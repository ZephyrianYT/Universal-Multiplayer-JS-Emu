@echo off
rem Double-click to start Retro Hub and share it over the internet with a Cloudflare Tunnel.
rem Needs cloudflared: winget install --id Cloudflare.cloudflared
cd /d "%~dp0"
where py >nul 2>nul && (py -3 launch.py --tunnel %* & goto :end)
where python >nul 2>nul && (python launch.py --tunnel %* & goto :end)
echo Python 3 was not found. Install it from https://www.python.org/downloads/ and try again.
:end
pause
