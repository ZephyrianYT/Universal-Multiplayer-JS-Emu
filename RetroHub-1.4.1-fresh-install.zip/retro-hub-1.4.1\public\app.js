// Retro Hub: hub page (hosts list, host form, library), the room lobby (ready-up, rules, voice, countdown)
// and the in-game view (loading board, host emulator / guest stream).
(function () {
  "use strict";
  const { Accounts, prettyId, Input, Net, UI, Voice, Calibrate, Ghost, Saves } = window.RH;
  const { Settings, Modal, guard, toast, Sfx, pingClass, pingLabel } = UI;
  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const wsUrl = () => (location.protocol === "https:" ? "wss://" : "ws://") + location.host + "/ws";
  const fmtSize = n => n > 1 << 20 ? (n / (1 << 20)).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB";
  const showErr = (el, text) => { el.textContent = text || ""; el.hidden = !text; };
  // Invite links use the hub's public address (PUBLIC_URL, e.g. a Cloudflare tunnel) when the server has one.
  const LOCAL_HOST_RE = /^(localhost|127\.\d+\.\d+\.\d+|\[::1\])$/i;
  const inviteBase = () => (config && config.publicUrl) || location.origin;
  const inviteLink = code => `${inviteBase()}/?join=${code}`;
  // A link built from localhost only works on this computer: say so instead of a cheerful "Copied!".
  function copyInvite(code, label) {
    const link = inviteLink(code);
    if (LOCAL_HOST_RE.test(new URL(link).hostname)) {
      return UI.copy(link, "Copied, but a localhost link only works on this PC")
        .then(() => UI.toast("Friends elsewhere need a public address: start the hub with launch-tunnel.bat (or set PUBLIC_URL).", { kind: "bad", ms: 6000 }));
    }
    return UI.copy(link, label);
  }
  const GHOST_TIP = "Each player runs their own local ROM independently. Other players appear as 60% translucent ghosts\u2014no collisions, shared items, or game interference.";
  const hostMode = () => document.querySelector("input[name=mode]:checked")?.value === "ghost" ? "ghost" : "coop";

  let me = null, config = null;
  const state = { rooms: [], library: null, inRoom: false, myRtt: null };
  let hubPicked = null;

  // ================================================================ boot
  async function boot() {
    const r = await fetch("/api/me", { cache: "no-store" });
    if (r.status === 401) { location.replace("/login.html?next=" + encodeURIComponent(location.pathname + location.search)); return; }
    me = await r.json();
    config = await fetch("/api/config", { cache: "no-store" }).then(r => r.json());
    renderTopbar();
    renderSystems();
    renderSeats();
    renderModePick();
    renderFilters();
    renderIntro();
    makePicker($("hub-picker"), p => {
      hubPicked = p;
      const remembered = p.kind === "file" && !p.system ? (Settings.get("extSys") || {})[fileExt(p.file)] : "";
      $("system").value = p.system || remembered || "";
      showPicked(p.system ? "" : remembered ? "Console remembered from last time; change it if it's wrong." : "Choose the console for this file.");
    }, () => { if (!$("host-btn").disabled) $("host-btn").click(); });
    if (!(await resumeRoom())) lobbySocket();
  }

  // Host migration hands off through a quick page reload: the hub marks our held seat as "handing off" and gives
  // it back to the same signed-in account. Only the (non-secret) room code is kept in sessionStorage; no token.
  async function resumeRoom() {
    let r = null;
    try { r = JSON.parse(sessionStorage.getItem("rh-rejoin") || "null"); sessionStorage.removeItem("rh-rejoin"); } catch {}
    if (!r || !r.code || Date.now() - r.at > 25000) return false;
    try {
      const sock = await GameSocket.open({ t: "join", role: "guest", room: r.code, handoff: true });
      const j = sock.joined;
      if (j.host) {
        const params = { t: "join", role: "host", room: r.code, game: j.game, system: j.system, local: [Math.max(0, j.slot)], mode: j.mode };
        sock.joinMsg = params;
        enterRoom(sock, { host: true, params, picked: null, promoted: true });
      } else enterRoom(sock, { host: false, room: { code: r.code, game: j.game, system: j.system, mode: j.mode } });
      return true;
    } catch (e) { toast(e.message || "Couldn't get back into the lobby.", { kind: "bad", ms: 4000 }); return false; }
  }
  function handOff(sock, code) {
    if (sock.handoff) return;
    sock.handoff = true;
    sock.send({ t: "handoff" });
    try { sessionStorage.setItem("rh-rejoin", JSON.stringify({ code, at: Date.now() })); } catch {}
    setTimeout(() => location.reload(), 50);
  }

  function renderTopbar() {
    $("me-name").textContent = me.name; $("me-name").title = me.name;
    $("me-id").textContent = "#" + prettyId(me.id);
    $("version").textContent = "v" + me.version;
    $("unlock-btn").hidden = !me.canUnlock;
  }

  $("switch-btn").addEventListener("click", async () => {
    await Accounts.signOut();
    Accounts.setCurrent(null);
    location.replace("/login.html");
  });
  $("export-btn").addEventListener("click", async () => {
    const acct = await Accounts.get(me.id).catch(() => null);
    if (!acct) return alert("This account's key isn't stored in this browser, so it can't be exported from here.");
    Accounts.download(acct);
  });

  // ---------------------------------------------------------------- calibration
  function openCalibration(after) {
    Calibrate.open({
      onDone: ({ reason, results }) => {
        if (reason === "done" && results.length) toast(`Calibration saved for ${results.filter(r => r.ok).length} controller(s).`, { kind: "ok" });
        renderCalibSummary();
        after?.();
      },
    });
  }
  $("calib-btn").addEventListener("click", () => openCalibration());
  function renderCalibSummary() {
    const cal = Calibrate.load(), keys = Object.keys(cal);
    $("r-calib-sum").textContent = keys.length
      ? keys.map(k => `${Calibrate.deviceName(k)} ${Number.isFinite(cal[k].offsetMs) ? (cal[k].offsetMs >= 0 ? "+" : "") + cal[k].offsetMs + " ms" : ""}`).join(" · ")
      : "Not calibrated yet";
    $("r-calib-sum").title = $("r-calib-sum").textContent;
  }

  // ---------------------------------------------------------------- unlock library
  $("unlock-btn").addEventListener("click", () => {
    showErr($("unlock-error"), ""); $("unlock-pw").value = "";
    Modal.open($("unlock-dlg"), { focus: "#unlock-pw" });
  });
  const doUnlock = guard($("unlock-form").querySelector("button[value=ok]"), async () => {
    const r = await fetch("/api/unlock", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password: $("unlock-pw").value }) });
    const res = await r.json().catch(() => ({}));
    if (!r.ok) return showErr($("unlock-error"), res.error || "Could not unlock.");
    Modal.close($("unlock-dlg"));
    me = await fetch("/api/me", { cache: "no-store" }).then(r => r.json());
    renderTopbar();
    state.library = null;
    document.querySelectorAll(".game-picker").forEach(el => el.__refresh?.());
  });
  $("unlock-form").addEventListener("submit", e => {
    if (e.submitter && e.submitter.value === "cancel") return;
    e.preventDefault(); doUnlock();
  });

  // ---------------------------------------------------------------- first-visit guide + join by code
  function renderIntro() {
    $("intro").hidden = !!Settings.get("introSeen");
    $("intro-close").onclick = () => { Settings.set("introSeen", true); $("intro").hidden = true; };
  }
  $("empty-host").addEventListener("click", e => {
    e.preventDefault();
    const box = $("hub-picker");
    box.scrollIntoView({ behavior: "smooth", block: "center" });
    (box.querySelector("[role=tab][aria-selected=true]") || box.querySelector("input"))?.focus({ preventScroll: true });
  });
  // Accepts a bare code or a whole pasted invite link.
  $("code-form").addEventListener("submit", e => {
    e.preventDefault();
    let v = $("code-input").value.trim();
    const m = /[?&]join=([A-Za-z0-9-]+)/.exec(v); if (m) v = m[1];
    const c = v.toUpperCase().replace(/[^A-Z0-9-]/g, "").slice(0, 24);
    if (!c) return $("code-input").focus();
    const r = state.rooms.find(x => x.code === c);
    if (!r) return toast(`No lobby with code ${c} is open right now.`, { kind: "bad", ms: 3500 });
    if (r.hostKey === me.id) return toast("That's your own lobby.");
    $("code-input").value = "";
    openJoin(r, true, r.open === 0 && r.watchable);
  });

  // ================================================================ lobby list (live)
  let lobbyWs = null, lobbyRetry = 1000, pingTimer = 0;
  function lobbySocket() {
    const ws = lobbyWs = new WebSocket(wsUrl());
    const ping = () => { if (ws.readyState === 1) ws.send(JSON.stringify({ t: "ping", ts: performance.now() })); };
    ws.onopen = () => {
      lobbyRetry = 1000; $("lobby-status").textContent = "Live";
      ws.send(JSON.stringify({ t: "lobby" }));
      ping(); clearInterval(pingTimer); pingTimer = setInterval(ping, 3000);
    };
    ws.onmessage = e => {
      let m; try { m = JSON.parse(e.data); } catch { return; }
      if (m.t === "rooms") { state.rooms = m.rooms || []; renderRooms(); checkInvite(); }
      if (m.t === "pong") {
        const rtt = performance.now() - m.ts;
        state.myRtt = state.myRtt == null ? rtt : state.myRtt * 0.6 + rtt * 0.4;   // smoothed
        $("my-ping").innerHTML = `You <span class="ping ${pingClass(state.myRtt)}">${pingLabel(state.myRtt)}</span>`;
        renderRooms();
      }
    };
    ws.onclose = () => {
      clearInterval(pingTimer);
      if (state.inRoom) return;
      $("lobby-status").textContent = "Reconnecting…";
      setTimeout(lobbySocket, lobbyRetry); lobbyRetry = Math.min(lobbyRetry * 2, 15000);
    };
  }
  const estPing = r => (state.myRtt == null || r.hostRtt == null) ? null : state.myRtt + r.hostRtt;

  function renderModePick() {
    const saved = Settings.get("hostMode") === "ghost" ? "ghost" : "coop";
    document.querySelectorAll("input[name=mode]").forEach(r => {
      r.checked = r.value === saved;
      r.addEventListener("change", () => { Settings.set("hostMode", hostMode()); modeHelp(); });
    });
    modeHelp();
  }
  function modeHelp() {
    const ghost = hostMode() === "ghost";
    $("mode-help").hidden = !ghost;
    $("seats-wrap").hidden = ghost;       // one player per computer in ghost mode
  }

  function renderFilters() {
    const f = Settings.get("filters");
    const sel = $("f-system");
    for (const [id, label] of Object.entries(config.systems)) { const o = document.createElement("option"); o.value = id; o.textContent = label; sel.appendChild(o); }
    $("f-full").checked = !!f.hideFull; $("f-locked").checked = !!f.hideLocked; sel.value = f.system || ""; $("f-mode").value = f.mode || "";
    const upd = () => { Settings.patch("filters", { hideFull: $("f-full").checked, hideLocked: $("f-locked").checked, system: sel.value, mode: $("f-mode").value }); renderRooms(); };
    $("f-full").addEventListener("change", upd); $("f-locked").addEventListener("change", upd); sel.addEventListener("change", upd);
    $("f-mode").addEventListener("change", upd);
  }

  let roomsKey = "";
  function renderRooms() {
    if (state.inRoom) return;
    const f = Settings.get("filters");
    const list = state.rooms
      .filter(r => !(f.hideFull && r.open === 0) && !(f.hideLocked && r.locked) && !(f.system && r.system !== f.system)
        && !(f.mode && (r.mode || "coop") !== f.mode))
      .map(r => ({ r, ping: estPing(r) }))
      .sort((a, b) => (a.ping ?? 1e9) - (b.ping ?? 1e9) || String(a.r.game).localeCompare(b.r.game));
    // Skip re-rendering when nothing visible changed (keeps focus and hover state stable).
    const key = JSON.stringify(list.map(x => [x.r, x.ping == null ? null : Math.round(x.ping / 5)]));
    if (key === roomsKey) return;
    roomsKey = key;
    const focusedCode = document.activeElement?.closest?.("#rooms li")?.dataset.code;
    const focusedAct = document.activeElement?.dataset?.act;
    const ul = $("rooms"); ul.textContent = "";
    $("rooms-empty").hidden = list.length > 0;
    $("rooms-empty-title").textContent = state.rooms.length ? "No lobbies match your filters." : "Nobody is hosting right now.";
    $("rooms-empty-sub").hidden = !!state.rooms.length;
    $("rooms-count").textContent = state.rooms.length ? `${list.length} of ${state.rooms.length}` : "";
    for (const { r, ping } of list) {
      const li = document.createElement("li");
      li.dataset.code = r.code;
      const mine = r.hostKey === me.id;
      const sys = config.systems[r.system] || "";
      const canJoin = r.open > 0 && !mine, canWatch = !mine && r.open === 0 && r.watchable;
      li.innerHTML = `
        <div class="grow">
          <div class="title" title="${esc(r.game || "Untitled game")}">${esc(r.game || "Untitled game")}</div>
          <div class="sub trunc">${esc(r.host)} <span class="id">#${esc(prettyId(r.hostKey))}</span>${sys ? " · " + esc(sys) : ""}${r.spectators ? ` · ${r.spectators} watching` : ""}</div>
        </div>
        ${r.mode === "ghost" ? `<span class="badge mode-ghost" title="${esc(GHOST_TIP)}">Ghost</span>` : ""}
        ${r.phase && r.phase !== "lobby" ? `<span class="badge">${r.phase === "playing" ? "In game" : r.phase === "countdown" ? "Starting" : "Loading"}</span>` : ""}
        <span class="ping ${pingClass(ping)}" title="Estimated ping through the hub">${pingLabel(ping)}</span>
        ${r.locked ? '<span class="badge lock" title="Needs a lobby password">🔒</span>' : ""}
        <span class="badge ${r.open ? "" : "full"}">${r.players}/${r.max}</span>
        <button class="small icon" data-act="copy" title="Copy invite link" aria-label="Copy invite link for ${esc(r.game || "this lobby")}">⧉</button>
        <button class="small ${canJoin || canWatch ? "primary" : ""}" data-act="join" ${canJoin || canWatch ? "" : "disabled"}>${mine ? "Yours" : canJoin ? "Join" : canWatch ? "Watch" : "Full"}</button>`;
      li.querySelector("[data-act=copy]").addEventListener("click", () => copyInvite(r.code));
      const jb = li.querySelector("[data-act=join]");
      jb.addEventListener("click", () => openJoin(r, false, canWatch));
      ul.appendChild(li);
      if (r.code === focusedCode && focusedAct) li.querySelector(`[data-act=${focusedAct}]`)?.focus();
    }
  }

  // ================================================================ join
  let joinTarget = null, joinWatch = false;
  let invite = new URLSearchParams(location.search).get("join");
  if (invite) invite = invite.toUpperCase().replace(/[^A-Z0-9-]/g, "").slice(0, 24) || null;

  function checkInvite() {
    if (!invite || state.inRoom) return;
    const r = state.rooms.find(x => x.code === invite);
    if (!r) { $("lobby-status").textContent = `Waiting for lobby ${invite} to open…`; return; }
    invite = null;
    history.replaceState(null, "", "/");
    if (r.hostKey === me.id) return;
    openJoin(r, true, r.open === 0 && r.watchable);
  }

  function showJoinDlg(room) {
    $("join-title").textContent = `${joinWatch ? "Watch" : "Join"} ${room.host}'s lobby`;
    $("join-sub").textContent = `${room.game || "Untitled game"}${config.systems[room.system] ? " · " + config.systems[room.system] : ""}`;
    $("join-ok").textContent = joinWatch ? "Watch" : "Join";
    if (!Modal.isOpen($("join-dlg"))) Modal.open($("join-dlg"), { focus: room.locked ? "#join-pw" : "#join-ok" });
  }
  function openJoin(room, fromInvite, watch) {
    joinTarget = room; joinWatch = !!watch;
    if (!room.locked && !fromInvite) return doJoin(room, "");
    $("join-pw-wrap").hidden = !room.locked;
    $("join-pw").value = "";
    showErr($("join-error"), "");
    showJoinDlg(room);
  }
  const submitJoin = guard($("join-ok"), () => joinTarget && doJoin(joinTarget, $("join-pw").value));
  $("join-form").addEventListener("submit", e => {
    if (e.submitter && e.submitter.value === "cancel") return;
    e.preventDefault(); submitJoin();
  });

  let joining = false;
  async function doJoin(room, password) {
    if (joining) return;            // one join request at a time
    joining = true;
    const btn = document.querySelector(`#rooms li[data-code="${room.code}"] [data-act=join]`);
    if (btn) btn.disabled = true;
    try {
      const sock = await GameSocket.open({ t: "join", role: "guest", room: room.code, password, spectate: joinWatch });
      if (Modal.isOpen($("join-dlg"))) Modal.close($("join-dlg"));
      enterRoom(sock, { host: false, room, password });
    } catch (e) {
      if (btn) btn.disabled = false;
      if (e.code === "full" && e.watchable && !joinWatch) { joinWatch = true; e.message += " Press Watch to spectate."; }
      $("join-pw-wrap").hidden = !(room.locked || e.code === "password");
      showJoinDlg(room);
      showErr($("join-error"), e.message);
    } finally { setTimeout(() => { joining = false; }, 300); }
  }

  // ================================================================ game picker (hub card + "Change game" dialog)
  const fileExt = f => (String(f?.name || "").split(".").pop() || "").toLowerCase();
  // onActivate (optional): double-click / Ctrl+Enter on a library game = pick it and go.
  function makePicker(box, onPick, onActivate) {
    const tab = Settings.get("tab") === "lib" ? "lib" : "file";
    box.innerHTML = `
      <div class="tabs" role="tablist">
        <button role="tab" data-tab="file">My files</button>
        <button role="tab" data-tab="lib" hidden>Server library</button>
      </div>
      <div data-panel="file">
        <p class="small muted">Pick a game file from this computer. It stays here: it's never uploaded.</p>
        <input type="file" class="rom-file" aria-label="Game file">
      </div>
      <div data-panel="lib" hidden>
        <div class="lib-tools">
          <input type="search" class="lib-search" placeholder="Search the library" aria-label="Search the library">
          <select class="lib-sys" aria-label="Console"><option value="">All consoles</option></select>
          <select class="lib-sort" aria-label="Sort games">
            <option value="name">A–Z</option><option value="recent">Recently played</option><option value="system">By console</option>
          </select>
        </div>
        <div class="small muted lib-count" aria-live="polite"></div>
        <div class="library lib-grid" role="listbox" aria-label="Games"></div>
      </div>`;
    const q = s => box.querySelector(s);
    let picked = null;
    const select = name => {
      if (name === "lib" && !me.library) name = "file";
      box.querySelectorAll("[data-tab]").forEach(b => b.setAttribute("aria-selected", String(b.dataset.tab === name)));
      box.querySelectorAll("[data-panel]").forEach(p => { p.hidden = p.dataset.panel !== name; });
      Settings.set("tab", name);
      if (name === "lib") loadLibrary(q(".library"), render);
    };
    box.querySelectorAll("[data-tab]").forEach(b => b.addEventListener("click", () => select(b.dataset.tab)));
    q(".rom-file").addEventListener("change", () => {
      const f = q(".rom-file").files[0]; if (!f) return;
      const ext = (f.name.split(".").pop() || "").toLowerCase();
      picked = { kind: "file", file: f, name: f.name.replace(/\.[^.]+$/, ""), system: config.detect.ext[ext] || "" };
      onPick(picked);
    });
    const libPrefs = () => ({ sys: "", sort: "name", ...(Settings.get("lib") || {}) });
    q(".lib-sort").value = libPrefs().sort;
    q(".lib-sys").addEventListener("change", () => { Settings.patch("lib", { sys: q(".lib-sys").value }); render(); });
    q(".lib-sort").addEventListener("change", () => { Settings.patch("lib", { sort: q(".lib-sort").value }); render(); });
    let sysFilled = false;
    const render = () => {
      if (!state.library) return;
      const lib = q(".library"), term = q(".lib-search").value.trim().toLowerCase();
      const prefs = libPrefs();
      if (!sysFilled) {           // only consoles that are actually in the library
        sysFilled = true;
        const present = [...new Set(state.library.map(g => g.system))].sort((a, b) => (config.systems[a] || a).localeCompare(config.systems[b] || b));
        for (const id of present) { const o = document.createElement("option"); o.value = id; o.textContent = config.systems[id] || id; q(".lib-sys").appendChild(o); }
        q(".lib-sys").value = present.includes(prefs.sys) ? prefs.sys : "";
        q(".lib-sys").hidden = present.length < 2;
      }
      const sys = q(".lib-sys").value;
      lib.textContent = "";
      if (!state.library.length) {
        lib.innerHTML = `<div class="empty"><div class="empty-title">No games in the server's ROM folder yet.</div>
          <div class="small">Put ROM files in <code>roms/</code> (one folder per console, e.g. <code>roms/snes</code>) and reopen this tab.</div></div>`;
        q(".lib-count").textContent = ""; return;
      }
      const recent = Settings.get("recent") || [];
      const rank = g => { const i = recent.indexOf(g.path); return i < 0 ? 1e9 : i; };
      const sysName = id => config.systems[id] || id;
      const items = state.library
        .filter(g => (!sys || g.system === sys) && (!term || g.name.toLowerCase().includes(term) || g.path.toLowerCase().includes(term)))
        .sort(prefs.sort === "recent" ? (a, b) => rank(a) - rank(b) || a.name.localeCompare(b.name)
          : prefs.sort === "system" ? (a, b) => sysName(a.system).localeCompare(sysName(b.system)) || a.name.localeCompare(b.name)
          : (a, b) => a.name.localeCompare(b.name));
      q(".lib-count").textContent = items.length === state.library.length ? `${items.length} game${items.length === 1 ? "" : "s"}` : `${items.length} of ${state.library.length} games`;
      if (!items.length) { lib.innerHTML = '<div class="empty">No games match.</div>'; return; }
      for (const g of items) {
        const t = document.createElement("button");
        t.type = "button"; t.className = "tile"; t.setAttribute("role", "option");
        t.setAttribute("aria-selected", String(picked?.kind === "lib" && picked.item.path === g.path));
        t.title = `${g.name}\n${sysName(g.system)} · ${g.ext.toUpperCase()} · ${fmtSize(g.size)}`;
        t.innerHTML = `<span class="cover" style="--hue:${sysHue(g.system)}"><span class="cover-sys">${esc(sysShort(g.system))}</span><span class="cover-init">${esc(initials(g.name))}</span></span>
          <span class="t-name"></span><span class="t-sub"></span>${rank(g) < 1e9 ? '<span class="t-recent" title="Played recently"></span>' : ""}`;
        t.querySelector(".t-name").textContent = g.name;
        t.querySelector(".t-sub").textContent = `${sysShort(g.system)} · ${fmtSize(g.size)}`;
        if (g.cover) {
          const img = new Image(); img.alt = ""; img.loading = "lazy"; img.decoding = "async";
          img.addEventListener("load", () => t.querySelector(".cover").classList.add("has-img"));
          img.addEventListener("error", () => img.remove());
          img.src = "/covers/" + g.cover.split("/").map(encodeURIComponent).join("/");
          t.querySelector(".cover").appendChild(img);
        }
        if (onActivate) {
          t.title += "\nDouble-click to open a lobby with it";
          t.addEventListener("dblclick", () => onActivate());
          t.addEventListener("keydown", e => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); t.click(); onActivate(); } });
        }
        t.addEventListener("click", () => {
          picked = { kind: "lib", item: g, name: g.name, system: g.system };
          lib.querySelectorAll(".tile").forEach(x => x.setAttribute("aria-selected", "false"));
          t.setAttribute("aria-selected", "true");
          onPick(picked);
        });
        lib.appendChild(t);
      }
    };
    // Arrow keys move between tiles (row by row, using the rendered layout).
    q(".library").addEventListener("keydown", e => {
      if (!/^Arrow(Left|Right|Up|Down)$/.test(e.key)) return;
      const tiles = [...q(".library").querySelectorAll(".tile")], i = tiles.indexOf(document.activeElement);
      if (i < 0) return;
      e.preventDefault();
      const cols = Math.max(1, tiles.filter(t => t.offsetTop === tiles[0].offsetTop).length);
      const j = e.key === "ArrowLeft" ? i - 1 : e.key === "ArrowRight" ? i + 1 : e.key === "ArrowUp" ? i - cols : i + cols;
      tiles[Math.max(0, Math.min(tiles.length - 1, j))].focus();
    });
    q(".lib-search").addEventListener("input", UI.debounce(render, 120));
    box.__refresh = () => { q("[data-tab=lib]").hidden = !me.library; select(me.library ? Settings.get("tab") : "file"); };
    q("[data-tab=lib]").hidden = !me.library;
    select(tab);
    return { reset() { picked = null; q(".rom-file").value = ""; render(); } };
  }
  const SYS_SHORT = { n64: "N64", nes: "NES", snes: "SNES", gb: "GB", gba: "GBA", nds: "DS", psx: "PS1", segaMD: "MD", segaMS: "SMS",
    segaGG: "GG", segaCD: "SCD", sega32x: "32X", segaSaturn: "SAT", atari2600: "2600", atari7800: "7800", lynx: "LYNX", jaguar: "JAG",
    pce: "PCE", ngp: "NGP", ws: "WS", vb: "VB", coleco: "CV", arcade: "ARC", psp: "PSP" };
  const sysShort = id => SYS_SHORT[id] || String(id || "?").toUpperCase().slice(0, 4);
  const sysHue = id => { let h = 0; for (const c of String(id)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
  // "The Legend of Zelda (U) [!]" -> "LZ": first letters of the main words, tags in brackets dropped.
  const initials = name => (String(name).replace(/[([].*$/, "").replace(/([a-z])(?=[A-Z0-9])|(of)(?=[A-Z])/g, "$1$2 ").match(/[A-Za-z0-9]+/g) || ["?"])
    .filter(w => !/^(the|of|a|an|and|de|la|le)$/i.test(w)).slice(0, 2).map(w => w[0].toUpperCase()).join("") || "?";
  function rememberPlayed(item) {
    const recent = (Settings.get("recent") || []).filter(p => p !== item.path);
    Settings.set("recent", [item.path, ...recent].slice(0, 30));
  }
  let libLoading = null;
  async function loadLibrary(box, render) {
    if (state.library) return render();
    box.innerHTML = '<div class="empty">Loading…</div>';
    libLoading = libLoading || fetch("/api/library", { cache: "no-store" }).then(async r => r.ok ? r.json() : null).finally(() => { libLoading = null; });
    const lib = await libLoading;
    if (!lib) { box.innerHTML = '<div class="empty">The library is owner-only.</div>'; return; }
    state.library = lib; render();
  }

  // ================================================================ host form
  function renderSystems() {
    for (const sel of [$("system"), $("r-system")]) {
      for (const [id, label] of Object.entries(config.systems)) {
        const o = document.createElement("option"); o.value = id; o.textContent = label; sel.appendChild(o);
      }
    }
    $("system").addEventListener("change", () => {
      if (hubPicked?.kind === "file" && !hubPicked.system && $("system").value)
        Settings.patch("extSys", { [fileExt(hubPicked.file)]: $("system").value });
      updateHostBtn();
    });
  }
  function renderSeats() {
    const box = $("seats"); box.textContent = "";
    const p1 = document.createElement("label"); p1.className = "check";
    p1.innerHTML = `<input type="checkbox" checked disabled> P1: you`;
    box.appendChild(p1);
    for (let s = 1; s < config.maxPlayers; s++) {
      const l = document.createElement("label"); l.className = "check";
      l.innerHTML = `<input type="checkbox" data-seat="${s}"> P${s + 1} on this computer`;
      box.appendChild(l);
    }
    box.addEventListener("change", seatHelp);
    seatHelp();
  }
  const localSeats = () => hostMode() === "ghost" ? [0] : [0, ...[...document.querySelectorAll("[data-seat]")].filter(c => c.checked).map(c => Number(c.dataset.seat))];
  function seatHelp() {
    const seats = localSeats();
    const parts = seats.map((s, i) => `P${s + 1}: ${i === 0 ? "keyboard (arrows) or gamepad 1" : i === 1 ? "numpad keys or gamepad 2" : `gamepad ${i + 1}`}`);
    const online = config.maxPlayers - seats.length;
    $("seat-help").textContent = parts.join(" · ") + ` · ${online} seat${online === 1 ? "" : "s"} open online.`;
  }
  function showPicked(note) {
    const p = hubPicked;
    $("picked").hidden = !p;
    if (p) $("picked").innerHTML = `Game: <b class="trunc-inline" title="${esc(p.name)}">${esc(p.name)}</b> <span class="muted">(${p.kind === "file" ? "from this computer" : "server library"})</span>${note ? `<div class="small muted">${esc(note)}</div>` : ""}`;
    updateHostBtn();
  }
  function updateHostBtn() { $("host-btn").disabled = !(hubPicked && $("system").value); }

  const CODE_CHARS = "ABCDEFGHJKMNPQRTUVWXY346789";      // no look-alikes: 0/O, 1/I/L, 2/Z, 5/S
  const newCode = () => Array.from(crypto.getRandomValues(new Uint8Array(6)), b => CODE_CHARS[b % CODE_CHARS.length]).join("");

  const openLobby = guard($("host-btn"), async () => {
    const p = hubPicked, system = $("system").value;
    if (!p || !system) return;
    showErr($("host-error"), "");
    const code = newCode();
    const params = { t: "join", role: "host", room: code, password: $("lobby-pw").value, game: p.name, system, local: localSeats(), mode: hostMode() };
    try {
      const sock = await GameSocket.open(params);
      if (p.kind === "lib") rememberPlayed(p.item);
      enterRoom(sock, { host: true, params, picked: p });
    } catch (e) { showErr($("host-error"), e.message); }
    finally { updateHostBtn(); }
  });
  $("host-btn").addEventListener("click", openLobby);

  // ================================================================ game socket (signaling) with auto-rejoin
  const GameSocket = {
    // Resolves once the server says "joined"; rejects with {message, code} on a join error.
    open(joinMsg) {
      return new Promise((resolve, reject) => {
        const sock = { joinMsg, handlers: {}, ws: null, closed: false, joined: null,
          on(t, fn) { this.handlers[t] = fn; return this; },
          send(m) { if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify(m)); },
          // Intentional leave: tell the hub first so it frees the seat now instead of holding it for a resume.
          close() { this.closed = true; this.send({ t: "leave" }); try { this.ws.close(); } catch {} } };
        let first = true, retry = 1500;     // reconnect delay: 1.5 s, doubling up to 15 s while the hub is unreachable
        window.addEventListener("pagehide", e => { if (!e.persisted && !sock.closed && !sock.handoff) sock.close(); });
        const connect = () => {
          const ws = sock.ws = new WebSocket(wsUrl());
          // After a drop, the resume token from "joined" gets this player back the same id, seat and ready state.
          ws.onopen = () => { retry = 1500; ws.send(JSON.stringify(sock.token ? { ...sock.joinMsg, resume: sock.token } : sock.joinMsg)); };
          ws.onmessage = e => {
            let m; try { m = JSON.parse(e.data); } catch { return; }
            if (m.t === "joined") {
              if (m.token) sock.token = m.token;
              sock.joined = m;
              if (first) { first = false; resolve(sock); } else sock.handlers.rejoined?.(m);
              return;
            }
            if (m.t === "error" && first) {
              first = false; sock.closed = true; ws.close();
              const err = new Error(m.msg || "Could not join."); err.code = m.code; err.watchable = m.watchable; return reject(err);
            }
            if (m.t === "error") { sock.handlers.fatal?.(m); sock.closed = true; ws.close(); return; }
            sock.handlers[m.t]?.(m);
          };
          ws.onclose = () => {
            if (first) { first = false; return reject(new Error("Lost the connection to the hub.")); }
            if (sock.closed) return;
            sock.handlers.dropped?.();
            setTimeout(() => { if (!sock.closed) connect(); }, retry);
            retry = Math.min(retry * 2, 15000);
          };
        };
        connect();
      });
    },
  };

  // ================================================================ ROOM (lobby -> countdown -> loading -> playing)
  function enterRoom(sock, opts) {
    state.inRoom = true;
    try { lobbyWs?.close(); } catch {}
    const isHost = opts.host;
    const code = isHost ? opts.params.room : opts.room.code;
    let picked = opts.picked || null;
    let players = [], phase = sock.joined.phase || "lobby", rules = { spectators: true, mode: isHost ? opts.params.mode : (opts.room.mode || "coop") }, reserved = [], staged = false;
    const ghostMode = () => rules.mode === "ghost";
    let myRom = null;            // ghost mode: { crc, size, name, file?, src } of the ROM this player will run
    let romHash = null;          // { pct, name } while hashing
    let roomGame = isHost ? opts.params.game : opts.room.game, roomSystem = isHost ? opts.params.system : opts.room.system;
    const myId = () => sock.joined.id;
    const mine = () => players.find(p => p.id === myId());
    const keyOf = id => players.find(p => p.id === id)?.key;

    // ---- views
    $("hub-main").hidden = true; $("room").hidden = false;
    document.querySelectorAll("#room .host-only").forEach(el => { el.hidden = !isHost; });
    $("r-code").textContent = code;
    $("r-copy-code").onclick = () => UI.copy(code, "Code copied!");
    $("r-copy-link").onclick = () => copyInvite(code, "Copied! (password not included)");
    $("r-leave").onclick = () => {
      if (isHost && players.length > 1 && !confirm("Leave the lobby? Hosting passes to another player.")) return;
      leave();
    };
    if (opts.promoted) setTimeout(() => toast(`You're the host now. Pick the game with "Change…" to start.`, { kind: "ok", ms: 6000 }), 300);
    const leave = () => { sock.close(); net.close(); voice.close(); comp?.destroy(); if (document.pictureInPictureElement) document.exitPictureInPicture().catch(() => {}); location.replace("/"); };
    window.addEventListener("beforeunload", e => { if (isHost && (phase === "playing" || phase === "loading")) { e.preventDefault(); e.returnValue = ""; } });

    // ---- settings panel (persisted)
    const det = $("r-settings");
    det.open = !!Settings.get("panels").settings;
    det.addEventListener("toggle", () => Settings.patch("panels", { settings: det.open }));
    $("s-volume").value = Settings.get("volume"); $("s-voice").value = Settings.get("voiceVolume");
    $("s-sfx").checked = !!Settings.get("sfx"); $("s-eq").checked = !!Settings.get("equalizeLag");
    $("s-volume").addEventListener("input", () => { const v = Number($("s-volume").value); Settings.set("volume", v); applyGameVolume(v); });
    $("s-voice").addEventListener("input", () => voice.setVolume(Number($("s-voice").value)));
    $("s-sfx").addEventListener("change", () => Settings.set("sfx", $("s-sfx").checked));
    $("s-eq").addEventListener("change", () => Settings.set("equalizeLag", $("s-eq").checked));
    $("r-calib").onclick = () => openCalibration();
    renderCalibSummary();
    const applyGameVolume = v => {
      if (window.EJS_emulator) { try { window.EJS_emulator.setVolume(v); } catch {} }
      else $("guest-video").volume = v;
    };

    // ---- voice
    const voice = new Voice.Voice();
    Voice.animateMeters(voice, me.id);
    const micButtons = [$("r-mic"), $("g-mic")];
    const renderMic = () => micButtons.forEach(b => {
      const on = !!voice.mic; b.setAttribute("aria-pressed", String(on));
      b.textContent = b.id === "r-mic" ? (on ? "🎙 Mic on" : "🎙 Mic off") : (on ? "🎙 On" : "🎙 Off");
      b.classList.toggle("on", on);
    });
    const toggleMic = guard(null, async () => {
      if (voice.mic) { voice.disable(); }
      else {
        try { await voice.enable(); }
        catch (e) { toast(e.name === "NotAllowedError" ? "Microphone permission was denied." : "No microphone available.", { kind: "bad", ms: 3000 }); }
      }
      if (isHost) net.setHostMic(voice.mic, myId()); else net.setMic(voice.mic);
      sock.send({ t: "voice", on: !!voice.mic });
      renderMic();
    });
    micButtons.forEach(b => b.addEventListener("click", toggleMic));
    renderMic();

    // ---- networking (started now so voice works in the lobby; the game stream joins at load time)
    // The game object is created when the match loads, once the mode is final:
    // co-op host (emulator + stream), co-op guest (stream), ghost player (own emulator) or ghost spectator.
    let net, game = null, lastStream = null, netStateNow = "new";
    let comp = null;                          // ghost compositor
    let ghostTracks = new Map();              // playerId -> remote ghost video track
    let myGhost = null;                       // this player's own ghost track
    if (isHost) {
      net = new Net.HostNet({
        iceServers: config.iceServers,
        sendSignal: (to, data) => sock.send({ t: "signal", to, data }),
        onInput: (id, v) => game?.input?.(id, v),
        onState: () => { renderSlots(); game?.redraw(); },
        onVoice: (id, track) => { const k = keyOf(id); if (!k) return; track ? voice.setRemote(k, track) : voice.dropRemote(k); },
        onGhost: (id, track) => { track ? ghostTracks.set(id, track) : ghostTracks.delete(id); syncGhosts(); },
        onAbuse: id => toast(`Cut off ${players.find(p => p.id === id)?.name || "a player"}'s connection: it was flooding or sending bad data.`, { kind: "bad", ms: 5000 }),
      });
      net.start();
    } else {
      net = new Net.GuestNet({
        iceServers: config.iceServers,
        sendSignal: (to, data) => sock.send({ t: "signal", to, data }),
        onStream: s => { lastStream = s; game?.stream?.(s); },
        onState: st => { netStateNow = st; game?.netState?.(st); },
        onGhosts: map => { ghostTracks = new Map(Object.entries(map).map(([id, t]) => [Number(id), t])); syncGhosts(); },
        onAbuse: () => toast("Disconnected from the host: it was flooding or sending bad data.", { kind: "bad", ms: 5000 }),
        onVoice: map => {
          const want = new Map(Object.entries(map).map(([id, tr]) => [keyOf(Number(id)), tr]).filter(([k]) => k));
          for (const k of [...voice.remote.keys()]) if (!want.has(k)) voice.dropRemote(k);
          for (const [k, tr] of want) voice.setRemote(k, tr);
        },
      });
    }
    voice.onChange(() => renderSlots());
    if (!isHost) net.onSharedState = bytes => receiveSharedSave(bytes);

    // ---- text chat (relayed and kept by the hub; works for players and spectators, with or without a mic)
    const chatLog = $("chat-log"), chatSeen = new Set();
    let chatOpen = false, unread = 0, peekT = 0;
    $("r-chat-home").appendChild($("chat"));
    const atBottom = () => chatLog.scrollHeight - chatLog.scrollTop - chatLog.clientHeight < 40;
    function addChat(msg) {
      if (!msg || typeof msg.n !== "number" || chatSeen.has(msg.n)) return false;
      chatSeen.add(msg.n);
      const stick = atBottom();
      const li = document.createElement("li");
      const time = new Date(msg.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      if (msg.sys) {
        li.className = "sys";
        li.innerHTML = `<span class="c-text"></span><time></time>`;
      } else {
        li.className = msg.key === me.id ? "mine" : "";
        li.innerHTML = `<div class="c-who"><span class="c-slot"></span><b class="trunc"></b><time></time></div><div class="c-text"></div>`;
        li.querySelector(".c-slot").textContent = msg.slot >= 0 ? `P${msg.slot + 1}` : "👁";
        li.querySelector(".c-who b").textContent = msg.name; li.querySelector(".c-who b").title = `${msg.name} #${prettyId(msg.key || "")}`;
      }
      li.querySelector(".c-text").textContent = msg.text;
      li.querySelector("time").textContent = time;
      chatLog.appendChild(li);
      while (chatLog.children.length > 200) chatLog.firstElementChild.remove();
      $("chat-empty").hidden = true;
      if (stick) chatLog.scrollTop = chatLog.scrollHeight;
      return true;
    }
    function onNewChat(msg) {
      if (!inGame || chatOpen || msg.key === me.id) return;
      if (!msg.sys) { unread++; renderUnread(); }
      // A short "peek" bubble over the game so nobody misses a message.
      const peek = $("chat-peek");
      const line = document.createElement("div");
      line.className = "peek-line" + (msg.sys ? " sys" : "");
      line.textContent = msg.sys ? msg.text : `${msg.name}: ${msg.text}`;
      peek.appendChild(line);
      while (peek.children.length > 3) peek.firstElementChild.remove();
      clearTimeout(peekT); peekT = setTimeout(() => { peek.textContent = ""; }, 6000);
    }
    const renderUnread = () => { const u = $("g-chat-unread"); u.hidden = !unread; u.textContent = unread > 9 ? "9+" : String(unread); };
    sock.on("chat", m => { if (addChat(m.msg)) { onNewChat(m.msg); noteTitle(m.msg); } });
    sock.on("chat-history", m => { (Array.isArray(m.list) ? m.list : []).forEach(addChat); chatLog.scrollTop = chatLog.scrollHeight; });
    let lastSent = "", sendTimes = [];
    $("chat-form").addEventListener("submit", e => {
      e.preventDefault();
      const text = $("chat-input").value.trim();
      if (!text) return;
      // Keep the text in the box when it can't go out now, instead of silently dropping it.
      if (!sock.ws || sock.ws.readyState !== 1) return toast("Not connected to the hub right now. Your message is still in the box.", { kind: "bad", ms: 3000 });
      const now = Date.now(); sendTimes = sendTimes.filter(t => now - t < 8000);
      if (sendTimes.length >= 6) return toast("Slow down a little: wait a few seconds before sending more.", { ms: 2500 });
      sendTimes.push(now);
      sock.send({ t: "chat", text });
      lastSent = text;
      $("chat-input").value = ""; renderChatCount();
      if (inGame) $("chat-input").blur();          // in a match, Enter sends and hands the keyboard back to the game
    });
    const renderChatCount = () => {
      const n = $("chat-input").value.length, c = $("chat-count");
      c.hidden = n < 240; c.textContent = `${300 - n}`; c.classList.toggle("bad", n >= 290);
    };
    $("chat-input").addEventListener("input", renderChatCount);
    // Tab title shows unread messages while the page is in the background.
    let titleUnread = 0;
    const baseTitle = document.title;
    const renderTitle = () => { document.title = titleUnread ? `(${titleUnread}) ${baseTitle}` : baseTitle; };
    document.addEventListener("visibilitychange", () => { if (!document.hidden) { titleUnread = 0; renderTitle(); } });
    function noteTitle(msg) { if (document.hidden && !msg.sys && msg.key !== me.id) { titleUnread++; renderTitle(); } }
    // Typing must never leave a game button held down: release every key the moment the chat box gets focus.
    $("chat-input").addEventListener("focus", () => window.dispatchEvent(new Event("blur")));
    $("chat-input").addEventListener("keydown", e => {
      if (e.key === "Escape") {
        e.preventDefault(); e.stopPropagation(); $("chat-input").blur();
        if (inGame) setChatOpen(false);
      } else if (e.key === "ArrowUp" && !$("chat-input").value && lastSent) {      // recall your last message
        e.preventDefault(); $("chat-input").value = lastSent; renderChatCount();
      }
    });
    function setChatOpen(open, focus) {
      chatOpen = open;
      $("g-chat-drawer").hidden = !open;
      $("g-chat").setAttribute("aria-expanded", String(open));
      $("g-chat").classList.toggle("on", open);
      if (open && Modal.isOpen(savesPanel)) Modal.close(savesPanel);
      if (open) { unread = 0; renderUnread(); $("chat-peek").textContent = ""; chatLog.scrollTop = chatLog.scrollHeight; if (focus) $("chat-input").focus(); }
    }
    $("g-chat").onclick = () => setChatOpen(!chatOpen, !chatOpen);
    $("chat-close").onclick = () => setChatOpen(false);
    window.addEventListener("keydown", e => {
      if (!inGame || (e.code !== "Slash" && e.key !== "/") || e.code === "NumpadDivide" || e.ctrlKey || e.metaKey || e.altKey) return;
      const t = e.target;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable)) return;
      e.preventDefault();
      setChatOpen(true, true);
    });

    // ---- save states (co-op host). Every save is also copied to each guest, so whoever hosts next can resume.
    const savesPanel = $("saves-panel");
    const emuReady = () => !!window.EJS_emulator?.gameManager && phase === "playing";
    const canSave = () => isHost && !ghostMode();
    async function saveNow() {
      if (!canSave()) return;
      if (!emuReady()) return toast("The game isn't running yet.", { kind: "bad" });
      const gm = window.EJS_emulator.gameManager;
      try { if (gm.supportsStates && !gm.supportsStates()) return toast("This console's emulator can't make save states.", { kind: "bad", ms: 3500 }); } catch {}
      let bytes;
      try { bytes = gm.getState(); } catch { return toast("Couldn't save the game right now.", { kind: "bad" }); }
      const png = await Promise.race([Promise.resolve().then(() => gm.screenshot()).catch(() => null), new Promise(r => setTimeout(() => r(null), 1500))]);
      const thumb = png ? await Saves.thumbFrom(png) : null;
      const label = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      let entry;
      try {
        entry = await Saves.make(bytes, { system: roomSystem, game: roomGame, by: me.name, byKey: me.id, label, thumb });
        entry.id = await Saves.put(entry);
      } catch (e) { return toast("Couldn't store the save in this browser.", { kind: "bad", ms: 3500 }); }
      sock.send({ t: "savestate", act: "save", label });
      toast(`Game saved (${fmtSize(entry.size)}).`, { kind: "ok" });
      if (Modal.isOpen(savesPanel)) renderSaves();
      if (players.some(p => !p.host)) {
        const packed = await Saves.pack(entry);
        if (packed.length <= Saves.MAX_PACKED) net.sendState(packed).then(n => { if (n) toast(`Save copied to ${n} other player${n === 1 ? "" : "s"}.`, { ms: 2200 }); });
      }
    }
    async function loadSave(id) {
      if (!canSave()) return;
      if (!emuReady()) return toast("Start the match first, then load the save.", { kind: "bad", ms: 3000 });
      const entry = await Saves.get(id).catch(() => null);
      if (!entry) return toast("That save is gone.", { kind: "bad" });
      let bytes;
      try { bytes = await Saves.load(entry); window.EJS_emulator.gameManager.loadState(bytes); }
      catch (e) { return toast(e.message && e.message.length < 80 ? e.message : "Couldn't load that save.", { kind: "bad", ms: 3500 }); }
      sock.send({ t: "savestate", act: "load", label: `${entry.label || Saves.ago(entry.at)}${entry.by ? ` by ${entry.by}` : ""}` });
      toast("Save loaded.", { kind: "ok" });
    }
    async function receiveSharedSave(bytes) {
      try {
        const head = Saves.unpack(bytes);
        if (head.system !== roomSystem || head.game.toLowerCase() !== String(roomGame).toLowerCase()) return;   // not this match's game
        await Saves.importPacked(bytes, { shared: true });
        toast(`${head.by || "The host"} saved the game. A copy is kept on this computer too.`, { ms: 3000 });
      } catch {}
    }
    async function renderSaves() {
      const list = $("sv-list");
      const rows = await Saves.list(roomSystem, roomGame).catch(() => []);
      const others = (await Saves.listSystem(roomSystem).catch(() => [])).filter(r => r.gameKey !== rows[0]?.gameKey && r.game.toLowerCase() !== String(roomGame).toLowerCase());
      $("sv-save").hidden = !canSave();
      const row = (r, other) => `<li data-id="${r.id}">
          ${r.thumb ? `<img class="sv-thumb" src="${esc(r.thumb)}" alt="">` : `<span class="sv-thumb none">${esc(sysShort(r.system))}</span>`}
          <div class="grow min0">
            <div class="title trunc" title="${esc(r.by ? `Saved by ${r.by}` : "")}">${esc(other ? r.game : (r.label || "Save"))}${r.by ? ` <span class="muted small">· ${esc(r.by)}</span>` : ""}</div>
            <div class="sub trunc">${esc(Saves.ago(r.at))} · ${fmtSize(r.size)}${r.shared ? " · shared" : ""}</div>
          </div>
          ${!other && canSave() ? `<button class="small primary" data-load="${r.id}">Load</button>` : ""}
          <button class="small icon" data-dl="${r.id}" title="Download a .rhsave file" aria-label="Download">⤓</button>
          <button class="small icon" data-del="${r.id}" title="Delete" aria-label="Delete">🗑</button>
        </li>`;
      list.innerHTML = rows.length ? rows.map(r => row(r)).join("")
        : `<li class="empty-row"><div class="empty small">No saves for this game yet.${canSave() ? " Press 💾 Save (or F2) during the match." : ""}</div></li>`;
      if (others.length) list.insertAdjacentHTML("beforeend", `<li class="sv-group small muted">Other ${esc(config.systems[roomSystem] || "")} games</li>` + others.slice(0, 8).map(r => row(r, true)).join(""));
      list.querySelectorAll("[data-load]").forEach(b => b.onclick = guard(b, async () => { await loadSave(Number(b.dataset.load)); }));
      list.querySelectorAll("[data-dl]").forEach(b => b.onclick = async () => { const e = await Saves.get(Number(b.dataset.dl)); if (e) Saves.download(e); });
      list.querySelectorAll("[data-del]").forEach(b => b.onclick = async () => {
        if (!confirm("Delete this save from this computer? This can't be undone.")) return;
        await Saves.remove(Number(b.dataset.del)); renderSaves();
      });
    }
    $("sv-save").onclick = guard($("sv-save"), saveNow);
    $("sv-import").addEventListener("change", async e => {
      const f = e.target.files[0]; e.target.value = "";
      if (!f) return;
      if (f.size > Saves.MAX_PACKED) return toast("That file is too big to be a save.", { kind: "bad" });
      try {
        const entry = await Saves.importPacked(new Uint8Array(await f.arrayBuffer()), { shared: true });
        toast(entry.system === roomSystem && entry.game.toLowerCase() === String(roomGame).toLowerCase()
          ? "Save imported." : `Imported a save for ${entry.game}, which isn't this game.`, { kind: "ok", ms: 3500 });
        renderSaves();
      } catch (err) { toast(err.message || "Couldn't import that file.", { kind: "bad" }); }
    });
    $("sv-close").onclick = () => Modal.close(savesPanel);
    $("g-save").onclick = guard($("g-save"), saveNow);
    $("g-saves").onclick = () => {
      if (Modal.isOpen(savesPanel)) return Modal.close(savesPanel);
      renderSaves();
      Modal.open(savesPanel, { focus: "#sv-close" });
    };
    window.addEventListener("keydown", async e => {
      if (!inGame || !canSave() || e.repeat || (e.key !== "F2" && e.key !== "F4")) return;
      e.preventDefault();
      if (e.key === "F2") return saveNow();
      const newest = (await Saves.list(roomSystem, roomGame).catch(() => []))[0];
      newest ? loadSave(newest.id) : toast("No save for this game yet (F2 saves).", { ms: 2500 });
    });
    // When the match starts, mention a save that can be continued (e.g. a copy the previous host shared).
    async function offerResume() {
      if (!canSave()) return;
      const newest = (await Saves.list(roomSystem, roomGame).catch(() => []))[0];
      if (newest) toast(`Saved game from ${Saves.ago(newest.at)}${newest.by ? ` by ${newest.by}` : ""} available. Open 📂 Saves (or press F4) to continue it.`, { ms: 6500 });
    }

    // ---- ghost mode: the player's own ROM (checksum only is shared)
    const romMeta = r => r ? { crc: r.crc, size: r.size, name: r.name } : null;
    const refRom = () => players.find(p => p.host)?.rom || null;
    let hashToken = 0;
    async function useRom(blob, name, src, file) {
      const token = ++hashToken;
      romHash = { pct: 0, name };
      renderRomBoxes();
      try {
        const crc = await Ghost.crc32File(blob, pct => { if (token === hashToken) { romHash.pct = Math.round(pct * 100); renderRomBoxes(); } });
        if (token !== hashToken) return;
        myRom = { crc, size: blob.size, name, file, src };
        romHash = null;
        sock.send({ t: "rom", rom: romMeta(myRom) });
        sock.joinMsg = { ...sock.joinMsg, rom: romMeta(myRom) };
        game?.romReady?.();
      } catch (e) {
        if (token !== hashToken) return;
        romHash = null;
        toast("Couldn't read that file.", { kind: "bad", ms: 3000 });
      }
      renderRoom();
    }
    // The host's reference ROM is the game they picked (a local file or the server library).
    async function hashHostRom() {
      if (!isHost || !picked || !ghostMode()) return;
      const src = picked.kind === "lib" ? "lib:" + picked.item.path : picked.file;
      if (myRom && myRom.src === src) return;
      if (picked.kind === "file") return useRom(picked.file, picked.file.name, src, picked.file);
      const r = await fetch(libUrl(picked.item), { cache: "no-store" }).catch(() => null);
      if (!r || !r.ok) { toast("Couldn't read the library ROM to make its checksum.", { kind: "bad", ms: 3000 }); return; }
      const blob = await r.blob();
      useRom(blob, picked.item.path.split("/").pop(), src, null);
    }
    const libUrl = item => {
      const parts = item.path.split("/");
      if (roomSystem !== "arcade") parts[parts.length - 1] = me.id.slice(0, 8) + "__" + parts[parts.length - 1];
      return "/roms/" + parts.map(encodeURIComponent).join("/");
    };
    function romBadge(rom, ref, host) {
      if (host) return `<span class="rom-badge ref" title="Other players compare their ROM to this one">Reference ROM</span>`;
      if (!rom) return `<span class="rom-badge none">No ROM loaded</span>`;
      if (!ref) return `<span class="rom-badge warn">Waiting for host's ROM</span>`;
      return Ghost.sameRom(rom, ref)
        ? `<span class="rom-badge ok" title="Same checksum as the host's ROM">✓ ROM Verified (Match)</span>`
        : `<span class="rom-badge warn" title="Different checksum from the host's ROM (${esc(ref.crc)}). Levels or the camera may not line up.">⚠ ROM differs (may desync)</span>`;
    }
    // Renders a ROM drop zone into box. Host: read-only reference (changed with "Change…").
    function renderRomBox(box) {
      if (!box || box.hidden) return;
      let html;
      if (romHash) {
        html = `<div class="rom-row"><span class="rom-name trunc" title="${esc(romHash.name)}">${esc(romHash.name)}</span><span class="rom-meta">Checking… ${romHash.pct}%</span></div>
          <div class="bar"><i style="width:${romHash.pct}%"></i></div>`;
      } else if (myRom) {
        html = `<div class="rom-row"><span class="rom-name trunc" title="${esc(myRom.name)}">${esc(myRom.name)}</span>${romBadge(myRom, refRom(), isHost)}</div>
          <div class="rom-meta trunc">CRC32 ${esc(myRom.crc)} · ${fmtSize(myRom.size)}</div>`;
      } else {
        html = `<div class="rom-row"><span class="rom-name muted">${isHost ? "Reading your game…" : "Drop your own copy of the game here"}</span>${isHost ? "" : romBadge(null)}</div>`;
      }
      if (!isHost) {
        const locked = phase !== "lobby" && !(phase === "loading" && !myRom);
        html += `<div class="small muted" style="margin-top:6px">Your file stays on this computer: only its checksum is shared.</div>
          ${locked ? "" : `<input type="file" class="rom-input" aria-label="Your ROM file" style="margin-top:8px">`}`;
      }
      if (box.__html === html) return;
      box.__html = html; box.innerHTML = html;
      box.querySelector(".rom-input")?.addEventListener("change", e => { const f = e.target.files[0]; if (f) useRom(f, f.name, f, f); });
    }
    function bindDrop(box) {
      const ok = () => !isHost && ghostMode() && (phase === "lobby" || (phase === "loading" && !myRom)) && !mine()?.spectator;
      box.addEventListener("dragover", e => { if (!ok()) return; e.preventDefault(); box.classList.add("dragover"); });
      box.addEventListener("dragleave", () => box.classList.remove("dragover"));
      box.addEventListener("drop", e => {
        box.classList.remove("dragover");
        if (!ok()) return;
        e.preventDefault();
        const f = e.dataTransfer.files[0]; if (f) useRom(f, f.name, f, f);
      });
    }
    bindDrop($("r-rom-box")); bindDrop($("load-rom"));
    function renderRomBoxes() {
      const seated = !!mine() && !mine().spectator;
      $("r-rom").hidden = !ghostMode() || !seated;
      renderRomBox($("r-rom-box"));
      renderRomBox($("load-rom"));
    }

    // ---- ready / spectate / start / rules
    const readyBtn = $("r-ready");
    const toggleReady = guard(readyBtn, async () => {
      const r = mine()?.ready === "ready" ? "notready" : "ready";
      sock.send({ t: "ready", state: r });
    });
    readyBtn.onclick = toggleReady;
    $("r-spectate").onclick = guard($("r-spectate"), async () => sock.send({ t: "spectate", on: !(mine()?.spectator) }));
    $("r-start").onclick = guard($("r-start"), async () => { Sfx.unlock(); sock.send({ t: "start" }); });
    $("r-system").onchange = () => { if (isHost) sock.send({ t: "rules", system: $("r-system").value }); };
    $("r-mode").onchange = () => {
      if (!isHost) return;
      const mode = $("r-mode").value === "ghost" ? "ghost" : "coop";
      sock.send({ t: "rules", mode });
      if (mode === "ghost") sock.joinMsg = { ...sock.joinMsg, local: [Math.min(...sock.joinMsg.local)] };
    };
    $("r-spec-rule").onchange = () => { if (isHost) sock.send({ t: "rules", spectators: $("r-spec-rule").checked }); };
    let dlgPicker = null;
    $("r-change-game").onclick = () => {
      if (!dlgPicker) dlgPicker = makePicker($("dlg-picker"), p => {
        picked = p;
        if (p.kind === "lib") rememberPlayed(p.item);
        Modal.close($("game-dlg"));
        sock.send({ t: "rules", game: p.name, ...(p.system ? { system: p.system } : {}) });
        sock.joinMsg = { ...sock.joinMsg, game: p.name, system: p.system || sock.joinMsg.system };
        hashHostRom();
        renderRoom();       // the hub sends no roster when the name didn't change (e.g. a promoted host re-picking it)
      });
      else dlgPicker.reset();
      Modal.open($("game-dlg"));
    };
    $("game-dlg-cancel").onclick = () => Modal.close($("game-dlg"));

    // ---- roster rendering
    function renderRoom() {
      const sys = config.systems[roomSystem] || "Unknown console";
      $("r-game").textContent = roomGame || "Untitled game"; $("r-game").title = roomGame || "";
      const host = players.find(p => p.host);
      $("r-sub").textContent = `${sys} · ${ghostMode() ? "Single-Player Ghost" : "Co-op Netplay"} · hosted by ${host ? host.name : "…"}`;
      $("r-ghost-badge").hidden = !ghostMode();
      $("r-mode").value = rules.mode || "coop";
      $("r-mode").disabled = !isHost || phase !== "lobby";
      $("r-phase").textContent = { lobby: "Lobby", countdown: "Starting", loading: "Loading", playing: "In game" }[phase];
      $("r-phase").dataset.phase = phase;
      $("r-game-pick").textContent = roomGame || "—"; $("r-game-pick").title = roomGame || "";
      $("r-system").value = roomSystem;
      $("r-system").disabled = !isHost || phase !== "lobby";
      $("r-spec-rule").checked = !!rules.spectators; $("r-spec-rule").disabled = !isHost || phase !== "lobby";
      $("r-change-game").disabled = phase !== "lobby";
      $("r-rules-who").textContent = isHost ? "You set the rules" : "The host sets the rules";
      const m = mine();
      const ready = m?.ready === "ready";
      readyBtn.hidden = isHost || !!m?.spectator;
      readyBtn.textContent = ready ? "Ready ✓" : "Ready up";
      readyBtn.classList.toggle("primary", !ready);
      readyBtn.classList.toggle("is-ready", ready);
      readyBtn.setAttribute("aria-pressed", String(ready));
      const needRom = ghostMode() && !myRom && !ready;
      if (needRom) readyBtn.textContent = romHash ? "Checking ROM…" : "Load ROM first";
      readyBtn.title = needRom ? "Load your own ROM file before you ready up" : "";
      readyBtn.dataset.lockDisabled = (phase === "lobby" || phase === "countdown") && !needRom ? "0" : "1";
      readyBtn.disabled = readyBtn.dataset.lockDisabled === "1";
      $("r-spectate").hidden = isHost;
      $("r-spectate").textContent = m?.spectator ? "Take a player slot" : "Watch instead";
      $("r-spectate").disabled = phase === "countdown" || (!m?.spectator && !rules.spectators);
      const seated = players.filter(p => !p.spectator && !p.host);
      const waiting = seated.filter(p => p.ready !== "ready");
      if (isHost) {
        const noGame = !picked;             // a promoted host has no game file yet
        const noRom = ghostMode() && !myRom;
        $("r-start").dataset.lockDisabled = phase !== "lobby" || waiting.length || noRom || noGame ? "1" : "0";
        $("r-start").disabled = $("r-start").dataset.lockDisabled === "1";
        $("r-start-help").textContent = phase !== "lobby" ? "" : noGame ? `Pick the game file with "Change…" first.` : noRom ? "Reading your ROM…" : waiting.length ? `Waiting for ${waiting.map(p => p.name).join(", ")}` : seated.length ? "Everyone is ready." : "You can start alone or wait for friends.";
      } else {
        $("r-start-help").textContent = phase === "lobby" ? (waiting.length ? `${seated.length - waiting.length}/${seated.length} ready` : "Waiting for the host to start") : "";
      }
      $("r-start-help").title = $("r-start-help").textContent;
      renderRomBoxes();
      renderSlots();
      renderLoadActions();
    }

    function slotCard(s) {
      const p = players.find(x => x.slot === s && !x.spectator);
      const localSeat = reserved.includes(s) && !p;
      const el = document.createElement("div");
      el.className = "slotcard";
      if (!p && !localSeat) {
        el.classList.add("empty");
        const canMove = !isHost && phase !== "countdown" && mine() && (mine().slot !== s);
        el.innerHTML = `<span class="slotnum">P${s + 1}</span><span class="muted grow">Open</span>
          ${canMove ? `<button class="small" data-move="${s}">Move here</button>` : ""}
          ${isHost && phase !== "countdown" && swapFrom != null && swapFrom !== s ? `<button class="small" data-swapto="${s}">Move P${swapFrom + 1} here</button>` : ""}`;
      } else if (localSeat) {
        const host = players.find(x => x.host);
        el.innerHTML = `<span class="slotnum">P${s + 1}</span>
          <div class="grow min0"><div class="pname trunc">${esc(host?.name || "Host")}'s PC</div><div class="small muted">Local player</div></div>
          <span class="rstate ${phaseStateClass(host)}">${stateLabel(host, true)}</span>`;
      } else {
        const isMe = p.id === myId();
        const muted = voice.muted.has(p.key);
        const ping = p.rtt;
        el.classList.toggle("me", isMe);
        el.innerHTML = `<span class="slotnum">P${s + 1}</span>
          <div class="grow min0">
            <div class="pname-row">
              <span class="pname trunc" title="${esc(p.name)}">${esc(p.name)}</span>
              ${p.voice ? `<span class="vu ${muted ? "muted" : ""}" data-key="${esc(p.key)}" title="${muted ? "Muted" : "Voice"}"><i></i><i></i><i></i><i></i></span>` : ""}
            </div>
            <div class="small muted trunc"><span class="id">#${esc(prettyId(p.key).slice(0, 9))}</span>${p.host ? " · Host" : ""}${isMe ? " · You" : ""}</div>
          </div>
          <span class="ping ${pingClass(ping)}" title="Round trip to the hub">${pingLabel(ping)}</span>
          ${p.voice && !isMe ? `<button class="small icon mute ${muted ? "on" : ""}" data-mute="${esc(p.key)}" aria-pressed="${muted}" title="${muted ? "Unmute" : "Mute"} ${esc(p.name)} for you" aria-label="${muted ? "Unmute" : "Mute"} ${esc(p.name)}">${muted ? "🔇" : "🔊"}</button>` : ""}
          ${ghostMode() && (p.rom || p.host) ? romBadge(p.rom, refRom(), p.host) : ""}
          <span class="rstate ${phaseStateClass(p)}">${stateLabel(p)}</span>
          ${isHost && !p.host && phase !== "countdown" ? `<button class="small" data-swap="${s}" aria-pressed="${swapFrom === s}">${swapFrom === s ? "Cancel" : swapFrom != null ? `Swap with P${swapFrom + 1}` : "Swap"}</button>` : ""}`;
        if (phase === "loading" || (phase === "playing" && p.progress < 100)) {
          el.insertAdjacentHTML("beforeend", `<div class="bar"><i style="width:${p.progress}%"></i></div>`);
        }
      }
      return el;
    }
    const stateLabel = (p, local) => {
      if (!p) return "—";
      if (p.away) return "Reconnecting…";      // seat held by the hub for 30 s
      if (p.host && phase === "lobby") return local ? "Host" : "Host";
      if (p.ready === "loading") return `Loading ${p.progress}%`;
      if (ghostMode() && phase === "lobby" && !p.rom && !p.host) return "No ROM loaded";
      return p.ready === "ready" ? "Ready" : "Not ready";
    };
    const phaseStateClass = p => !p ? "" : p.away ? "loading" : p.ready === "ready" || (p.host && phase === "lobby") ? "ready" : p.ready === "loading" ? "loading" : "notready";

    let swapFrom = null;
    function renderSlots() {
      const box = $("r-slots"); box.textContent = "";
      for (let s = 0; s < config.maxPlayers; s++) box.appendChild(slotCard(s));
      const specs = players.filter(p => p.spectator);
      $("r-specs").hidden = !specs.length;
      $("r-spec-list").innerHTML = specs.map(p => `<li><span class="pname trunc grow" title="${esc(p.name)}">${esc(p.name)}</span>
        ${p.voice ? `<span class="vu" data-key="${esc(p.key)}"><i></i><i></i><i></i><i></i></span>` : ""}
        <span class="ping ${pingClass(p.rtt)}">${pingLabel(p.rtt)}</span></li>`).join("");
      $("r-count").textContent = `${players.filter(p => !p.spectator).length + reserved.filter(s => !players.some(p => p.slot === s)).length}/${config.maxPlayers}`;
      box.querySelectorAll("[data-move]").forEach(b => b.onclick = guard(b, async () => sock.send({ t: "slot", slot: Number(b.dataset.move) })));
      box.querySelectorAll("[data-mute]").forEach(b => b.onclick = () => { voice.toggleMute(b.dataset.mute); });
      box.querySelectorAll("[data-swap]").forEach(b => b.onclick = () => {
        const s = Number(b.dataset.swap);
        if (swapFrom === s) swapFrom = null;
        else if (swapFrom == null) swapFrom = s;
        else { sock.send({ t: "swap", a: swapFrom, b: s }); swapFrom = null; }
        renderSlots();
      });
      box.querySelectorAll("[data-swapto]").forEach(b => b.onclick = () => { sock.send({ t: "swap", a: swapFrom, b: Number(b.dataset.swapto) }); swapFrom = null; renderSlots(); });
      game?.redraw();
      if (Modal.isOpen($("ghost-panel"))) renderGhostPanel();
    }

    // ---- countdown (server-timed; freezes and aborts if anyone unreadies or drops)
    const cd = $("countdown");
    let cdTimer = 0;
    function startCountdown(ms) {
      clearInterval(cdTimer);
      Sfx.unlock();
      const end = performance.now() + ms;
      cd.classList.remove("frozen");
      $("cd-sub").textContent = ghostMode() && inGame ? "Runs start on GO!" : "Match starting";
      $("cd-abort").textContent = isHost ? "Abort" : "Not ready";
      if (!Modal.isOpen(cd)) Modal.open(cd, { focus: "#cd-abort" });
      let lastN = null;
      const tick = () => {
        const left = end - performance.now();
        const n = Math.max(0, Math.ceil(left / 1000));
        if (n !== lastN) {
          lastN = n;
          $("cd-num").textContent = n > 0 ? n : "GO!";
          $("cd-num").classList.remove("pop"); void $("cd-num").offsetWidth; $("cd-num").classList.add("pop");
          n > 0 ? Sfx.tick() : Sfx.go();
          if (n === 0 && ghostMode()) game?.go?.();      // everyone's run starts on their own GO
        }
        if (left <= 0) clearInterval(cdTimer);
      };
      tick(); cdTimer = setInterval(tick, 50);
    }
    function freezeCountdown(reason) {
      clearInterval(cdTimer);
      if (!Modal.isOpen(cd)) return;
      cd.classList.add("frozen");
      $("cd-sub").textContent = reason || "Countdown stopped";
      Sfx.warn();
      setTimeout(() => { if (cd.classList.contains("frozen")) Modal.close(cd); }, 1600);
    }
    $("cd-abort").onclick = guard($("cd-abort"), async () => {
      if (isHost) sock.send({ t: "abort" }); else sock.send({ t: "ready", state: "notready" });
    });

    // ---- phase changes
    let inGame = false;
    function onPhase(next) {
      const prev = phase; phase = next;
      if (next === "loading" || next === "playing") {
        if (Modal.isOpen(cd)) { clearInterval(cdTimer); Modal.close(cd); }
        if (!inGame) { inGame = true; enterGame(); }
      }
      if (next === "playing" && prev !== "playing") { game?.started(); offerResume(); }
      if (inGame) $("loadboard").hidden = next === "playing" || (next === "countdown" && ghostMode());
      renderRoom();
      renderLoadBoard();
    }
    function enterGame() {
      document.body.classList.add("playing");
      $("hub").hidden = true; $("game").hidden = false;
      $("g-title").textContent = roomGame; $("g-title").title = roomGame;
      $("g-code").textContent = code;
      $("g-invite").onclick = () => copyInvite(code, "Copied! (password not included)");
      $("g-full").onclick = () => { if (document.fullscreenElement) document.exitFullscreen(); else $("game").requestFullscreen?.().catch(() => {}); };
      $("g-leave").onclick = () => {
        if (isHost && !confirm("Stop hosting? The match ends for everyone and hosting passes to another player.")) return;
        leave();
      };
      $("loadboard").hidden = phase === "playing";
      $("g-ghost-badge").hidden = !ghostMode();
      $("g-ghosts").hidden = !ghostMode();
      $("g-ghost-toggle").hidden = !ghostMode();
      $("g-save").hidden = $("g-saves").hidden = !canSave();
      $("g-chat-drawer").appendChild($("chat"));
      $("chat-close").hidden = false;
      renderGhostToggle();
      $("load-help").textContent = ghostMode()
        ? "Everyone boots their own copy of the game. The 3-2-1 starts when everyone is at 100%."
        : "The match starts when everyone is at 100%.";
      if (!game) {
        if (ghostMode()) game = mine()?.spectator ? makeGhostWatch() : makeEmuGame({ ghost: true });
        else game = isHost ? makeEmuGame({ ghost: false }) : makeGuestGame();
        if (lastStream) game.stream?.(lastStream);
      }
      game.load();
      renderLoadActions();
    }
    // Ghost mode after an aborted countdown: guests ready up again, the host restarts the countdown.
    function renderLoadActions() {
      const show = inGame && ghostMode() && phase === "loading" && staged;
      $("load-actions").hidden = !show;
      if (!show) return;
      const m = mine();
      const lb = $("lb-ready"), ready = m?.ready === "ready";
      lb.hidden = isHost || !!m?.spectator;
      lb.textContent = ready ? "Ready ✓" : "Ready up";
      lb.classList.toggle("is-ready", ready); lb.setAttribute("aria-pressed", String(ready));
      lb.dataset.lockDisabled = (m?.progress ?? 0) < 100 ? "1" : "0"; lb.disabled = lb.dataset.lockDisabled === "1";
      const st = $("lb-start");
      st.hidden = !isHost;
      const loading = players.filter(p => p.progress < 100), waiting = players.filter(p => !p.spectator && !p.host && p.ready !== "ready");
      st.dataset.lockDisabled = loading.length || waiting.length ? "1" : "0"; st.disabled = st.dataset.lockDisabled === "1";
      $("load-help").textContent = loading.length ? `Loading: ${loading.map(p => p.name).join(", ")}`
        : waiting.length ? `Countdown stopped. Waiting for ${waiting.map(p => p.name).join(", ")} to ready up.`
        : isHost ? "Everyone is ready. Start the countdown when you are." : "Everyone is ready. Waiting for the host.";
    }
    $("lb-ready").onclick = guard($("lb-ready"), async () => sock.send({ t: "ready", state: mine()?.ready === "ready" ? "notready" : "ready" }));
    $("lb-start").onclick = guard($("lb-start"), async () => { Sfx.unlock(); sock.send({ t: "start" }); });
    function renderLoadBoard() {
      if ($("loadboard").hidden) return;
      const rows = [];
      for (const p of players.slice().sort((a, b) => (a.spectator - b.spectator) || a.slot - b.slot)) {
        const label = p.spectator ? "Watching" : `P${p.slot + 1}`;
        rows.push(`<div class="lrow"><span class="slotnum">${label}</span><span class="pname trunc" title="${esc(p.name)}">${esc(p.name)}</span>
          <div class="bar grow"><i style="width:${p.progress}%"></i></div><span class="pct">${p.progress}%</span></div>`);
      }
      $("load-rows").innerHTML = rows.join("");
    }

    // ---- progress reporting (rate-limited)
    let lastPct = -1, pctTimer = 0, pendingPct = 0;
    function reportProgress(pct) {
      pct = Math.max(0, Math.min(100, Math.round(pct)));
      if (pct <= lastPct && pct !== 100) return;
      pendingPct = Math.max(pendingPct, pct);
      if (pctTimer) return;
      const flush = () => {
        pctTimer = 0;
        if (pendingPct === lastPct) return;
        lastPct = pendingPct;
        sock.send({ t: "progress", pct: lastPct });
        if (isHost) sock.joinMsg = { ...sock.joinMsg, progress: lastPct };
      };
      if (pct === 100) flush(); else pctTimer = setTimeout(flush, 200);
    }

    // ---- socket handlers
    let awayIds = new Set(), hostAwayMsg = false;
    sock.on("roster", m => {
      players = m.players || [];
      const wasGhost = ghostMode();
      rules = m.rules || rules; reserved = m.reserved || reserved; staged = !!m.staged;
      if (ghostMode() && !wasGhost) hashHostRom();
      if (m.game != null) roomGame = m.game;
      if (m.system) { if (m.system !== roomSystem) game?.systemChanged?.(m.system); roomSystem = m.system; }
      if (m.phase && m.phase !== phase) onPhase(m.phase); else renderRoom();
      if (isHost) {
        game?.roster?.(players);
        net.setGuests(players.filter(p => !p.host).map(p => p.id));
        net.setVoiceOn(players.filter(p => !p.host && p.voice).map(p => p.id));
        net.setGhostOn(players.filter(p => !p.host && p.ghost).map(p => p.id));
      } else if (inGame && phase !== "lobby") {
        const host = players.find(p => p.host);
        if (m.hostId == null || host?.away) { message("The host disconnected. Waiting for them to come back…", true); hostAwayMsg = true; }
        else if (hostAwayMsg) { message("", false); hostAwayMsg = false; }
      }
      const nowAway = new Set(players.filter(p => p.away && p.id !== myId()).map(p => p.id));
      for (const id of nowAway) if (!awayIds.has(id)) toast(`${players.find(p => p.id === id).name} lost connection. Holding their seat…`, { ms: 3000 });
      for (const id of awayIds) if (!nowAway.has(id)) { const p = players.find(x => x.id === id); toast(p ? `${p.name} is back.` : "A player didn't come back in time.", { kind: p ? "ok" : undefined, ms: 2500 }); }
      awayIds = nowAway;
      syncGhosts();
      renderLoadBoard();
      renderLoadActions();
    });
    // A running match went back to the lobby (host migration): the game lived in the old host's browser,
    // so reload into the lobby with our seat kept.
    sock.on("phase", m => { if (m.phase === "lobby" && inGame) return handOff(sock, code); onPhase(m.phase); });
    sock.on("promoted", () => handOff(sock, code));
    sock.on("countdown", m => {
      if (m.cancelled) { freezeCountdown(m.reason); return; }
      startCountdown(m.ms || 3000);
    });
    sock.on("notice", m => {
      showErr($("r-notice"), m.msg);
      toast(m.msg, { ms: 3000 });
      clearTimeout(sock.noticeT); sock.noticeT = setTimeout(() => showErr($("r-notice"), ""), 6000);
    });
    sock.on("signal", m => net.onSignal(m.from, m.data));
    // A hub drop doesn't break the WebRTC game link, so play goes on if it's still up; the hub holds our seat for 30 s.
    let dropOverlay = false;
    sock.on("dropped", () => {
      toast("Connection to the hub lost. Reconnecting…", { kind: "bad", ms: 2500 });
      if (inGame && !isHost && !net.connected) { message("Connection to the hub lost. Reconnecting…", true); dropOverlay = true; }
    });
    sock.on("rejoined", m => {
      toast(m.resumed ? "Reconnected. Your seat was kept." : "Reconnected.", { kind: "ok" });
      if (dropOverlay) { message("", false); dropOverlay = false; }
      if (myGhost) { if (isHost) net.setHostGhost(myGhost, myId()); sock.send({ t: "ghost", on: true }); }
      if (lastPct >= 0) { const p = lastPct; lastPct = -1; reportProgress(p); }
      sock.send({ t: "voice", on: !!voice.mic });
    });
    sock.on("fatal", m => {
      // No inline handlers (the Content-Security-Policy blocks them): wire the button up after rendering.
      const text = esc(m.msg || "You were disconnected from the lobby.") + ' <div style="margin-top:10px"><button data-act="hub">Back to the hub</button></div>';
      if (inGame) { message(text, true); $("g-msg").querySelector("[data-act=hub]").onclick = () => location.replace("/"); }
      else { showErr($("r-notice"), m.msg || "You were disconnected from the lobby."); }
    });
    if (!isHost) sock.joinMsg = { t: "join", role: "guest", room: code, password: opts.password, spectate: false };
    if (isHost) hashHostRom();
    // Reconnects should keep the seat type we have now.
    const syncJoinMsg = () => { if (!isHost) sock.joinMsg = { ...sock.joinMsg, spectate: !!mine()?.spectator, slot: mine()?.slot }; };
    setInterval(syncJoinMsg, 1000);

    // ---- ghost overlay: other players' runs drawn translucent over this player's game
    function ensureComp() {
      if (comp) return comp;
      comp = new Ghost.Compositor($("stage"));
      comp.setOptions(Settings.get("ghost"));
      queueMicrotask(syncGhosts);           // ghosts that arrived before the game view existed
      return comp;
    }
    function syncGhosts() {
      if (!comp) return;
      const follow = game?.following?.() ?? null;
      for (const [id, track] of ghostTracks) {
        const p = players.find(x => x.id === id);
        if (!p || id === myId() || id === follow || pips.has(id)) { comp.set(id, null); continue; }
        comp.set(id, track, { slot: p.slot, name: p.name });
      }
      for (const g of comp.list()) if (!ghostTracks.has(g.id)) comp.set(g.id, null);
      for (const [id, w] of pips) {
        const p = players.find(x => x.id === id);
        if (!p || p.spectator) { closePip(id); continue; }
        w.setTrack(ghostTracks.get(id) || null);
        w.setName(p);
      }
      game?.ghostsChanged?.();
      if (Modal.isOpen($("ghost-panel"))) renderGhostPanel();
    }
    const gp = $("ghost-panel");
    const saveGhost = patch => { Settings.patch("ghost", patch); comp?.setOptions(Settings.get("ghost")); renderPlayersNow(); };
    function renderGhostPanel() {
      const g = Settings.get("ghost");
      $("gp-opacity").value = Math.round(g.opacity * 100);
      $("gp-opacity-val").textContent = Math.round(g.opacity * 100) + "%";
      $("gp-tint").checked = !!g.tint;
      $("gp-show").checked = g.enabled !== false;
      $("gp-blend").value = g.blend === "screen" ? "screen" : "normal";
      const others = players.filter(p => !p.spectator && p.id !== myId()).sort((a, b) => a.slot - b.slot);
      const follow = game?.following?.();
      const box = $("gp-slots");
      const opts = c => Ghost.PALETTE.map(o => `<option value="${o.hex}" ${o.hex === c ? "selected" : ""}>${o.label}</option>`).join("");
      box.innerHTML = others.length ? others.map(p => {
        const c = g.colors[p.slot] ?? "";
        return `<div class="gp-slot"><span class="slotnum">P${p.slot + 1}</span>
          <span class="swatch ${c ? "" : "none"}" style="${c ? `background:${c}` : ""}"></span>
          <span class="pname trunc" title="${esc(p.name)}">${esc(p.name)}${ghostTracks.has(p.id) ? "" : ' <span class="muted small">(no video yet)</span>'}</span>
          ${game?.follow ? `<button class="small ${follow === p.id ? "on" : ""}" data-follow="${p.id}" aria-pressed="${follow === p.id}" title="Show this player solid">Follow</button>` : ""}
          <button class="small" data-pip="${p.id}" aria-pressed="${pips.has(p.id)}" title="${pips.has(p.id) ? "Put back as a ghost" : "Pop out into its own window"}">${pips.has(p.id) ? "Pop in" : "Pop out"}</button>
          <select data-color="${p.slot}" aria-label="Ghost color for P${p.slot + 1}">${opts(c)}</select>
          <input type="checkbox" data-show="${p.slot}" ${g.hidden.includes(p.slot) ? "" : "checked"} aria-label="Show P${p.slot + 1}'s ghost" title="Show ghost">
        </div>`;
      }).join("") : '<div class="small muted">No other players yet.</div>';
      box.querySelectorAll("[data-color]").forEach(sel => sel.onchange = () => { saveGhost({ colors: { ...Settings.get("ghost").colors, [sel.dataset.color]: sel.value } }); renderGhostPanel(); });
      box.querySelectorAll("[data-show]").forEach(cb => cb.onchange = () => {
        const s = Number(cb.dataset.show), hidden = new Set(Settings.get("ghost").hidden);
        cb.checked ? hidden.delete(s) : hidden.add(s);
        saveGhost({ hidden: [...hidden] });
      });
      box.querySelectorAll("[data-follow]").forEach(b => b.onclick = () => { game.follow(Number(b.dataset.follow)); renderGhostPanel(); });
      box.querySelectorAll("[data-pip]").forEach(b => b.onclick = () => { const id = Number(b.dataset.pip); pips.has(id) ? closePip(id) : openPip(id); renderGhostPanel(); });
    }
    $("gp-show").addEventListener("change", () => setGhostsOn($("gp-show").checked));
    $("gp-opacity").addEventListener("input", () => { const v = Number($("gp-opacity").value) / 100; $("gp-opacity-val").textContent = Math.round(v * 100) + "%"; saveGhost({ opacity: v }); });
    $("gp-tint").addEventListener("change", () => saveGhost({ tint: $("gp-tint").checked }));
    $("gp-blend").addEventListener("change", () => saveGhost({ blend: $("gp-blend").value }));
    const closeGp = () => Modal.close(gp);
    $("gp-close").onclick = closeGp;
    $("g-ghosts").onclick = () => {
      if (Modal.isOpen(gp)) return closeGp();
      renderGhostPanel();
      $("g-ghosts").setAttribute("aria-expanded", "true");
      Modal.open(gp, { focus: "#gp-opacity", onClose: () => $("g-ghosts").setAttribute("aria-expanded", "false") });
    };
    const renderPlayersNow = () => game?.redraw();
    const ghostColors = () => ghostMode() && Settings.get("ghost").tint ? Settings.get("ghost").colors : null;
    const ghostHud = () => ghostMode() ? { hidden: new Set(Settings.get("ghost").hidden), pipped: new Set(pips.keys()) } : null;

    // Master on/off: one click (HUD button) or the O key.
    function renderGhostToggle() {
      const on = Settings.get("ghost").enabled !== false, b = $("g-ghost-toggle");
      b.setAttribute("aria-pressed", String(on));
      b.textContent = on ? "👻 Ghosts on" : "👻 Ghosts off";
      if (Modal.isOpen(gp)) $("gp-show").checked = on;
    }
    function setGhostsOn(on) { saveGhost({ enabled: on }); renderGhostToggle(); }
    $("g-ghost-toggle").onclick = () => setGhostsOn(Settings.get("ghost").enabled === false);
    window.addEventListener("keydown", e => {
      if (e.code !== "KeyO" || e.repeat || e.ctrlKey || e.metaKey || e.altKey || !inGame || !ghostMode()) return;
      const t = e.target;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable)) return;
      e.preventDefault();
      setGhostsOn(Settings.get("ghost").enabled === false);
      toast(Settings.get("ghost").enabled === false ? "Ghosts hidden (O to show)" : "Ghosts shown", { ms: 1000 });
    });
    // One player's ghost on/off (click their chip in the top bar). A popped-out player is put back instead.
    function toggleGhost(id) {
      if (pips.has(id)) { closePip(id); return; }
      const p = players.find(x => x.id === id); if (!p) return;
      const hidden = new Set(Settings.get("ghost").hidden);
      hidden.has(p.slot) ? hidden.delete(p.slot) : hidden.add(p.slot);
      saveGhost({ hidden: [...hidden] });
      if (Modal.isOpen(gp)) renderGhostPanel();
    }
    // Chips: click = toggle that ghost; drag onto the game = pop out into a picture-in-picture window.
    const chipBox = $("g-players");
    chipBox.addEventListener("pointerdown", e => {
      const chip = e.target.closest(".pchip[data-gid]");
      if (!chip || !ghostMode() || e.button !== 0) return;
      e.preventDefault();
      const id = Number(chip.dataset.gid), sx = e.clientX, sy = e.clientY;
      let proxy = null;
      const stage = $("stage"), drop = $("pip-drop");
      const overStage = ev => { const r = stage.getBoundingClientRect(); return ev.clientX >= r.left && ev.clientX <= r.right && ev.clientY >= r.top && ev.clientY <= r.bottom; };
      const move = ev => {
        if (!proxy && Math.hypot(ev.clientX - sx, ev.clientY - sy) > 6) {
          hudDrag.on = true;
          proxy = chip.cloneNode(true); proxy.classList.add("chip-proxy"); document.body.appendChild(proxy);
          drop.hidden = false;
        }
        if (proxy) { proxy.style.left = ev.clientX + "px"; proxy.style.top = ev.clientY + "px"; drop.style.opacity = overStage(ev) ? "1" : ".4"; }
      };
      const end = ev => {
        window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", end); window.removeEventListener("pointercancel", end);
        hudDrag.on = false;
        drop.hidden = true;
        if (proxy) { proxy.remove(); if (ev.type === "pointerup" && overStage(ev)) openPip(id, ev.clientX, ev.clientY); }
        else if (ev.type === "pointerup") toggleGhost(id);
        renderPlayersNow();
      };
      window.addEventListener("pointermove", move); window.addEventListener("pointerup", end); window.addEventListener("pointercancel", end);
    });
    chipBox.addEventListener("keydown", e => {
      const chip = e.target.closest(".pchip[data-gid]"); if (!chip) return;
      const id = Number(chip.dataset.gid);
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggleGhost(id); }
      else if (e.key === "p" || e.key === "P") { e.preventDefault(); pips.has(id) ? closePip(id) : openPip(id); }
    });

    // ---- picture-in-picture windows: a partner's run, solid, movable and resizable
    const pips = new Map();   // playerId -> window api
    const pipLayer = $("pip-layer");
    const savePipGeo = (slot, el) => {
      const L = pipLayer.getBoundingClientRect();
      const r = el.getBoundingClientRect();
      Settings.patch("ghost", { pip: { ...Settings.get("ghost").pip, [slot]: { x: (r.left - L.left) / L.width, y: (r.top - L.top) / L.height, w: r.width / L.width } } });
    };
    function clampPip(el) {
      const L = pipLayer.getBoundingClientRect();
      const w = Math.min(el.offsetWidth, L.width), h = Math.min(el.offsetHeight, L.height);
      el.style.left = Math.max(0, Math.min(L.width - w, parseFloat(el.style.left) || 0)) + "px";
      el.style.top = Math.max(0, Math.min(L.height - h, parseFloat(el.style.top) || 0)) + "px";
    }
    function dragWith(handle, onMove, onEnd) {
      handle.addEventListener("pointerdown", e => {
        if (e.button !== 0 || e.target.closest("button")) return;
        e.preventDefault();
        handle.setPointerCapture(e.pointerId);
        const sx = e.clientX, sy = e.clientY;
        const mv = ev => onMove(ev.clientX - sx, ev.clientY - sy, true);
        const up = () => { handle.removeEventListener("pointermove", mv); handle.removeEventListener("pointerup", up); handle.removeEventListener("pointercancel", up); onEnd(); };
        onMove(0, 0, false);
        handle.addEventListener("pointermove", mv); handle.addEventListener("pointerup", up); handle.addEventListener("pointercancel", up);
      });
    }
    function openPip(id, cx, cy) {
      if (pips.has(id)) return;
      const p = players.find(x => x.id === id); if (!p || p.spectator) return;
      const el = document.createElement("div");
      el.className = "pip"; el.setAttribute("role", "group");
      el.innerHTML = `<div class="pip-bar" title="Drag to move">
          <span class="slotnum">P${p.slot + 1}</span><span class="pname trunc"></span>
          <button class="small icon" data-act="native" title="Separate window that stays on top of other apps" aria-label="Open in a separate window">⧉</button>
          <button class="small icon" data-act="close" title="Put back as a ghost" aria-label="Close and put back as a ghost">✕</button>
        </div>
        <video muted autoplay playsinline></video>
        <div class="pip-resize" title="Drag to resize"></div>`;
      pipLayer.appendChild(el);
      const video = el.querySelector("video");
      const L = pipLayer.getBoundingClientRect();
      const geo = Settings.get("ghost").pip?.[p.slot];
      const w = Math.max(180, Math.min(L.width * 0.9, geo ? geo.w * L.width : Math.max(240, L.width * 0.28)));
      el.style.width = w + "px";
      const h = el.offsetHeight;
      if (cx != null) { el.style.left = (cx - L.left - w / 2) + "px"; el.style.top = (cy - L.top - 14) + "px"; }
      else if (geo) { el.style.left = geo.x * L.width + "px"; el.style.top = geo.y * L.height + "px"; }
      else { el.style.left = (L.width - w - 12) + "px"; el.style.top = (L.height - h - 12) + "px"; }
      clampPip(el);
      // move
      let ox = 0, oy = 0;
      dragWith(el.querySelector(".pip-bar"), (dx, dy, moving) => {
        if (!moving) { ox = parseFloat(el.style.left); oy = parseFloat(el.style.top); return; }
        el.style.left = ox + dx + "px"; el.style.top = oy + dy + "px"; clampPip(el);
      }, () => savePipGeo(p.slot, el));
      // resize (keeps the picture's aspect; height follows the video)
      let ow = 0;
      dragWith(el.querySelector(".pip-resize"), (dx, dy, moving) => {
        if (!moving) { ow = el.offsetWidth; return; }
        const max = pipLayer.getBoundingClientRect().width - parseFloat(el.style.left);
        el.style.width = Math.max(160, Math.min(max, ow + Math.max(dx, dy * 4 / 3))) + "px"; clampPip(el);
      }, () => savePipGeo(p.slot, el));
      video.addEventListener("resize", () => { if (video.videoWidth) video.style.aspectRatio = `${video.videoWidth} / ${video.videoHeight}`; clampPip(el); });
      // the browser's own floating window (works over other apps / on a second monitor)
      const nativeBtn = el.querySelector("[data-act=native]");
      nativeBtn.hidden = !document.pictureInPictureEnabled;
      nativeBtn.onclick = () => video.requestPictureInPicture?.().catch(() => toast("This browser can't pop the video out.", { kind: "bad" }));
      video.addEventListener("enterpictureinpicture", () => el.classList.add("native"));
      video.addEventListener("leavepictureinpicture", () => el.classList.remove("native"));
      el.querySelector("[data-act=close]").onclick = () => closePip(id);
      let cur = null;
      const api = {
        el, video,
        setTrack(t) { if (t === cur) return; cur = t; video.srcObject = t ? new MediaStream([t]) : null; if (t) video.play().catch(() => {}); },
        setName(pl) { const n = el.querySelector(".pname"); n.textContent = pl.name; n.title = pl.name; el.setAttribute("aria-label", `P${pl.slot + 1} ${pl.name}`); },
      };
      pips.set(id, api);
      api.setName(p);
      syncGhosts(); renderPlayersNow();
    }
    function closePip(id) {
      const w = pips.get(id); if (!w) return;
      pips.delete(id);
      if (document.pictureInPictureElement === w.video) document.exitPictureInPicture().catch(() => {});
      w.video.srcObject = null; w.el.remove();
      syncGhosts(); renderPlayersNow();
      if (Modal.isOpen(gp)) renderGhostPanel();
    }
    window.addEventListener("resize", () => pips.forEach(w => clampPip(w.el)));

    // Late join: the match is already running.
    renderRoom();
    if (phase === "loading" || phase === "playing") { inGame = true; enterGame(); }

    // ============================================================ emulator game
    // Co-op host: runs the game, streams it, applies guests' inputs.
    // Ghost (any seated player): runs their own ROM, sends a low-rate ghost of their screen, starts on GO.
    function makeEmuGame({ ghost }) {
      const local = ghost ? [0] : opts.params.local.slice().sort((a, b) => a - b);
      const guestSlot = new Map();       // guestId -> slot
      const applied = new Map();         // slot -> last values sent to the core
      let gm = null, loaded = false, waitingRom = false, started = false, wentGo = false, goPending = false;
      const zero = () => new Array(Input.N).fill(0);
      function apply(slot, values) {
        if (!gm) return;
        const prev = applied.get(slot) || zero();
        for (let i = 0; i < Input.N; i++) if (values[i] !== prev[i]) { try { gm.simulateInput(slot, i, values[i]); } catch {} }
        applied.set(slot, values.slice());
      }
      const pads = local.map(slot => new Input.Pad(v => apply(slot, v)));
      let knownGuests = null;
      const api = {
        input(id, v) { if (ghost) return; const s = guestSlot.get(id); if (s !== undefined && s >= 0 && !local.includes(s)) apply(s, v); },
        roster(list) {
          if (ghost) { api.redraw(); return; }
          const before = new Map(guestSlot);
          guestSlot.clear();
          for (const p of list) if (!p.host) guestSlot.set(p.id, p.slot);
          for (const [id, slot] of before) if (slot >= 0 && (!guestSlot.has(id) || guestSlot.get(id) !== slot)) apply(slot, zero());
          if (knownGuests) for (const [id] of guestSlot) if (!knownGuests.has(id)) toast(`${list.find(p => p.id === id)?.name || "A player"} joined.`);
          knownGuests = new Set(guestSlot.keys());
          api.redraw();
        },
        redraw() { if (inGame) renderPlayers(players, { local: ghost ? [] : local, hostName: me.name, netState: isHost ? id => net.state(id) : null, voice, colors: ghostColors(), me: myId(), ghost: ghostHud() }); },
        message, started() {},
        romReady() { if (waitingRom) { waitingRom = false; $("load-rom").hidden = true; api.load(); } },
        go() {
          if (!ghost || wentGo) return;
          if (!started) { goPending = true; return; }
          wentGo = true;
          try { window.EJS_emulator.play(); } catch {}
        },
        load() {
          if (loaded) return;
          if (ghost && !myRom && !(isHost && picked)) {      // late joiner: needs their own ROM first
            waitingRom = true;
            $("load-rom").hidden = false; renderRomBoxes();
            $("load-help").textContent = "Drop your own copy of the game to join the run.";
            return;
          }
          loaded = true;
          $("ejs-wrap").hidden = false;
          if (ghost) { const c = ensureComp(); c.setTarget(() => window.EJS_emulator?.canvas || null); }
          // Local controllers; lag equalization only matters with two or more players on this computer.
          // Ghost mode: one player per computer, so any keyboard layout or gamepad drives P1.
          const lagFor = Settings.get("equalizeLag") && local.length > 1
            ? Input.lagPlan(["keyboard", ...Array.from(navigator.getGamepads?.() || []).filter(Boolean).map(g => g.id)]) : null;
          Input.attachKeyboard(roomSystem, { A: pads[0], B: pads[1] }, { lagFor });
          Input.attachGamepads(roomSystem, ghost ? () => pads[0] : order => pads[order] || null, { lagFor });
          const help = Input.KEY_HELP[Input.scheme(roomSystem)];
          const helpText = `<div class="small muted" style="margin-top:8px">P1 keys: ${esc(help.A)}${pads[1] ? `<br>P2 keys: ${esc(help.B)}` : ""}</div>`;
          // Capture the game's audio for the guests (must happen before the emulator makes its AudioContext).
          if (!ghost) Net.tapPageAudio(track => net.addTrack(track));
          const tag = me.id.slice(0, 8) + "__";           // separate saves per account on a shared computer
          const arcade = roomSystem === "arcade";          // arcade romsets must keep their exact file name
          const p = ghost && !isHost ? { kind: "file", file: myRom.file } : picked;
          if (p.kind === "lib") {
            const parts = p.item.path.split("/");
            if (!arcade) parts[parts.length - 1] = tag + parts[parts.length - 1];
            window.EJS_gameUrl = "/roms/" + parts.map(encodeURIComponent).join("/");
          } else {
            window.EJS_gameUrl = URL.createObjectURL(p.file);
            window.EJS_gameName = (arcade ? "" : tag) + p.file.name;
          }
          const noKeys = {};
          for (let pl = 0; pl < 4; pl++) { noKeys[pl] = {}; for (let i = 0; i < 30; i++) noKeys[pl][i] = { value: "", value2: "" }; }
          Object.assign(window, {
            EJS_player: "#ejs-player", EJS_core: roomSystem, EJS_pathtodata: "/data/", EJS_startOnLoaded: true,
            EJS_threads: !!window.crossOriginIsolated && typeof SharedArrayBuffer === "function",
            EJS_color: "#ffd60a", EJS_backgroundColor: "#000000", EJS_language: "en-US", EJS_disableAutoLang: false,
            EJS_volume: Settings.get("volume"),
            EJS_defaultControls: noKeys,     // Retro Hub handles keyboards and gamepads itself (local seats + guests)
            EJS_Buttons: { netplay: false },
            EJS_onGameStart: () => {
              gm = window.EJS_emulator.gameManager;
              if (ghost) {
                // Hold at the first frame until GO so every run starts together (late joiners start at once).
                if (phase !== "playing" && !goPending) { try { window.EJS_emulator.pause(); } catch {} }
                else wentGo = true;
                started = true;
                if (goPending) { goPending = false; api.go(); }
                myGhost = window.EJS_emulator.canvas.captureStream(Net.GHOST_FPS).getVideoTracks()[0] || null;
                if (myGhost) {
                  try { myGhost.contentHint = "motion"; } catch {}
                  isHost ? net.setHostGhost(myGhost, myId()) : net.setGhost(myGhost);
                  sock.send({ t: "ghost", on: true });
                }
              } else {
                const stream = window.EJS_emulator.canvas.captureStream(60);
                stream.getVideoTracks().forEach(t => net.addTrack(t));
              }
              pads.forEach((pad, i) => apply(local[i], pad.values));
              reportProgress(100);
              obs?.disconnect();
              api.helpText = helpText;
            },
          });
          // EmulatorJS has no progress API: read the percentage from its loading text.
          reportProgress(2);
          let obs = null;
          const watch = () => {
            const el = document.querySelector("#ejs-player .ejs_loading_text");
            if (!el) return setTimeout(watch, 100);
            const read = () => {
              const t = el.textContent || "", n = Number((/(\d{1,3})%/.exec(t) || [])[1]);
              if (/error|failed/i.test(t) || el.classList.contains("ejs_error_text")) {
                $("load-help").textContent = `The emulator couldn't load the game: ${t}. Leave and try again.`;
                $("load-help").classList.add("error-text");
                return;
              }
              if (/core/i.test(t)) reportProgress(5 + (Number.isFinite(n) ? n * 0.4 : 0));
              else if (/game data|download/i.test(t)) reportProgress(45 + (Number.isFinite(n) ? n * 0.4 : 0));
              else if (/decompress|extract/i.test(t)) reportProgress(85 + (Number.isFinite(n) ? n * 0.1 : 0));
              else if (/loading/i.test(t)) reportProgress(4);
            };
            obs = new MutationObserver(read); obs.observe(el, { childList: true, characterData: true, subtree: true, attributes: true, attributeFilter: ["class"] }); read();
          };
          watch();
          const s = document.createElement("script");
          s.src = "/data/loader.js";
          s.onerror = () => message("Couldn't load the emulator files.", true);
          document.body.appendChild(s);
        },
      };
      api.started = () => {
        if (ghost) {
          api.go();
          message(`GO! Your run is your own: other players are ghosts only.${api.helpText || ""}`, false);
          return;
        }
        message(`Lobby <b class="code">${esc(code)}</b> is live. Use <b>Copy invite link</b> to invite more friends.${api.helpText || ""}`, false);
        setTimeout(() => message("", false), 8000);
      };
      return api;
    }

    // ============================================================ ghost spectator
    // Shows one player's run solid (lowest seat by default; "Follow" in the Ghosts panel) with the others as ghosts.
    function makeGhostWatch() {
      let base = null, followId = null, chosen = false;
      const api = {
        message, systemChanged() {},
        redraw() { if (inGame) renderPlayers(players, { voice, colors: ghostColors(), me: myId(), ghost: ghostHud() }); },
        following: () => followId,
        follow(id) { chosen = true; followId = id; api.ghostsChanged(); syncGhosts(); },
        ghostsChanged() {
          if (!base) return;
          if (!chosen || !ghostTracks.has(followId)) {
            const live = players.filter(p => !p.spectator && ghostTracks.has(p.id)).sort((a, b) => a.slot - b.slot)[0];
            const next = live ? live.id : null;
            if (next !== followId) { followId = next; queueMicrotask(syncGhosts); }
          }
          const t = followId != null ? ghostTracks.get(followId) : null;
          const cur = base.srcObject?.getVideoTracks?.()[0] || null;
          if (t !== cur) { base.srcObject = t ? new MediaStream([t]) : null; if (t) base.play().catch(() => {}); comp?.setBase(base); }
        },
        load() {
          if (base) return;
          base = document.createElement("video");
          base.id = "ghost-base"; base.muted = true; base.playsInline = true; base.autoplay = true;
          $("stage").prepend(base);
          const c = ensureComp(); c.setTarget(() => base); c.setBase(base);
          api.ghostsChanged(); syncGhosts();
          reportProgress(100);
        },
        started() { message("You are watching. Open <b>Ghosts</b> to pick who to follow.", false); },
      };
      return api;
    }

    // ============================================================ guest game
    function makeGuestGame() {
      const video = $("guest-video");
      let touch = null, gotVideo = false, system = roomSystem, loaded = false;
      const pad = new Input.Pad(v => net.sendInput(v));
      const progressFor = () => {
        if (gotVideo && video.readyState >= 2) return 100;
        if (gotVideo) return 80;
        if (net?.channelOpen) return 60;
        if (netStateNow === "connected") return 45;
        if (netStateNow === "connecting") return 20;
        return 10;
      };
      const bump = () => { if (phase === "loading" || phase === "playing") reportProgress(progressFor()); };
      video.addEventListener("loadeddata", bump);
      video.addEventListener("playing", bump);
      const api = {
        message,
        redraw() { if (inGame) renderPlayers(players, { voice }); },
        stream(s) {
          if (video.srcObject !== s) video.srcObject = s;
          video.volume = Settings.get("volume");
          video.muted = false;
          video.play().then(() => { $("g-sound").hidden = true; }).catch(() => {
            video.muted = true; video.play().catch(() => {});
            $("g-sound").hidden = false;
          });
          gotVideo = true; bump();
        },
        netState(st) {
          bump();
          if (!inGame) return;
          if (st === "failed") message("Couldn't connect to the host directly. The hub owner may need to set up a TURN server.", true);
          else if (st === "disconnected") message("Connection to the host is unstable…", true);
        },
        systemChanged(sys) { system = sys; if (loaded) buildTouch(); },
        load() {
          if (loaded) return; loaded = true;
          video.hidden = false;
          Input.attachKeyboard(system, { A: pad });
          Input.attachGamepads(system, () => pad);
          buildTouch();
          $("g-touch").hidden = false;
          bump();
        },
        started() {
          const m = mine();
          message(m?.spectator ? "You are watching." : `You are <b>P${(m?.slot ?? 0) + 1}</b>. ${esc(Input.KEY_HELP[Input.scheme(system)].A)}`, false);
        },
      };
      setInterval(bump, 500);
      // Touch controller: automatic on touch screens, toggle with the HUD button; the choice is remembered.
      const coarse = matchMedia("(pointer: coarse)").matches;
      const pref = () => { try { const v = localStorage.getItem("rh-touchpad"); return v == null ? coarse : v === "1"; } catch { return coarse; } };
      const buildTouch = () => { touch?.destroy(); touch = Input.createTouch($("stage"), system, pad); touch.show(pref()); };
      $("g-touch").onclick = () => {
        const on = !pref();
        try { localStorage.setItem("rh-touchpad", on ? "1" : "0"); } catch {}
        touch?.show(on);
      };
      $("g-sound").onclick = () => { video.muted = false; video.play().catch(() => {}); $("g-sound").hidden = true; };
      setInterval(() => { $("g-net").textContent = net.rtt != null ? `Host ${net.rtt} ms` : ""; $("g-net").className = "small trunc ping " + pingClass(net.rtt); }, 1000);
      return api;
    }
  }

  // ================================================================ in-game HUD helpers
  let flashTimer = 0;
  function message(text, sticky) {
    clearTimeout(flashTimer);
    $("g-msg").innerHTML = text; $("g-msg").hidden = !text;
    if (text && !sticky) flashTimer = setTimeout(() => { $("g-msg").hidden = true; }, 3500);
  }
  const hudDrag = { on: false };   // don't rebuild the chips while one is being dragged
  function renderPlayers(players, extra = {}) {
    if (hudDrag.on) return;
    const box = $("g-players");
    const focusGid = document.activeElement?.closest?.("#g-players .pchip")?.dataset.gid;
    box.textContent = "";
    const bySlot = new Map(players.filter(p => !p.spectator).map(p => [p.slot, p]));
    for (let s = 0; s < config.maxPlayers; s++) {
      const p = bySlot.get(s), loc = extra.local?.includes(s) && !p;
      const chip = document.createElement("span");
      chip.className = "pchip" + (p || loc ? "" : " open");
      let net = "";
      if (p && !p.host && extra.netState) {
        const st = extra.netState(p.id);
        net = `<span class="net ${st === "connected" ? "ok" : st === "failed" || st === "disconnected" ? "bad" : ""}" title="${esc(st)}"></span>`;
      }
      const vu = p?.voice ? `<span class="vu ${extra.voice?.muted.has(p.key) ? "muted" : ""}" data-key="${esc(p.key)}"><i></i><i></i><i></i><i></i></span>` : "";
      const col = p && extra.colors && p.id !== extra.me ? extra.colors[s] : "";
      const sw = col ? `<span class="swatch" style="background:${col}" title="Ghost color"></span>` : "";
      chip.innerHTML = `<span class="slot">P${s + 1}</span>${p ? `${net}${sw}<span class="trunc pn">${esc(p.name)}</span>${vu}`
        : loc ? `<span class="trunc pn">${esc(extra.hostName)}'s PC</span>` : `<span class="muted">open</span>`}`;
      if (p) chip.title = `${p.name} #${prettyId(p.key)}`;
      if (p && extra.ghost && p.id !== extra.me) {
        const off = extra.ghost.hidden.has(s), pip = extra.ghost.pipped.has(p.id);
        chip.classList.add("ghostable");
        chip.classList.toggle("ghost-off", off && !pip);
        chip.classList.toggle("pipped", pip);
        chip.dataset.gid = p.id;
        chip.tabIndex = 0; chip.setAttribute("role", "button");
        chip.setAttribute("aria-pressed", String(!off && !pip));
        if (pip) chip.insertAdjacentHTML("beforeend", '<span class="pipmark" aria-hidden="true">⧉</span>');
        chip.title = `${p.name}: ${pip ? "in a window (click to put back)" : off ? "ghost hidden (click to show)" : "click to hide ghost"} · drag onto the game to pop out · P = pop out`;
      }
      box.appendChild(chip);
      if (focusGid && chip.dataset.gid === focusGid) chip.focus();
    }
    const specs = players.filter(p => p.spectator).length;
    if (specs) { const c = document.createElement("span"); c.className = "pchip open"; c.textContent = `👁 ${specs}`; c.title = `${specs} watching`; box.appendChild(c); }
  }

  boot().catch(e => { console.error(e); document.body.insertAdjacentHTML("beforeend", `<div class="msg error" style="margin:20px">${esc(e.message || e)}</div>`); });
})();
