@echo off
rem Double-click to stop the Retro Hub server running on this computer.
cd /d "%~dp0"
where py >nul 2>nul && (py -3 stop.py & goto :end)
where python >nul 2>nul && (python stop.py & goto :end)
echo Python 3 was not found. Close the Retro Hub window or press Ctrl+C in it instead.
:end
pause
