(function () {
  "use strict";
  const { Accounts, prettyId } = window.RH;
  const $ = id => document.getElementById(id);
  const sections = ["busy", "pick", "make", "access"];
  const show = id => sections.forEach(s => { $(s).hidden = s !== id; });
  const err = text => { $("error").textContent = text || ""; $("error").hidden = !text; };

  // Only same-site paths are allowed as a return address.
  function nextUrl() {
    const n = new URLSearchParams(location.search).get("next") || "/";
    return n.startsWith("/") && !n.startsWith("//") && !n.startsWith("/\\") && !n.startsWith("/login.html") ? n : "/";
  }

  let pending = null; // account waiting for the access code

  async function signIn(acct, access) {
    err(""); show("busy"); $("busy-text").textContent = `Signing in as ${acct.name}…`;
    try {
      await Accounts.signIn(acct, access);
      location.replace(nextUrl());
    } catch (e) {
      if (e.code === "access") {
        pending = acct; show("access");
        if (access) err(e.message);
        $("access-code").focus();
        return;
      }
      err(e.message || "Sign-in failed.");
      await renderPick();
    }
  }

  async function renderPick() {
    const accts = await Accounts.list();
    const ul = $("acct-list"); ul.textContent = "";
    if (!accts.length) { $("make-title").textContent = "Make an account"; show("make"); $("name").focus(); return; }
    for (const a of accts) {
      const li = document.createElement("li"); li.tabIndex = 0;
      li.innerHTML = `<div class="grow"><div class="title"></div><div class="id"></div></div><button class="primary small">Play</button>`;
      li.querySelector(".title").textContent = a.name;
      li.querySelector(".id").textContent = "#" + prettyId(a.id);
      const go = () => signIn(a);
      li.addEventListener("click", go);
      li.addEventListener("keydown", e => { if (e.key === "Enter") go(); });
      ul.appendChild(li);
    }
    const add = document.createElement("li");
    add.innerHTML = `<div class="grow"><div class="title">+ New account</div><div class="sub">For another player on this computer</div></div>`;
    add.addEventListener("click", () => { err(""); $("make-title").textContent = "New account"; show("make"); $("name").focus(); });
    ul.appendChild(add);
    show("pick");
  }

  $("make-form").addEventListener("submit", async e => {
    e.preventDefault();
    const name = $("name").value.trim();
    if (!name) return;
    try { signIn(await Accounts.create(name)); } catch (ex) { err(ex.message); }
  });
  $("import-btn").addEventListener("click", () => $("import-file").click());
  $("import-file").addEventListener("change", async () => {
    const f = $("import-file").files[0]; $("import-file").value = "";
    if (!f) return;
    try { signIn(await Accounts.importFile(f)); } catch (ex) { err(ex.message); }
  });
  $("access-form").addEventListener("submit", e => {
    e.preventDefault();
    if (pending) signIn(pending, $("access-code").value);
  });
  $("access-back").addEventListener("click", () => { err(""); pending = null; renderPick(); });

  (async () => {
    try {
      const id = Accounts.current();
      const acct = id && await Accounts.get(id);
      if (acct) return signIn(acct);
      await renderPick();
    } catch (e) {
      err(e.message || String(e)); show("make");
    }
  })();
})();
