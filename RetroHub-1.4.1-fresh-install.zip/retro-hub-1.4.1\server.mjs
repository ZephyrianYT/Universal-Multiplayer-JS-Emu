// Retro netplay hub server.
// - Local accounts: each browser holds its own ECDSA P-256 key; the server only verifies a signed one-time
//   challenge and issues a session cookie. No passwords, no account database: nothing about accounts is stored.
// - Every host sets its own lobby password; guests must know it to join that lobby
// - Owner-only ROM library (ROMS_DIR): unlocked by ADMIN_KEYS (account IDs) or the ADMIN_PASSWORD unlock
// - EmulatorJS served locally; missing cores are fetched once from the official CDN and cached (CORES_CACHE)
// - Room signaling + live open-rooms list over WebSocket (/ws)
// - COOP/COEP/CORP headers so SharedArrayBuffer (threaded cores) works
import http from "node:http";
import https from "node:https";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { WebSocketServer } from "ws";

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(ROOT, "public");
const ROMS_DIR = path.resolve(process.env.ROMS_DIR || path.join(ROOT, "roms"));
const CORES_CACHE = path.resolve(process.env.CORES_CACHE || path.join(ROOT, "cache", "cores"));
const PORT = Number(process.env.PORT || 8080);
const HOST = process.env.HOST || "0.0.0.0";
const MAX_PLAYERS = Math.min(4, Math.max(2, Number(process.env.MAX_PLAYERS || 4)));
const LIBRARY_ACCESS = process.env.LIBRARY_ACCESS === "all" ? "all" : "admin";
const TRUST_PROXY = process.env.TRUST_PROXY === "1";
// Public address of this hub (e.g. a Cloudflare tunnel). Invite links use it, so a host who opened the hub
// on localhost still copies a link that works for friends. Only a plain https?://host[:port] origin is accepted.
const PUBLIC_URL = (() => {
  const raw = String(process.env.PUBLIC_URL || "").trim();
  if (!raw) return "";
  try { const u = new URL(raw); if (u.protocol === "https:" || u.protocol === "http:") return u.origin; } catch {}
  console.warn(`PUBLIC_URL ${JSON.stringify(raw)} is not an http(s) address; ignoring it.`);
  return "";
})();
const EJS_VERSION = "4.2.3";
const APP_VERSION = JSON.parse(fs.readFileSync(path.join(ROOT, "package.json"), "utf8")).version;
const CTRL_RE = /[\x00-\x1f<>]/g;

// ---------------------------------------------------------------- auth
const ACCESS_PASSWORD = process.env.ACCESS_PASSWORD || "";   // optional server-wide access code
// Placeholder passwords from old examples count as unset, so a copied sample config never opens the library.
const WEAK_ADMIN = new Set(["change-me", "change-me-owner", "changeme", "owner", "password", "admin"]);
const ADMIN_PASSWORD = (() => {
  const p = process.env.ADMIN_PASSWORD || "";
  if (p && (WEAK_ADMIN.has(p.toLowerCase()) || p.length < 8)) {
    console.warn("ADMIN_PASSWORD is a placeholder or shorter than 8 characters; ignoring it. Set a real one in .env.");
    return "";
  }
  return p;
})();
const ADMIN_KEYS = new Set((process.env.ADMIN_KEYS || "").split(",").map(s => s.trim().toUpperCase()).filter(Boolean));
if (!ADMIN_PASSWORD && !ADMIN_KEYS.size) console.warn("Neither ADMIN_KEYS nor ADMIN_PASSWORD is set; nobody can use the server ROM library.");
// Cookie signing key: SESSION_SECRET, else a random key kept next to the core cache so sessions survive restarts
// (a host mid-game would otherwise be sent back to the account page).
function loadSecret() {
  if (process.env.SESSION_SECRET) return crypto.createHash("sha256").update(process.env.SESSION_SECRET).digest();
  const file = path.join(path.dirname(CORES_CACHE), "session.key");
  try { const k = fs.readFileSync(file); if (k.length === 32) return k; } catch {}
  const k = crypto.randomBytes(32);
  try { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, k, { mode: 0o600 }); }
  catch (e) { console.warn(`Could not save ${file} (${e.code}); everyone will be signed out when the server restarts.`); }
  return k;
}
const SECRET = loadSecret();
const SESSION_DAYS = 30;

const sha = s => crypto.createHash("sha256").update(String(s)).digest();
const same = (a, b) => b !== "" && crypto.timingSafeEqual(sha(a), sha(b));
const sign = data => crypto.createHmac("sha256", SECRET).update(data).digest("base64url");

function makeToken(name, role, id) {
  const body = Buffer.from(JSON.stringify({ n: name, r: role, k: id, e: Date.now() + SESSION_DAYS * 864e5 })).toString("base64url");
  return body + "." + sign(body);
}
const setSession = (req, res, name, role, id) => res.setHeader("Set-Cookie",
  `hub=${makeToken(name, role, id)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${SESSION_DAYS * 86400}${isHttps(req) ? "; Secure" : ""}`);

// One-time challenges for the key handshake: nonce -> expiry
const challenges = new Map();
const CHALLENGE_MS = 120e3;
function newChallenge() {
  if (challenges.size > 5000) { const now = Date.now(); for (const [k, v] of challenges) if (v < now) challenges.delete(k); }
  if (challenges.size > 5000) return null;
  const nonce = crypto.randomBytes(24).toString("base64url");
  challenges.set(nonce, Date.now() + CHALLENGE_MS);
  return nonce;
}
const B64U = /^[A-Za-z0-9_-]+$/;
// Accounts are Ed25519 keys (tweetnacl in the browser, so it also works over plain-HTTP LAN addresses).
// Account ID = first 16 hex chars of SHA-512 over the raw public key, shown to users as ABCD-EF01-2345-6789.
const accountId = pubBytes => crypto.createHash("sha512").update(pubBytes).digest("hex").slice(0, 16).toUpperCase();
function verifyHello(body) {
  const { pub, nonce, sig } = body || {};
  if (typeof pub !== "string" || pub.length !== 43 || !B64U.test(pub)) return null;
  if (typeof nonce !== "string" || typeof sig !== "string" || sig.length !== 86 || !B64U.test(sig)) return null;
  const exp = challenges.get(nonce);
  challenges.delete(nonce);
  if (!exp || exp < Date.now()) return null;
  try {
    const key = crypto.createPublicKey({ key: { kty: "OKP", crv: "Ed25519", x: pub }, format: "jwk" });
    const ok = crypto.verify(null, Buffer.from(`retro-hub-login\n${nonce}`), key, Buffer.from(sig, "base64url"));
    return ok ? accountId(Buffer.from(pub, "base64url")) : null;
  } catch { return null; }
}
function readSession(req) {
  const m = /(?:^|;\s*)hub=([^;]+)/.exec(req.headers.cookie || "");
  if (!m) return null;
  const [body, mac] = m[1].split(".");
  if (!body || !mac) return null;
  const expect = sign(body);
  if (mac.length !== expect.length || !crypto.timingSafeEqual(Buffer.from(mac), Buffer.from(expect))) return null;
  try {
    const s = JSON.parse(Buffer.from(body, "base64url").toString());
    return s.e > Date.now() && s.k ? { name: s.n, role: s.r, id: s.k } : null;
  } catch { return null; }
}
const canLibrary = s => !!s && (s.role === "admin" || LIBRARY_ACCESS === "all");
// Behind a proxy every visitor arrives from the proxy's address, so rate limits would lump everyone together.
// Forwarded headers are trusted with TRUST_PROXY=1, or automatically when the proxy runs on this same computer
// (loopback peer: a local cloudflared / Caddy / nginx). Cloudflare's CF-Connecting-IP wins over X-Forwarded-For.
function clientIp(req) {
  const peer = req.socket.remoteAddress;
  if (!TRUST_PROXY && !isLoopback(req)) return peer;
  const cf = String(req.headers["cf-connecting-ip"] || "").trim();
  const xff = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim();
  return (cf || xff).slice(0, 64) || peer;
}
const isHttps = req => !!req.socket.encrypted || String(req.headers["x-forwarded-proto"] || "").startsWith("https");

const failures = new Map(); // ip -> { n, until }
const rateLimited = ip => { const f = failures.get(ip); return !!f && f.n >= 10 && f.until > Date.now(); };
function noteFailure(ip) {
  const f = failures.get(ip);
  if (!f || f.until < Date.now()) failures.set(ip, { n: 1, until: Date.now() + 15 * 60e3 });
  else f.n++;
}
setInterval(() => { const now = Date.now(); for (const [k, v] of failures) if (v.until < now) failures.delete(k); }, 60e3).unref();

// ---------------------------------------------------------------- systems
// EmulatorJS system ids; recognised by folder name first, then by unambiguous extension.
const SYSTEMS = {
  n64:       { label: "Nintendo 64", ext: ["z64", "n64", "v64"], dirs: ["n64", "nintendo64"] },
  nes:       { label: "NES", ext: ["nes", "fds", "unf", "unif"], dirs: ["nes", "famicom"] },
  snes:      { label: "SNES", ext: ["sfc", "smc", "fig", "swc"], dirs: ["snes", "supernintendo", "superfamicom", "sfc"] },
  gb:        { label: "Game Boy / Color", ext: ["gb", "gbc", "dmg"], dirs: ["gb", "gbc", "gameboy", "gameboycolor"] },
  gba:       { label: "Game Boy Advance", ext: ["gba"], dirs: ["gba", "gameboyadvance"] },
  nds:       { label: "Nintendo DS", ext: ["nds"], dirs: ["nds", "nintendods"] },
  psx:       { label: "PlayStation", ext: ["pbp", "chd", "m3u", "ecm"], dirs: ["psx", "ps1", "playstation", "playstation1", "psone"] },
  segaMD:    { label: "Genesis / Mega Drive", ext: ["md", "gen", "smd"], dirs: ["genesis", "megadrive", "md", "segamd"] },
  segaMS:    { label: "Master System", ext: ["sms"], dirs: ["sms", "mastersystem"] },
  segaGG:    { label: "Game Gear", ext: ["gg"], dirs: ["gg", "gamegear"] },
  segaCD:    { label: "Sega CD", ext: [], dirs: ["segacd", "megacd"] },
  sega32x:   { label: "Sega 32X", ext: ["32x"], dirs: ["32x", "sega32x"] },
  segaSaturn:{ label: "Saturn", ext: [], dirs: ["saturn", "segasaturn"] },
  atari2600: { label: "Atari 2600", ext: ["a26"], dirs: ["atari2600", "2600"] },
  atari7800: { label: "Atari 7800", ext: ["a78"], dirs: ["atari7800", "7800"] },
  lynx:      { label: "Atari Lynx", ext: ["lnx"], dirs: ["lynx", "atarilynx"] },
  jaguar:    { label: "Atari Jaguar", ext: ["j64", "jag"], dirs: ["jaguar", "atarijaguar"] },
  pce:       { label: "PC Engine / TG-16", ext: ["pce"], dirs: ["pce", "pcengine", "tg16", "turbografx", "turbografx16"] },
  ngp:       { label: "Neo Geo Pocket", ext: ["ngp", "ngc"], dirs: ["ngp", "ngpc", "neogeopocket"] },
  ws:        { label: "WonderSwan", ext: ["ws", "wsc"], dirs: ["wonderswan", "wsc"] },
  vb:        { label: "Virtual Boy", ext: ["vb", "vboy"], dirs: ["virtualboy", "vb"] },
  coleco:    { label: "ColecoVision", ext: ["col"], dirs: ["coleco", "colecovision"] },
  arcade:    { label: "Arcade (FBNeo)", ext: [], dirs: ["arcade", "fbneo", "fba", "neogeo"] },
  psp:       { label: "PSP", ext: ["cso"], dirs: ["psp"] },
};
const AMBIGUOUS = ["zip", "7z", "bin", "iso", "cue", "img"];
const norm = s => s.toLowerCase().replace(/[\s_.-]/g, "");
const EXT_TO_SYS = {}, DIR_TO_SYS = {};
for (const [id, s] of Object.entries(SYSTEMS)) {
  for (const e of s.ext) EXT_TO_SYS[e] = id;
  for (const d of s.dirs) DIR_TO_SYS[norm(d)] = id;
}
const ROM_EXTS = new Set([...Object.keys(EXT_TO_SYS), ...AMBIGUOUS]);
const COVER_EXTS = new Set(["png", "jpg", "jpeg", "webp"]);

function detectSystem(relPath) {
  const parts = relPath.split("/");
  for (let i = parts.length - 2; i >= 0; i--) {
    const sys = DIR_TO_SYS[norm(parts[i])];
    if (sys) return sys;
  }
  return EXT_TO_SYS[path.extname(relPath).slice(1).toLowerCase()] || null;
}

let libCache = { at: 0, list: [] };
function scanLibrary() {
  if (Date.now() - libCache.at < 30e3) return libCache.list;
  const out = [];
  // Optional cover art: "<game>.png|jpg|jpeg|webp" next to the ROM, or in a covers/ boxart/ media/ subfolder.
  const imagesIn = (dir, rel) => {
    const map = new Map();
    const add = (d, r) => {
      let es; try { es = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
      for (const e of es) if (e.isFile() && COVER_EXTS.has(path.extname(e.name).slice(1).toLowerCase()))
        map.set(e.name.replace(/\.[^.]+$/, "").toLowerCase(), r ? r + "/" + e.name : e.name);
    };
    add(dir, rel);
    for (const sub of ["covers", "boxart", "media"]) add(path.join(dir, sub), rel ? rel + "/" + sub : sub);
    return map;
  };
  const walk = (dir, rel, depth) => {
    let entries; try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    let covers = null;
    for (const d of entries) {
      if (d.name.startsWith(".")) continue;
      const r = rel ? rel + "/" + d.name : d.name;
      if (d.isDirectory()) { if (depth < 5 && !/^(bios|covers|boxart|media)$/i.test(d.name)) walk(path.join(dir, d.name), r, depth + 1); continue; }
      if (!d.isFile()) continue;
      const ext = path.extname(d.name).slice(1).toLowerCase();
      if (!ROM_EXTS.has(ext)) continue;
      const system = detectSystem(r);
      if (!system) continue;
      let size = 0; try { size = fs.statSync(path.join(dir, d.name)).size; } catch {}
      const name = d.name.replace(/\.[^.]+$/, "");
      covers = covers || imagesIn(dir, rel);
      out.push({ path: r, name, ext, system, size, cover: covers.get(name.toLowerCase()) || null });
    }
  };
  walk(ROMS_DIR, "", 0);
  // EmulatorJS needs one file per game: hide .cue sheets and extra audio tracks of multi-track .bin dumps
  const list = out.filter(r => r.ext !== "cue" && !(r.ext === "bin" && /\(track 0*([2-9]|\d{2,})\)/i.test(r.name)));
  list.sort((a, b) => a.system.localeCompare(b.system) || a.name.localeCompare(b.name));
  libCache = { at: Date.now(), list };
  return list;
}

// ---------------------------------------------------------------- static files
const MIME = {
  ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8", ".wasm": "application/wasm",
  ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon",
  ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp",
  ".zip": "application/zip", ".7z": "application/x-7z-compressed",
};
function baseHeaders(res) {
  res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
  res.setHeader("Cross-Origin-Embedder-Policy", "require-corp");
  res.setHeader("Cross-Origin-Resource-Policy", "same-origin");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "same-origin");
  res.setHeader("Content-Security-Policy", CSP);
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Permissions-Policy", "camera=(), geolocation=(), payment=(), usb=(), microphone=(self), fullscreen=(self), gamepad=(self)");
}
// Only this server's own scripts run: no inline scripts or handlers, no other hosts, and connections go to this
// server only ('self' covers its ws:/wss: socket too; it also blocks EmulatorJS's update check to its CDN).
// 'wasm-unsafe-eval' lets the emulator compile its WebAssembly cores; blob: is where EmulatorJS puts the core's
// unpacked script and its workers. 'unsafe-eval' is needed only because EmulatorJS's bundled 7-Zip decompressor
// (data/compression/extract7z.js, old Emscripten output) calls eval() inside a blob worker, which inherits this
// policy. Without it, cores never finish "Decompress Game Core".
const CSP = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-eval' 'wasm-unsafe-eval' blob:",
  "worker-src 'self' blob:",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob:",
  "media-src 'self' blob: mediastream:",
  "font-src 'self' data:",
  "connect-src 'self' blob: data:",
  "object-src 'none'",
  "base-uri 'none'",
  "form-action 'self'",
  "frame-ancestors 'none'",
].join("; ");
function safeJoin(base, urlPath) {
  const p = path.resolve(base, "." + path.posix.normalize("/" + urlPath));
  return p === base || p.startsWith(base + path.sep) ? p : null;
}
function sendFile(req, res, file, cache = "no-cache", onMissing) {
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) {
      if (onMissing) return onMissing();
      res.writeHead(404); return res.end("Not found");
    }
    const type = MIME[path.extname(file).toLowerCase()] || "application/octet-stream";
    const headers = { "Content-Type": type, "Accept-Ranges": "bytes", "Cache-Control": cache };
    const range = req.headers.range && /bytes=(\d*)-(\d*)/.exec(req.headers.range);
    if (range && (range[1] || range[2])) {
      const start = range[1] ? Number(range[1]) : Math.max(0, st.size - Number(range[2]));
      const end = range[1] && range[2] ? Math.min(Number(range[2]), st.size - 1) : st.size - 1;
      if (start > end || start >= st.size) { res.writeHead(416, { "Content-Range": `bytes */${st.size}` }); return res.end(); }
      res.writeHead(206, { ...headers, "Content-Length": end - start + 1, "Content-Range": `bytes ${start}-${end}/${st.size}` });
      return req.method === "HEAD" ? res.end() : fs.createReadStream(file, { start, end }).pipe(res);
    }
    res.writeHead(200, { ...headers, "Content-Length": st.size });
    req.method === "HEAD" ? res.end() : fs.createReadStream(file).pipe(res);
  });
}

// ---------------------------------------------------------------- core cache (official CDN, pinned version)
const CORE_FILE_RE = /^(?:[a-z0-9_]+(?:-thread)?(?:-legacy)?-wasm\.data|reports\/[a-z0-9_]+\.json)$/;
const inflight = new Map();
function fetchCore(rel) {
  if (inflight.has(rel)) return inflight.get(rel);
  const dest = path.join(CORES_CACHE, rel);
  const url = `https://cdn.emulatorjs.org/${EJS_VERSION}/data/cores/${rel}`;
  const p = new Promise((resolve, reject) => {
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    const tmp = dest + ".part-" + process.pid;
    https.get(url, { timeout: 30e3 }, r => {
      if (r.statusCode !== 200) { r.resume(); return reject(new Error(`CDN ${r.statusCode} for ${rel}`)); }
      const out = fs.createWriteStream(tmp);
      r.pipe(out);
      out.on("finish", () => { fs.renameSync(tmp, dest); console.log(`cached core ${rel}`); resolve(dest); });
      out.on("error", e => { fs.rmSync(tmp, { force: true }); reject(e); });
      r.on("error", e => { out.destroy(); fs.rmSync(tmp, { force: true }); reject(e); });
    }).on("error", reject).on("timeout", function () { this.destroy(new Error("CDN timeout")); });
  }).finally(() => inflight.delete(rel));
  inflight.set(rel, p);
  return p;
}
function serveCore(req, res, rel) {
  const cache = "public, max-age=86400";
  sendFile(req, res, path.join(PUBLIC_DIR, "data", "cores", rel), cache,
    () => sendFile(req, res, path.join(CORES_CACHE, rel), cache,
      () => fetchCore(rel).then(f => sendFile(req, res, f, cache))
        .catch(e => { console.warn(e.message); res.writeHead(404); res.end(); })));
}

// ---------------------------------------------------------------- HTTP
const PUBLIC_PATHS = new Set(["/login.html", "/login.js", "/account.js", "/vendor/nacl-fast.min.js", "/style.css",
  "/api/challenge", "/favicon.ico"]);
const json = (res, code, obj) => { res.writeHead(code, { "Content-Type": "application/json", "Cache-Control": "no-store" }); res.end(JSON.stringify(obj)); };
function readBody(req, limit = 4096) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on("data", c => { size += c.length; if (size > limit) { reject(new Error("too big")); req.destroy(); } else chunks.push(c); });
    req.on("end", () => resolve(Buffer.concat(chunks).toString()));
    req.on("error", reject);
  });
}
function iceServers() {
  const list = (process.env.STUN_URLS || "stun:stun.l.google.com:19302")
    .split(",").map(s => s.trim()).filter(Boolean).map(urls => ({ urls }));
  if (process.env.TURN_URL) list.push({ urls: process.env.TURN_URL.split(",").map(s => s.trim()),
    username: process.env.TURN_USERNAME || "", credential: process.env.TURN_CREDENTIAL || "" });
  return list;
}

const server = http.createServer(async (req, res) => {
  baseHeaders(res);
  let urlPath;
  try { urlPath = decodeURIComponent(new URL(req.url, "http://x").pathname); }
  catch { res.writeHead(400); return res.end(); }

  if (urlPath === "/api/challenge" && req.method === "GET") {
    const nonce = newChallenge();
    if (!nonce) return json(res, 503, { error: "Server busy. Try again in a minute." });
    return json(res, 200, { nonce, accessCode: !!ACCESS_PASSWORD });
  }
  if (urlPath === "/api/hello" && req.method === "POST") {
    const ip = clientIp(req);
    if (rateLimited(ip)) return json(res, 429, { error: "Too many attempts. Try again in 15 minutes." });
    let body; try { body = JSON.parse(await readBody(req)); } catch { return json(res, 400, { error: "Bad request" }); }
    const name = String(body.name || "").replace(CTRL_RE, "").trim().slice(0, 20);
    if (!name) return json(res, 400, { error: "Your account needs a name." });
    if (ACCESS_PASSWORD && !same(String(body.access || ""), ACCESS_PASSWORD)) {
      noteFailure(ip); return json(res, 401, { error: "Wrong server access code.", code: "access" });
    }
    const id = verifyHello(body);
    if (!id) { noteFailure(ip); return json(res, 401, { error: "Key check failed. Reload the page and try again." }); }
    failures.delete(ip);
    const role = ADMIN_KEYS.has(id) ? "admin" : "user";
    setSession(req, res, name, role, id);
    return json(res, 200, { ok: true, name, role, id });
  }
  if (urlPath === "/api/unlock" && req.method === "POST") {
    const s = readSession(req);
    if (!s) return json(res, 401, { error: "Login required" });
    const ip = clientIp(req);
    if (rateLimited(ip)) return json(res, 429, { error: "Too many attempts. Try again in 15 minutes." });
    let body; try { body = JSON.parse(await readBody(req)); } catch { return json(res, 400, { error: "Bad request" }); }
    if (!same(String(body.password || ""), ADMIN_PASSWORD)) { noteFailure(ip); return json(res, 401, { error: "Wrong owner password." }); }
    failures.delete(ip);
    setSession(req, res, s.name, "admin", s.id);
    return json(res, 200, { ok: true });
  }
  if (urlPath === "/api/logout" && req.method === "POST") {
    res.setHeader("Set-Cookie", "hub=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0");
    return json(res, 200, { ok: true });
  }
  // Shut the whole server down. Allowed for (a) stop.py on this same computer, which proves itself with the
  // random token in run/retro-hub.json and must connect over loopback, or (b) a signed-in owner (admin)
  // pressing "Shut down server" (custom header = no cross-site form can trigger it).
  if (urlPath === "/api/shutdown" && req.method === "POST") {
    const s = readSession(req);
    const byToken = isLoopback(req) && typeof req.headers["x-shutdown-token"] === "string"
      && same(req.headers["x-shutdown-token"], SHUTDOWN_TOKEN);
    const byAdmin = s?.role === "admin" && req.headers["x-retro-hub"] === "shutdown";
    if (!byToken && !byAdmin) return json(res, 403, { error: "Not allowed." });
    json(res, 202, { ok: true });
    return shutdown(byAdmin ? `the owner (${s.name}) shut the server down` : "stop script");
  }
  if (req.method !== "GET" && req.method !== "HEAD") { res.writeHead(405); return res.end(); }

  const session = readSession(req);
  if (!session && !PUBLIC_PATHS.has(urlPath)) {
    if (urlPath === "/" || urlPath.endsWith(".html")) {
      res.writeHead(302, { Location: "/login.html?next=" + encodeURIComponent(req.url) }); return res.end();
    }
    return json(res, 401, { error: "Login required" });
  }

  if (urlPath === "/api/me") return json(res, 200, { ...session, library: canLibrary(session), version: APP_VERSION,
    canUnlock: !!ADMIN_PASSWORD && session.role !== "admin" });
  if (urlPath === "/api/config") return json(res, 200, { iceServers: iceServers(), maxPlayers: MAX_PLAYERS, publicUrl: PUBLIC_URL,
    systems: Object.fromEntries(Object.entries(SYSTEMS).map(([k, v]) => [k, v.label])),
    detect: { ext: EXT_TO_SYS, dirs: DIR_TO_SYS } });
  if (urlPath === "/api/library") {
    if (!canLibrary(session)) return json(res, 403, { error: "Library is owner-only" });
    return json(res, 200, scanLibrary());
  }
  if (urlPath.startsWith("/roms/")) {
    if (!canLibrary(session)) { res.writeHead(403); return res.end(); }
    // The client prefixes the file name with "<account>__" so EmulatorJS keeps a separate in-game save per account
    const f = safeJoin(ROMS_DIR, urlPath.slice(6).replace(/(^|\/)[0-9A-F]{8}__(?=[^/]+$)/, "$1"));
    if (!f || !ROM_EXTS.has(path.extname(f).slice(1).toLowerCase())) { res.writeHead(404); return res.end(); }
    return sendFile(req, res, f, "private, no-store");
  }
  if (urlPath.startsWith("/covers/")) {      // library cover art: same access rule as the ROMs
    if (!canLibrary(session)) { res.writeHead(403); return res.end(); }
    const f = safeJoin(ROMS_DIR, urlPath.slice(8));
    if (!f || !COVER_EXTS.has(path.extname(f).slice(1).toLowerCase())) { res.writeHead(404); return res.end(); }
    return sendFile(req, res, f, "private, max-age=3600");
  }
  if (urlPath.startsWith("/data/cores/")) {
    const rel = urlPath.slice("/data/cores/".length);
    if (!CORE_FILE_RE.test(rel)) { res.writeHead(404); return res.end(); }
    return serveCore(req, res, rel);
  }
  const f = safeJoin(PUBLIC_DIR, urlPath.endsWith("/") ? urlPath + "index.html" : urlPath);
  if (!f) { res.writeHead(403); return res.end(); }
  sendFile(req, res, f, f.startsWith(path.join(PUBLIC_DIR, "data")) ? "public, max-age=86400" : "no-cache");
});

// ---------------------------------------------------------------- rooms + signaling (/ws)
// Room phases: lobby -> countdown (3 s, server-timed) -> loading (per-player progress) -> playing.
const rooms = new Map();      // code -> { code, host, owner, pw, reserved:Set, clients:Map, game, system, phase, rules, cd }
const lobbyWatchers = new Set();
let nextId = 1;
const MAX_CLIENTS = 12;       // players + spectators
const COUNTDOWN_MS = 3000;
const WS_RATE_MAX = 200;      // messages per second per socket before it is closed as a flood
const RESUME_MS = 30000;
const CHAT_KEEP = 60;         // messages kept per room for late joiners
const CHAT_MAX = 300;         // characters per message
const CHAT_BURST = 6, CHAT_WINDOW = 8000;   // at most 6 messages per 8 s per player     // a dropped socket keeps its seat, id, ready flag and ROM this long (resume token)
const wss = new WebSocketServer({ noServer: true, maxPayload: 64 * 1024 });
server.on("upgrade", (req, socket, head) => {
  const session = readSession(req);
  if (new URL(req.url, "http://x").pathname !== "/ws" || !session) {
    socket.write("HTTP/1.1 401 Unauthorized\r\n\r\n"); return socket.destroy();
  }
  wss.handleUpgrade(req, socket, head, ws => wss.emit("connection", ws, session, clientIp(req)));
});

const send = (c, msg) => { if (c.ws.readyState === 1) c.ws.send(JSON.stringify(msg)); };
const roster = room => [...room.clients.values()].map(c => ({ id: c.id, slot: c.slot, name: c.name, key: c.key, host: c === room.host,
  ready: c.ready, progress: c.progress, rtt: c.ws.rtt ?? null, spectator: c.slot < 0, voice: c.voice, rom: c.rom, ghost: c.ghost,
  away: !!c.away }));
// Removes a client for good (left on purpose, or its resume window ran out).
function finalizeLeave(room, c, quiet) {
  clearTimeout(c.awayT); c.awayT = null; c.away = false;
  if (room.clients.get(c.id) !== c) return;
  room.clients.delete(c.id);
  const wasHost = room.host === c;
  if (wasHost) { room.host = null; room.reserved = new Set(); }
  if (!room.clients.size) { clearTimeout(room.cd); rooms.delete(room.code); return pushRoomList(); }
  if (!quiet) chatSys(room, `${c.name} left.`);
  if (wasHost && promoteHost(room, `${c.name} left.`)) return;
  cancelCountdown(room, `${c.name} left.`);
  checkLoaded(room);
  sendRoster(room);
}
// Host migration: the old host is gone for good, so the connected player in the lowest seat (else a spectator)
// takes over. The game itself only ever lived in the old host's browser, so a running match ends and the room
// goes back to the lobby; the new host picks the game (co-op) or reference ROM (ghost) and starts again.
function promoteHost(room, why) {
  const live = [...room.clients.values()].filter(c => !c.away && !c.left);
  const next = live.filter(c => c.slot >= 0).sort((a, b) => a.slot - b.slot)[0] || live[0];
  if (!next) return false;          // everyone is away: the room waits (the owner can still come back as host)
  const wasRunning = room.phase !== "lobby";
  clearTimeout(room.cd); room.cd = null; room.staged = false;
  if (room.phase === "countdown") broadcast(room, { t: "countdown", cancelled: true, reason: why });
  if (next.slot < 0) next.slot = freeSlot(room, next);
  next.wasSeated = true;
  room.host = next; room.owner = next.key;
  room.reserved = new Set([next.slot]);
  setPhase(room, "lobby");          // also clears everyone's ready state
  send(next, { t: "promoted", wasRunning });
  chatSys(room, `${next.name} is the host now.`);
  broadcast(room, { t: "notice", msg: `${why} ${next.name} is the host now.${wasRunning ? " The match ended; it can be started again from the lobby." : ""}` });
  sendRoster(room);
  return true;
}
const joinedMsg = (room, c, extra) => ({ t: "joined", id: c.id, slot: c.slot, room: room.code, host: room.host === c, phase: room.phase,
  token: c.token, game: room.game, system: room.system, mode: room.rules.mode, ...extra });
const tokenMatch = (a, b) => typeof a === "string" && a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
// Single-player ghost mode: every player runs their own ROM; only checksums (never ROM data) reach the server.
const isGhost = room => room.rules.mode === "ghost";
function cleanRom(r) {
  if (!r || typeof r !== "object") return null;
  const crc = String(r.crc || "").toUpperCase();
  const size = Number(r.size);
  if (!/^[0-9A-F]{8}$/.test(crc) || !Number.isSafeInteger(size) || size <= 0) return null;
  return { crc, size, name: cleanText(r.name, 80) };
}
// Lobby passwords live in memory only, as salted scrypt hashes, for as long as the lobby exists.
function hashLobbyPw(pw) {
  const salt = crypto.randomBytes(16);
  return { salt, hash: crypto.scryptSync(pw, salt, 32) };
}
const checkLobbyPw = (room, pw) => !room.pw || crypto.timingSafeEqual(crypto.scryptSync(String(pw || ""), room.pw.salt, 32), room.pw.hash);
const broadcast = (room, msg) => room.clients.forEach(c => send(c, msg));
// Room chat (text only, kept in memory for as long as the room exists). sys = a hub line, not a player's message.
function chat(room, entry) {
  room.chat = room.chat || []; room.chatSeq = (room.chatSeq || 0) + 1;
  const msg = { n: room.chatSeq, at: Date.now(), ...entry };
  room.chat.push(msg); if (room.chat.length > CHAT_KEEP) room.chat.shift();
  broadcast(room, { t: "chat", msg });
}
const chatSys = (room, text) => chat(room, { sys: true, text });
function chatAllowed(c) {
  const now = Date.now();
  c.chatTimes = (c.chatTimes || []).filter(t => now - t < CHAT_WINDOW);
  if (c.chatTimes.length >= CHAT_BURST) return false;
  c.chatTimes.push(now); return true;
}
const cleanCode = s => String(s || "").toUpperCase().replace(/[^A-Z0-9-]/g, "").slice(0, 24);
const cleanText = (s, n) => String(s || "").replace(CTRL_RE, "").trim().slice(0, n);

function freeSlot(room, except) {
  const used = new Set([...room.clients.values()].filter(c => c !== except).map(c => c.slot));
  for (let s = 0; s < MAX_PLAYERS; s++) if (!used.has(s) && !room.reserved.has(s)) return s;
  return -1;
}
const slotTaken = (room, s) => room.reserved.has(s) || [...room.clients.values()].some(c => c.slot === s);
function roomList() {
  return [...rooms.values()].filter(r => r.host).map(r => {
    const guests = [...r.clients.values()].filter(c => c !== r.host);
    const seated = guests.filter(c => c.slot >= 0).length;
    return { code: r.code, game: r.game, system: r.system, host: r.host.name, hostKey: r.owner, locked: !!r.pw,
      players: r.reserved.size + seated, open: Math.max(0, MAX_PLAYERS - r.reserved.size - seated), max: MAX_PLAYERS,
      spectators: guests.length - seated, watchable: r.rules.spectators && r.clients.size < MAX_CLIENTS,
      phase: r.phase, hostRtt: r.host.ws.rtt ?? null, mode: r.rules.mode };
  });
}
let listTimer = null;
function pushRoomList() {
  if (listTimer) return;
  listTimer = setTimeout(() => {
    listTimer = null;
    const msg = JSON.stringify({ t: "rooms", rooms: roomList() });
    for (const ws of lobbyWatchers) if (ws.readyState === 1) ws.send(msg);
  }, 100);
}
function sendRoster(room) {
  broadcast(room, { t: "roster", players: roster(room), hostId: room.host?.id ?? null, game: room.game, system: room.system,
    phase: room.phase, rules: room.rules, reserved: [...room.reserved], staged: !!room.staged });
  pushRoomList();
}
function setPhase(room, phase) {
  room.phase = phase;
  if (phase === "loading") for (const c of room.clients.values()) { c.ready = "loading"; c.progress = 0; }
  if (phase === "lobby") for (const c of room.clients.values()) { c.ready = "notready"; c.progress = 0; }
  broadcast(room, { t: "phase", phase });
}
// Co-op: lobby -> countdown -> loading -> playing (the host's stream starts once everyone is connected).
// Ghost: lobby -> loading -> countdown -> playing, so every player's own emulator is booted (paused) before
// the 3-2-1 and all runs start together on GO. A cancelled ghost countdown returns to the loaded state.
function cancelCountdown(room, reason) {
  if (room.phase !== "countdown") return false;
  clearTimeout(room.cd); room.cd = null;
  room.phase = room.staged ? "loading" : "lobby";
  broadcast(room, { t: "countdown", cancelled: true, reason });
  return true;
}
function runCountdown(room, after) {
  room.phase = "countdown";
  broadcast(room, { t: "countdown", ms: COUNTDOWN_MS });
  room.cd = setTimeout(() => { room.cd = null; if (room.phase === "countdown") { after(); sendRoster(room); } }, COUNTDOWN_MS);
}
const needsReady = room => [...room.clients.values()].filter(c => c.slot >= 0 && c !== room.host);   // the host readies by pressing Start
function checkLoaded(room) {
  if (room.phase !== "loading" || !room.host) return;
  if (![...room.clients.values()].every(c => c.progress >= 100)) return;
  if (!isGhost(room)) {
    for (const c of room.clients.values()) c.ready = "ready";
    return setPhase(room, "playing");
  }
  // Ghost: the first time everyone is loaded the countdown starts by itself; after an abort the host restarts it.
  if (room.staged) return;
  room.staged = true;
  runCountdown(room, () => setPhase(room, "playing"));
}

wss.on("connection", (ws, session, ip) => {
  let me = { id: nextId++, ws, room: null, slot: -1, name: session.name, key: session.id, ready: "notready", progress: 0, voice: false,
    rom: null, ghost: false, token: crypto.randomBytes(18).toString("base64url"), away: false, awayT: null };
  ws.isAlive = true; ws.missed = 0;
  ws.on("pong", () => { ws.isAlive = true; ws.missed = 0; if (ws.pingAt) ws.rtt = Date.now() - ws.pingAt; });
  ws.on("message", raw => {
    // Flood guard: a normal client sends a few messages a second (bursts of ICE candidates are well under this).
    const now = Date.now();
    if (now - (ws.win || 0) >= 1000) { ws.win = now; ws.n = 0; }
    if (++ws.n > WS_RATE_MAX) { me.left = true; return ws.close(1008, "Too many messages"); }
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (!m || typeof m !== "object" || typeof m.t !== "string") return;
    if (m.t === "ping") return send(me, { t: "pong", ts: m.ts });
    if (m.t === "lobby") { lobbyWatchers.add(ws); return send(me, { t: "rooms", rooms: roomList() }); }
    if (m.t === "join" && !me.room) {
      const code = cleanCode(m.room);
      if (!code) return send(me, { t: "error", msg: "Missing room code." });
      let room = rooms.get(code);
      if (room) {
        // Resume: same account + the secret token from "joined" gets back the exact same player (id, seat, ready, ROM).
        const mineAway = [...room.clients.values()].filter(c => c.away && c.key === me.key);
        let held = mineAway.find(c => tokenMatch(m.resume, c.token))
          // Planned reload (host migration): the seat was marked just before the page reloaded; same account only.
          || (m.handoff ? mineAway.find(c => c.handoff && Date.now() - c.handoff < RESUME_MS) : null);
        if (held) {
          clearTimeout(held.awayT); held.awayT = null; held.away = false; held.handoff = 0;
          held.ws = ws; lobbyWatchers.delete(ws);
          me = held;
          send(me, joinedMsg(room, me, { resumed: true }));
          send(me, { t: "chat-history", list: room.chat || [] });
          if (!room.host && promoteHost(room, "The host didn't come back.")) return;
          return sendRoster(room);
        }
        // Same account came back without the token (page reload): the old seat is released so the new join can take it.
        held = mineAway.find(c => (c === room.host) === (m.role === "host"));
        if (held) { finalizeLeave(room, held, true); room = rooms.get(code); me.reloaded = true; }
      }
      if (m.role === "host") {
        if (room && room.owner !== me.key) {
          return send(me, room.host
            ? { t: "error", code: "host-moved", msg: `${room.host.name} is hosting this lobby now. You can join it from the hosts list.` }
            : { t: "error", code: "host-taken", msg: "This lobby belongs to someone else." });
        }
        if (room?.host) return send(me, { t: "error", code: "host-taken", msg: "You are already hosting this lobby in another tab." });
        if (!room) {
          const pw = String(m.password || "").slice(0, 64);
          rooms.set(code, room = { code, host: null, owner: me.key, pw: pw ? hashLobbyPw(pw) : null,
            reserved: new Set(), clients: new Map(), game: "", system: "", phase: "lobby", cd: null, staged: false,
            rules: { spectators: true, mode: m.mode === "ghost" ? "ghost" : "coop" } });
          room.game = cleanText(m.game, 80);
          room.system = SYSTEMS[m.system] ? m.system : "";
        }
        const local = Array.isArray(m.local) ? m.local.filter(n => Number.isInteger(n) && n >= 0 && n < MAX_PLAYERS) : [];
        room.reserved = new Set(local.length && !isGhost(room) ? local : [0]);
        me.rom = cleanRom(m.rom);
        for (const c of room.clients.values()) if (room.reserved.has(c.slot)) c.slot = -1;
        for (const c of room.clients.values()) if (c.slot < 0 && c.wasSeated) c.slot = freeSlot(room);
        me.slot = Math.min(...room.reserved);
        if (room.phase === "loading" || room.phase === "playing") { me.ready = "ready"; me.progress = Number(m.progress) || 0; }
        room.host = me;
      } else {
        if (!room) return send(me, { t: "error", code: "no-room", msg: "No lobby with this code is open right now." });
        const rlKey = "lobby:" + ip;
        if (rateLimited(rlKey)) return send(me, { t: "error", code: "limited", msg: "Too many wrong passwords. Try again in 15 minutes." });
        if (!checkLobbyPw(room, m.password)) {
          if (m.password) noteFailure(rlKey);
          return send(me, { t: "error", code: "password", msg: m.password ? "Wrong lobby password." : "This lobby needs a password." });
        }
        if (room.clients.size >= MAX_CLIENTS) return send(me, { t: "error", code: "full", msg: "Lobby is full." });
        const watch = !!m.spectate;
        me.slot = watch ? -1 : (Number.isInteger(m.slot) && m.slot >= 0 && m.slot < MAX_PLAYERS && !slotTaken(room, m.slot) ? m.slot : freeSlot(room));
        if (!watch && me.slot < 0) {
          return send(me, { t: "error", code: "full", msg: room.rules.spectators ? "All player slots are taken. You can still watch." : "Lobby is full.",
            watchable: room.rules.spectators });
        }
        if (watch && !room.rules.spectators) return send(me, { t: "error", code: "no-spectators", msg: "This lobby doesn't allow spectators." });
        me.wasSeated = me.slot >= 0;
        me.rom = cleanRom(m.rom);
        if (room.phase === "loading" || room.phase === "playing") me.ready = "loading";
      }
      me.room = room; room.clients.set(me.id, me);
      send(me, joinedMsg(room, me));
      send(me, { t: "chat-history", list: room.chat || [] });
      if (!me.reloaded && (room.host !== me || room.clients.size > 1)) chatSys(room, `${me.name} joined${me.slot < 0 ? " to watch" : ""}.`);
      if (!room.host && promoteHost(room, "The host didn't come back.")) return;
      return sendRoster(room);
    }
    const room = me.room; if (!room) return;
    const isHost = room.host === me;
    switch (m.t) {
      case "signal": {
        const target = room.clients.get(m.to);
        if (!target || (!isHost && target !== room.host)) return;
        return send(target, { t: "signal", from: me.id, data: m.data });
      }
      case "ready": {
        const staged = room.staged && (room.phase === "loading" || room.phase === "countdown");
        if (room.phase !== "lobby" && room.phase !== "countdown" && !staged) return;
        const want = m.state === "ready" ? "ready" : "notready";
        if (want === "ready" && isGhost(room) && me.slot >= 0 && !me.rom) {
          return send(me, { t: "notice", msg: "Load your own copy of the game (ROM) before you ready up." });
        }
        if (want === "ready" && staged && me.progress < 100) return;
        me.ready = want;
        if (me.ready === "notready") cancelCountdown(room, `${me.name} is no longer ready.`);
        return sendRoster(room);
      }
      case "rom": {     // ghost mode: checksum of the player's own ROM file (the file itself never leaves their browser)
        if (room.phase !== "lobby" && room.phase !== "countdown" && room.phase !== "loading") return;
        const rom = cleanRom(m.rom);
        if (JSON.stringify(rom) === JSON.stringify(me.rom)) return;
        me.rom = rom;
        if (room.phase !== "loading") {
          if (isHost) {     // the reference ROM changed: everyone re-checks and readies again
            cancelCountdown(room, "The host loaded a different ROM.");
            for (const c of room.clients.values()) c.ready = "notready";
          } else if (me.ready === "ready") { me.ready = "notready"; cancelCountdown(room, `${me.name} changed their ROM.`); }
        }
        return sendRoster(room);
      }
      case "ghost": { me.ghost = !!m.on; return sendRoster(room); }
      case "rules": {
        if (!isHost || room.staged || (room.phase !== "lobby" && room.phase !== "countdown")) return;
        const before = JSON.stringify([room.game, room.system, room.rules]);
        if (typeof m.game === "string") room.game = cleanText(m.game, 80);
        if (typeof m.system === "string" && SYSTEMS[m.system]) room.system = m.system;
        if (typeof m.spectators === "boolean") room.rules.spectators = m.spectators;
        if (m.mode === "ghost" || m.mode === "coop") {
          room.rules.mode = m.mode;
          if (m.mode === "ghost") room.reserved = new Set([room.host.slot]);   // one player per computer in ghost mode
        }
        if (JSON.stringify([room.game, room.system, room.rules]) === before) return;
        cancelCountdown(room, "The host changed the rules.");
        for (const c of room.clients.values()) c.ready = "notready";
        broadcast(room, { t: "notice", msg: "The host changed the game or rules. Everyone needs to ready up again." });
        return sendRoster(room);
      }
      case "start": {
        if (!isHost) return;
        const waiting = needsReady(room).filter(c => c.ready !== "ready");
        if (room.phase === "loading" && room.staged) {     // ghost: restart the countdown after an abort
          if (![...room.clients.values()].every(c => c.progress >= 100)) return send(me, { t: "notice", msg: "Someone is still loading." });
          if (waiting.length) return send(me, { t: "notice", msg: `Waiting for ${waiting.map(c => c.name).join(", ")} to ready up.` });
          runCountdown(room, () => setPhase(room, "playing"));
          return sendRoster(room);
        }
        if (room.phase !== "lobby") return;
        if (waiting.length) return send(me, { t: "notice", msg: `Waiting for ${waiting.map(c => c.name).join(", ")} to ready up.` });
        if (isGhost(room)) {
          if (!me.rom) return send(me, { t: "notice", msg: "Load your ROM first." });
          room.staged = false;
          setPhase(room, "loading");
          return sendRoster(room);
        }
        runCountdown(room, () => setPhase(room, "loading"));
        return sendRoster(room);
      }
      case "abort": {
        if (isHost && cancelCountdown(room, "The host stopped the countdown.")) sendRoster(room);
        return;
      }
      case "progress": {
        if (room.phase !== "loading" && room.phase !== "playing") return;
        const pct = Math.max(0, Math.min(100, Math.round(Number(m.pct) || 0)));
        if (pct === me.progress) return;
        me.progress = pct;
        if (pct >= 100 && (room.phase === "playing" || (isGhost(room) && me.ready === "loading"))) me.ready = "ready";
        checkLoaded(room);
        return sendRoster(room);
      }
      case "slot": {     // move yourself to an empty seat (also leaves spectating)
        const s = Number(m.slot);
        if (!Number.isInteger(s) || s < 0 || s >= MAX_PLAYERS || isHost || room.phase === "countdown" || slotTaken(room, s)) return;
        if (isGhost(room) && room.phase !== "lobby" && me.slot < 0) return;   // a ghost run can't be joined from the stands
        me.slot = s; me.wasSeated = true; me.ready = room.phase === "lobby" ? "notready" : me.ready;
        return sendRoster(room);
      }
      case "swap": {     // host swaps two guest seats (either may be empty)
        if (!isHost || room.phase === "countdown" || (isGhost(room) && room.phase !== "lobby")) return;
        const a = Number(m.a), b = Number(m.b);
        if (![a, b].every(s => Number.isInteger(s) && s >= 0 && s < MAX_PLAYERS && !room.reserved.has(s)) || a === b) return;
        const ca = [...room.clients.values()].find(c => c.slot === a), cb = [...room.clients.values()].find(c => c.slot === b);
        if (ca) ca.slot = b; if (cb) cb.slot = a;
        return sendRoster(room);
      }
      case "spectate": {
        if (isHost || room.phase === "countdown") return;
        if (isGhost(room) && room.phase !== "lobby") return send(me, { t: "notice", msg: "Seats are locked while a ghost run is in progress." });
        if (m.on) {
          if (!room.rules.spectators) return send(me, { t: "notice", msg: "This lobby doesn't allow spectators." });
          me.slot = -1; me.wasSeated = false;
        } else if (me.slot < 0) {
          const s = freeSlot(room, me);
          if (s < 0) return send(me, { t: "notice", msg: "No free player slot." });
          me.slot = s; me.wasSeated = true; if (room.phase === "lobby") me.ready = "notready";
        }
        return sendRoster(room);
      }
      case "voice": { me.voice = !!m.on; return sendRoster(room); }
      case "chat": {
        // Clients render chat as plain text, so only control characters are removed ("<3" survives).
        const text = String(m.text ?? "").replace(/[\x00-\x1f\x7f]/g, " ").trim().slice(0, CHAT_MAX);
        if (!text) return;
        if (!chatAllowed(me)) return send(me, { t: "notice", msg: "Slow down a little: too many chat messages." });
        return chat(room, { from: me.id, name: me.name, key: me.key, slot: me.slot, text });
      }
      case "savestate": {     // co-op host saved or loaded a save state (the state itself travels peer to peer)
        if (!isHost || isGhost(room) || room.phase !== "playing" || !chatAllowed(me)) return;
        const label = cleanText(m.label, 60);
        if (m.act === "save") return chatSys(room, `${me.name} saved the game${label ? ` (${label})` : ""}.`);
        if (m.act === "load") return chatSys(room, `${me.name} loaded a save${label ? `: ${label}` : ""}.`);
        return;
      }
      case "leave": { me.left = true; return; }               // sent right before an intentional close: no resume window
      case "handoff": { me.handoff = Date.now(); return; }   // about to reload into a new role: keep the seat
    }
  });
  ws.on("close", () => {
    lobbyWatchers.delete(ws);
    const room = me.room; if (!room || me.ws !== ws) return;     // a resumed client's old socket closing changes nothing
    if (me.left) return finalizeLeave(room, me);
    // Wi-Fi blip etc.: keep the seat for RESUME_MS. WebRTC links usually survive a hub drop, and the same id keeps them.
    me.away = true;
    const c = me;
    c.awayT = setTimeout(() => finalizeLeave(room, c), RESUME_MS);
    cancelCountdown(room, `${me.name} lost connection.`);
    sendRoster(room);
  });
});
// Heartbeat every 5 s: measures each socket's round-trip time; drops sockets that miss 3 in a row.
setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive && ++ws.missed >= 3) { ws.terminate(); continue; }
    ws.isAlive = false; ws.pingAt = Date.now(); ws.ping();
  }
}, 5000).unref();
// Latency changes: refresh the hosts list and rosters every 5 s.
setInterval(() => { if (rooms.size) { pushRoomList(); for (const r of rooms.values()) if (r.clients.size > 1) sendRoster(r); } }, 5000).unref();

// ---------------------------------------------------------------- shutdown
// Every way of stopping ends here: Ctrl+C, closing the window, `docker stop` (SIGTERM; without a handler Node
// running as PID 1 in a container ignores it and Docker has to kill it after 10 s), stop.py / stop.bat / stop.sh,
// or the owner's "Shut down server" button. Players are told, sockets close, the run file is removed, and the
// process exits; if anything hangs, it is forced out after 3 s.
let stopping = false;
function shutdown(reason) {
  if (stopping) return;
  stopping = true;
  console.log(`Shutting down (${reason})…`);
  const bye = JSON.stringify({ t: "shutdown", msg: "The Retro Hub server was shut down." });
  for (const ws of wss.clients) { try { ws.send(bye); ws.close(1001, "Server shutting down"); } catch {} }
  for (const room of rooms.values()) clearTimeout(room.cd);
  removeRunFile();
  server.close(() => process.exit(0));
  setTimeout(() => { for (const ws of wss.clients) ws.terminate(); process.exit(0); }, 3000).unref();
}
for (const sig of ["SIGINT", "SIGTERM", "SIGHUP", "SIGBREAK"]) { try { process.on(sig, () => shutdown(sig)); } catch {} }
process.on("exit", removeRunFile);

// run/retro-hub.json tells stop.py which process and port this is, plus a random token that only someone who
// can read this folder knows. Readable by this user only; deleted on exit. Never sent to browsers.
const RUN_FILE = path.join(ROOT, "run", "retro-hub.json");
const SHUTDOWN_TOKEN = crypto.randomBytes(24).toString("base64url");
function writeRunFile() {
  try {
    fs.mkdirSync(path.dirname(RUN_FILE), { recursive: true });
    fs.writeFileSync(RUN_FILE, JSON.stringify({ pid: process.pid, port: PORT, token: SHUTDOWN_TOKEN, started: new Date().toISOString() }), { mode: 0o600 });
  } catch (e) { console.warn(`Could not write ${RUN_FILE} (${e.code}); stop.py will fall back to finding the process by port.`); }
}
function removeRunFile() {
  try { if (JSON.parse(fs.readFileSync(RUN_FILE, "utf8")).pid === process.pid) fs.unlinkSync(RUN_FILE); } catch {}
}
function isLoopback(req) {
  const a = req.socket.remoteAddress || "";
  return a === "127.0.0.1" || a === "::1" || a === "::ffff:127.0.0.1";
}

server.listen(PORT, HOST, () => {
  writeRunFile();
  console.log(`Retro Hub v${APP_VERSION} on http://localhost:${PORT}  (roms: ${ROMS_DIR}, core cache: ${CORES_CACHE}, library: ${LIBRARY_ACCESS})`);
  if (PUBLIC_URL) console.log(`Public address (used in invite links): ${PUBLIC_URL}`);
  console.log("Stop it with Ctrl+C, stop.bat / stop.sh / python stop.py, or 'docker compose down' for Docker.");
});
