// Retro netplay hub server.
// - Local accounts: each browser holds its own Ed25519 key; the server only verifies a signed one-time
//   challenge and issues a session cookie. No passwords, no account database: nothing about accounts is stored.
// - Every host sets its own lobby password; guests must know it to join that lobby
// - Owner-only ROM library (ROMS_DIR): unlocked by ADMIN_KEYS (account IDs) or the ADMIN_PASSWORD unlock
// - EmulatorJS served locally; missing cores are fetched once from the official CDN and cached (CORES_CACHE)
// - Room signaling + live open-rooms list over WebSocket (/ws)
// - COOP/COEP/CORP headers so SharedArrayBuffer (threaded cores) works
import http from "node:http";
import https from "node:https";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { WebSocketServer } from "ws";
import { createNative, nativeSystems } from "./core/streaming/native.mjs";
import { createDiscovery, createMasterPool } from "./core/net/discovery.mjs";
import { createLink, sha1File, LINK_PORT } from "./core/net/link.mjs";
import { createRetroAchievements } from "./core/net/retroachievements.mjs";
import { createCovers } from "./core/net/covers.mjs";
import os from "node:os";

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(ROOT, "public");
const NATIVE_SYSTEMS = nativeSystems(path.dirname(fileURLToPath(import.meta.url)), process.env.EMULATORS_DIR);
const ROMS_DIR = path.resolve(process.env.ROMS_DIR || path.join(ROOT, "roms"));
const CORES_CACHE = path.resolve(process.env.CORES_CACHE || path.join(ROOT, "cache", "cores"));
const CACHE_DIR = path.dirname(CORES_CACHE);      // cache/ (Docker: /cache): covers and RetroAchievements lists live here too
const PORT = Number(process.env.PORT || 8080);
const HOST = process.env.HOST || "0.0.0.0";
const MAX_PLAYERS = Math.min(4, Math.max(2, Number(process.env.MAX_PLAYERS || 4)));
const LIBRARY_ACCESS = process.env.LIBRARY_ACCESS === "all" ? "all" : "admin";
const TRUST_PROXY = process.env.TRUST_PROXY === "1";
// Public address of this hub (e.g. a Cloudflare tunnel). Invite links use it, so a host who opened the hub
// on localhost still copies a link that works for friends. Only a plain https?://host[:port] origin is accepted.
const PUBLIC_URL = (() => {
  const raw = String(process.env.PUBLIC_URL || "").trim();
  if (!raw) return "";
  try { const u = new URL(raw); if (u.protocol === "https:" || u.protocol === "http:") return u.origin; } catch {}
  console.warn(`PUBLIC_URL ${JSON.stringify(raw)} is not an http(s) address; ignoring it.`);
  return "";
})();
const EJS_VERSION = "4.2.3";
const APP_VERSION = JSON.parse(fs.readFileSync(path.join(ROOT, "package.json"), "utf8")).version;
const CTRL_RE = /[\x00-\x1f<>]/g;

// ---------------------------------------------------------------- auth
const ACCESS_PASSWORD = process.env.ACCESS_PASSWORD || "";   // optional server-wide access code
// Placeholder passwords from old examples count as unset, so a copied sample config never opens the library.
const WEAK_ADMIN = new Set(["change-me", "change-me-owner", "changeme", "owner", "password", "admin"]);
const ADMIN_PASSWORD = (() => {
  const p = process.env.ADMIN_PASSWORD || "";
  if (p && (WEAK_ADMIN.has(p.toLowerCase()) || p.length < 8)) {
    console.warn("ADMIN_PASSWORD is a placeholder or shorter than 8 characters; ignoring it. Set a real one in .env.");
    return "";
  }
  return p;
})();
const ADMIN_KEYS = new Set((process.env.ADMIN_KEYS || "").split(",").map(s => s.trim().toUpperCase()).filter(Boolean));
if (!ADMIN_PASSWORD && !ADMIN_KEYS.size) console.warn("Neither ADMIN_KEYS nor ADMIN_PASSWORD is set; nobody can use the server ROM library.");
// Cookie signing key: SESSION_SECRET, else a random key kept next to the core cache so sessions survive restarts
// (a host mid-game would otherwise be sent back to the account page).
function loadSecret() {
  if (process.env.SESSION_SECRET) return crypto.createHash("sha256").update(process.env.SESSION_SECRET).digest();
  const file = path.join(path.dirname(CORES_CACHE), "session.key");
  try { const k = fs.readFileSync(file); if (k.length === 32) return k; } catch {}
  const k = crypto.randomBytes(32);
  try { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, k, { mode: 0o600 }); }
  catch (e) { console.warn(`Could not save ${file} (${e.code}); everyone will be signed out when the server restarts.`); }
  return k;
}
const SECRET = loadSecret();
const SESSION_DAYS = 30;

const sha = s => crypto.createHash("sha256").update(String(s)).digest();
const same = (a, b) => b !== "" && crypto.timingSafeEqual(sha(a), sha(b));
const sign = data => crypto.createHmac("sha256", SECRET).update(data).digest("base64url");

function makeToken(name, role, id) {
  const body = Buffer.from(JSON.stringify({ n: name, r: role, k: id, e: Date.now() + SESSION_DAYS * 864e5 })).toString("base64url");
  return body + "." + sign(body);
}
const setSession = (req, res, name, role, id) => res.setHeader("Set-Cookie",
  `hub=${makeToken(name, role, id)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${SESSION_DAYS * 86400}${isHttps(req) ? "; Secure" : ""}`);

// One-time challenges for the key handshake: nonce -> expiry
const challenges = new Map();
const CHALLENGE_MS = 120e3;
function newChallenge() {
  if (challenges.size > 5000) { const now = Date.now(); for (const [k, v] of challenges) if (v < now) challenges.delete(k); }
  if (challenges.size > 5000) return null;
  const nonce = crypto.randomBytes(24).toString("base64url");
  challenges.set(nonce, Date.now() + CHALLENGE_MS);
  return nonce;
}
const B64U = /^[A-Za-z0-9_-]+$/;
// Accounts are Ed25519 keys (tweetnacl in the browser, so it also works over plain-HTTP LAN addresses).
// Account ID = first 16 hex chars of SHA-512 over the raw public key, shown to users as ABCD-EF01-2345-6789.
const accountId = pubBytes => crypto.createHash("sha512").update(pubBytes).digest("hex").slice(0, 16).toUpperCase();
function verifyHello(body) {
  const { pub, nonce, sig } = body || {};
  if (typeof pub !== "string" || pub.length !== 43 || !B64U.test(pub)) return null;
  if (typeof nonce !== "string" || typeof sig !== "string" || sig.length !== 86 || !B64U.test(sig)) return null;
  const exp = challenges.get(nonce);
  challenges.delete(nonce);
  if (!exp || exp < Date.now()) return null;
  try {
    const key = crypto.createPublicKey({ key: { kty: "OKP", crv: "Ed25519", x: pub }, format: "jwk" });
    const ok = crypto.verify(null, Buffer.from(`retro-hub-login\n${nonce}`), key, Buffer.from(sig, "base64url"));
    return ok ? accountId(Buffer.from(pub, "base64url")) : null;
  } catch { return null; }
}
function readSession(req) {
  const m = /(?:^|;\s*)hub=([^;]+)/.exec(req.headers.cookie || "");
  if (!m) return null;
  const [body, mac] = m[1].split(".");
  if (!body || !mac) return null;
  const expect = sign(body);
  if (mac.length !== expect.length || !crypto.timingSafeEqual(Buffer.from(mac), Buffer.from(expect))) return null;
  try {
    const s = JSON.parse(Buffer.from(body, "base64url").toString());
    return s.e > Date.now() && s.k ? { name: s.n, role: s.r, id: s.k } : null;
  } catch { return null; }
}
const canLibrary = s => !!s && (s.role === "admin" || LIBRARY_ACCESS === "all");
// Behind a proxy every visitor arrives from the proxy's address, so rate limits would lump everyone together.
// Forwarded headers are trusted with TRUST_PROXY=1, or automatically when the proxy runs on this same computer
// (loopback peer: a local cloudflared / Caddy / nginx). Cloudflare's CF-Connecting-IP wins over X-Forwarded-For.
function clientIp(req) {
  const peer = req.socket.remoteAddress;
  if (!TRUST_PROXY && !isLoopback(req)) return peer;
  const cf = String(req.headers["cf-connecting-ip"] || "").trim();
  const xff = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim();
  return (cf || xff).slice(0, 64) || peer;
}
const isHttps = req => !!req.socket.encrypted || String(req.headers["x-forwarded-proto"] || "").startsWith("https");

const failures = new Map(); // ip -> { n, until }
const rateLimited = ip => { const f = failures.get(ip); return !!f && f.n >= 10 && f.until > Date.now(); };
function noteFailure(ip) {
  const f = failures.get(ip);
  if (!f || f.until < Date.now()) failures.set(ip, { n: 1, until: Date.now() + 15 * 60e3 });
  else f.n++;
}
setInterval(() => { const now = Date.now(); for (const [k, v] of failures) if (v.until < now) failures.delete(k); }, 60e3).unref();

// ---------------------------------------------------------------- systems
// EmulatorJS system ids; recognised by folder name first, then by unambiguous extension.
const SYSTEMS = {
  n64:       { label: "Nintendo 64", ext: ["z64", "n64", "v64"], dirs: ["n64", "nintendo64"] },
  nes:       { label: "NES", ext: ["nes", "fds", "unf", "unif"], dirs: ["nes", "famicom"] },
  snes:      { label: "SNES", ext: ["sfc", "smc", "fig", "swc"], dirs: ["snes", "supernintendo", "superfamicom", "sfc"] },
  gb:        { label: "Game Boy / Color", ext: ["gb", "gbc", "dmg"], dirs: ["gb", "gbc", "gameboy", "gameboycolor"] },
  gba:       { label: "Game Boy Advance", ext: ["gba"], dirs: ["gba", "gameboyadvance"] },
  nds:       { label: "Nintendo DS", ext: ["nds"], dirs: ["nds", "nintendods"] },
  psx:       { label: "PlayStation", ext: ["pbp", "chd", "m3u", "ecm"], dirs: ["psx", "ps1", "playstation", "playstation1", "psone"] },
  segaMD:    { label: "Genesis / Mega Drive", ext: ["md", "gen", "smd"], dirs: ["genesis", "megadrive", "md", "segamd"] },
  segaMS:    { label: "Master System", ext: ["sms"], dirs: ["sms", "mastersystem"] },
  segaGG:    { label: "Game Gear", ext: ["gg"], dirs: ["gg", "gamegear"] },
  segaCD:    { label: "Sega CD", ext: [], dirs: ["segacd", "megacd"] },
  sega32x:   { label: "Sega 32X", ext: ["32x"], dirs: ["32x", "sega32x"] },
  segaSaturn:{ label: "Saturn", ext: [], dirs: ["saturn", "segasaturn"] },
  atari2600: { label: "Atari 2600", ext: ["a26"], dirs: ["atari2600", "2600"] },
  atari7800: { label: "Atari 7800", ext: ["a78"], dirs: ["atari7800", "7800"] },
  lynx:      { label: "Atari Lynx", ext: ["lnx"], dirs: ["lynx", "atarilynx"] },
  jaguar:    { label: "Atari Jaguar", ext: ["j64", "jag"], dirs: ["jaguar", "atarijaguar"] },
  pce:       { label: "PC Engine / TG-16", ext: ["pce"], dirs: ["pce", "pcengine", "tg16", "turbografx", "turbografx16"] },
  ngp:       { label: "Neo Geo Pocket", ext: ["ngp", "ngc"], dirs: ["ngp", "ngpc", "neogeopocket"] },
  ws:        { label: "WonderSwan", ext: ["ws", "wsc"], dirs: ["wonderswan", "wsc"] },
  vb:        { label: "Virtual Boy", ext: ["vb", "vboy"], dirs: ["virtualboy", "vb"] },
  coleco:    { label: "ColecoVision", ext: ["col"], dirs: ["coleco", "colecovision"] },
  arcade:    { label: "Arcade (FBNeo)", ext: [], dirs: ["arcade", "fbneo", "fba", "neogeo"] },
  psp:       { label: "PSP", ext: ["cso"], dirs: ["psp"] },
};
// Native emulators and PC games (core/runner/catalog.json + emulators/apps.json, run by apps.py): they run on the
// host's computer, not in the browser. A built-in EmulatorJS console with the same id is never replaced.
for (const [id, s] of Object.entries(NATIVE_SYSTEMS)) if (!SYSTEMS[id]) SYSTEMS[id] = { label: s.label, ext: s.ext, dirs: s.dirs, native: true };
const native = createNative({ root: ROOT, emulatorsDir: process.env.EMULATORS_DIR });
// Folder names each built-in emulator is found in (emulators/<folder>/), so "Check for Emus" can spot unknown folders.
const NATIVE_FOLDERS = (() => {
  try {
    const cat = JSON.parse(fs.readFileSync(path.join(ROOT, "core", "runner", "catalog.json"), "utf8"));
    return Object.fromEntries(Object.entries(cat.emulators || {}).map(([id, e]) => [id, e.folders || [id]]));
  } catch { return {}; }
})();
const LOCAL_ONLY = "Library folders can only be changed by the owner, from a browser on the hub's own computer.";
const isNativeSys = id => !!SYSTEMS[id]?.native;
const AMBIGUOUS = ["zip", "7z", "bin", "iso", "cue", "img"];
const norm = s => s.toLowerCase().replace(/[\s_.-]/g, "");
const EXT_TO_SYS = {}, DIR_TO_SYS = {};
for (const [id, s] of Object.entries(SYSTEMS)) {
  // First console wins an extension: built-in browser consoles come first, so a native alternative for the same
  // files (melonDS for .nds) only takes games from its own folders (dirs / library folder), never all of them.
  for (const e of s.ext) if (!EXT_TO_SYS[e]) EXT_TO_SYS[e] = id;
  for (const d of s.dirs) DIR_TO_SYS[norm(d)] = id;
}
const ROM_EXTS = new Set([...Object.keys(EXT_TO_SYS), ...AMBIGUOUS]);
const COVER_EXTS = new Set(["png", "jpg", "jpeg", "webp"]);

function detectSystem(relPath) {
  const parts = relPath.split("/");
  for (let i = parts.length - 2; i >= 0; i--) {
    const sys = DIR_TO_SYS[norm(parts[i])];
    if (sys) return sys;
  }
  return EXT_TO_SYS[path.extname(relPath).slice(1).toLowerCase()] || null;
}

// Per-console library folders, set by the owner in the hub ("Library folders"). A game in one of them gets the
// path "@<console>/<file inside it>"; everything else stays relative to ROMS_DIR.
const LIB_FOLDERS_FILE = path.join(ROOT, "library-folders.json");
let libFolders = {};
try {
  const raw = JSON.parse(fs.readFileSync(LIB_FOLDERS_FILE, "utf8"));
  for (const [k, v] of Object.entries(raw || {})) if (SYSTEMS[k] && typeof v === "string" && path.isAbsolute(v)) libFolders[k] = path.resolve(v);
} catch {}
function saveLibFolders() {
  const tmp = LIB_FOLDERS_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(libFolders, null, 2) + "\n");
  fs.renameSync(tmp, LIB_FOLDERS_FILE);
}
// Library path -> file on disk (null when it points outside its folder).
function romFile(rel) {
  const m = /^@([a-z0-9]{1,20})\/(.+)$/i.exec(rel);
  if (!m) return safeJoin(ROMS_DIR, rel);
  const base = libFolders[m[1]];
  return base ? safeJoin(base, m[2]) : null;
}

let libCache = { at: 0, list: [] };
const coverArt = createCovers({ cacheDir: CACHE_DIR, onChange: () => { libCache.at = 0; } });
const retroAch = await createRetroAchievements({ cacheDir: CACHE_DIR });
// Library entry + file on disk for a library path (owner / library users only).
function libEntry(rel, session) {
  if (!canLibrary(session)) return null;
  const entry = scanLibrary().find(g => g.path === String(rel || "") && !g.app);
  const file = entry && romFile(entry.path);
  return file ? { entry, file, system: entry.system, ext: entry.ext } : null;
}
function readRaw(req, limit) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on("data", c => { size += c.length; if (size > limit) { reject(new Error("too big")); req.destroy(); } else chunks.push(c); });
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}
function scanLibrary() {
  if (Date.now() - libCache.at < 30e3) return libCache.list;
  const out = [];
  // Optional cover art: "<game>.png|jpg|jpeg|webp" next to the ROM, or in a covers/ boxart/ media/ subfolder.
  const imagesIn = (dir, rel) => {
    const map = new Map();
    const add = (d, r) => {
      let es; try { es = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
      for (const e of es) if (e.isFile() && COVER_EXTS.has(path.extname(e.name).slice(1).toLowerCase()))
        map.set(e.name.replace(/\.[^.]+$/, "").toLowerCase(), r ? r + "/" + e.name : e.name);
    };
    add(dir, rel);
    for (const sub of ["covers", "boxart", "media"]) add(path.join(dir, sub), rel ? rel + "/" + sub : sub);
    return map;
  };
  const seen = new Set();
  // forced: a console's own library folder, so every matching file in it is that console's.
  const walk = (dir, rel, depth, forced) => {
    let entries; try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    let covers = null;
    for (const d of entries) {
      if (d.name.startsWith(".")) continue;
      const r = rel ? rel + "/" + d.name : d.name;
      if (d.isDirectory()) { if (depth < 5 && !/^(bios|covers|boxart|media)$/i.test(d.name)) walk(path.join(dir, d.name), r, depth + 1, forced); continue; }
      if (!d.isFile()) continue;
      const ext = path.extname(d.name).slice(1).toLowerCase();
      if (!ROM_EXTS.has(ext)) continue;
      const system = forced ? (SYSTEMS[forced].ext.includes(ext) || AMBIGUOUS.includes(ext) ? forced : null) : detectSystem(r);
      if (!system) continue;
      const abs = path.join(dir, d.name).toLowerCase();
      if (seen.has(abs)) continue;        // a console folder inside ROMS_DIR: list each game once
      seen.add(abs);
      let size = 0; try { size = fs.statSync(path.join(dir, d.name)).size; } catch {}
      let name = d.name.replace(/\.[^.]+$/, "");
      if (system === "ps3" && ext === "bin") {
        // PS3 games are folders: list <Game>/PS3_GAME/USRDIR/EBOOT.BIN (or <Game>/USRDIR/EBOOT.BIN) as "<Game>".
        if (d.name.toLowerCase() !== "eboot.bin") continue;
        const up = r.split("/").slice(0, -1);
        if (up.pop()?.toUpperCase() !== "USRDIR") continue;
        if (up[up.length - 1]?.toUpperCase() === "PS3_GAME") up.pop();
        name = up[up.length - 1] || name;
      }
      covers = covers || imagesIn(dir, rel);
      const cached = covers.get(name.toLowerCase()) ? null : coverArt.find(system, name);      // a cover next to the ROM wins
      out.push({ path: r, name, ext, system, size, cover: covers.get(name.toLowerCase()) || (cached ? "~cache/" + cached : null),
        ...(isNativeSys(system) ? { native: true } : {}) });
    }
  };
  for (const [sys, dir] of Object.entries(libFolders)) walk(dir, "@" + sys, 0, sys);
  walk(ROMS_DIR, "", 0);
  // EmulatorJS needs one file per game: hide .cue sheets and extra audio tracks of multi-track .bin dumps
  const list = out.filter(r => r.ext !== "cue" && !(r.ext === "bin" && /\(track 0*([2-9]|\d{2,})\)/i.test(r.name)));
  list.sort((a, b) => a.system.localeCompare(b.system) || a.name.localeCompare(b.name));
  list.push(...native.pcGames());     // PC games registered with apps.py (no file in the ROM folder)
  libCache = { at: Date.now(), list };
  coverArt.want(list.filter(g => !g.cover && !g.app));      // auto covers (when the owner turned them on)
  return list;
}

// ---------------------------------------------------------------- static files
const MIME = {
  ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8", ".wasm": "application/wasm",
  ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon",
  ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp",
  ".zip": "application/zip", ".7z": "application/x-7z-compressed",
};
function baseHeaders(res) {
  res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
  res.setHeader("Cross-Origin-Embedder-Policy", "require-corp");
  res.setHeader("Cross-Origin-Resource-Policy", "same-origin");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "same-origin");
  res.setHeader("Content-Security-Policy", CSP);
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Permissions-Policy", "camera=(), geolocation=(), payment=(), usb=(), microphone=(self), fullscreen=(self), gamepad=(self)");
}
// Only this server's own scripts run: no inline scripts or handlers, no other hosts, and connections go to this
// server only ('self' covers its ws:/wss: socket too; it also blocks EmulatorJS's update check to its CDN).
// 'wasm-unsafe-eval' lets the emulator compile its WebAssembly cores; blob: is where EmulatorJS puts the core's
// unpacked script and its workers. 'unsafe-eval' is needed only because EmulatorJS's bundled 7-Zip decompressor
// (data/compression/extract7z.js, old Emscripten output) calls eval() inside a blob worker, which inherits this
// policy. Without it, cores never finish "Decompress Game Core".
const CSP = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-eval' 'wasm-unsafe-eval' blob:",
  "worker-src 'self' blob:",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob:",
  "media-src 'self' blob: mediastream:",
  "font-src 'self' data:",
  // ws://localhost:* : the optional LiveSplit Server mirror (race / speedrun timer), on the player's own PC only.
  "connect-src 'self' blob: data: ws://localhost:* ws://127.0.0.1:*",
  "object-src 'none'",
  "base-uri 'none'",
  "form-action 'self'",
  "frame-ancestors 'none'",
].join("; ");
function safeJoin(base, urlPath) {
  const p = path.resolve(base, "." + path.posix.normalize("/" + urlPath));
  return p === base || p.startsWith(base + path.sep) ? p : null;
}
function sendFile(req, res, file, cache = "no-cache", onMissing) {
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) {
      if (onMissing) return onMissing();
      res.writeHead(404); return res.end("Not found");
    }
    const type = MIME[path.extname(file).toLowerCase()] || "application/octet-stream";
    const headers = { "Content-Type": type, "Accept-Ranges": "bytes", "Cache-Control": cache };
    const range = req.headers.range && /bytes=(\d*)-(\d*)/.exec(req.headers.range);
    if (range && (range[1] || range[2])) {
      const start = range[1] ? Number(range[1]) : Math.max(0, st.size - Number(range[2]));
      const end = range[1] && range[2] ? Math.min(Number(range[2]), st.size - 1) : st.size - 1;
      if (start > end || start >= st.size) { res.writeHead(416, { "Content-Range": `bytes */${st.size}` }); return res.end(); }
      res.writeHead(206, { ...headers, "Content-Length": end - start + 1, "Content-Range": `bytes ${start}-${end}/${st.size}` });
      return req.method === "HEAD" ? res.end() : fs.createReadStream(file, { start, end }).pipe(res);
    }
    res.writeHead(200, { ...headers, "Content-Length": st.size });
    req.method === "HEAD" ? res.end() : fs.createReadStream(file).pipe(res);
  });
}

// ---------------------------------------------------------------- core cache (official CDN, pinned version)
const CORE_FILE_RE = /^(?:[a-z0-9_]+(?:-thread)?(?:-legacy)?-wasm\.data|reports\/[a-z0-9_]+\.json)$/;
const inflight = new Map();
function fetchCore(rel) {
  if (inflight.has(rel)) return inflight.get(rel);
  const dest = path.join(CORES_CACHE, rel);
  const url = `https://cdn.emulatorjs.org/${EJS_VERSION}/data/cores/${rel}`;
  const p = new Promise((resolve, reject) => {
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    const tmp = dest + ".part-" + process.pid;
    https.get(url, { timeout: 30e3 }, r => {
      if (r.statusCode !== 200) { r.resume(); return reject(new Error(`CDN ${r.statusCode} for ${rel}`)); }
      const out = fs.createWriteStream(tmp);
      r.pipe(out);
      out.on("finish", () => { fs.renameSync(tmp, dest); console.log(`cached core ${rel}`); resolve(dest); });
      out.on("error", e => { fs.rmSync(tmp, { force: true }); reject(e); });
      r.on("error", e => { out.destroy(); fs.rmSync(tmp, { force: true }); reject(e); });
    }).on("error", reject).on("timeout", function () { this.destroy(new Error("CDN timeout")); });
  }).finally(() => inflight.delete(rel));
  inflight.set(rel, p);
  return p;
}
function serveCore(req, res, rel) {
  const cache = "public, max-age=86400";
  sendFile(req, res, path.join(PUBLIC_DIR, "data", "cores", rel), cache,
    () => sendFile(req, res, path.join(CORES_CACHE, rel), cache,
      () => fetchCore(rel).then(f => sendFile(req, res, f, cache))
        .catch(e => { console.warn(e.message); res.writeHead(404); res.end(); })));
}

// ---------------------------------------------------------------- HTTP
const PUBLIC_PATHS = new Set(["/login.html", "/login.js", "/account.js", "/vendor/nacl-fast.min.js", "/style.css",
  "/api/challenge", "/favicon.ico"]);
const json = (res, code, obj) => { res.writeHead(code, { "Content-Type": "application/json", "Cache-Control": "no-store" }); res.end(JSON.stringify(obj)); };
function readBody(req, limit = 4096) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on("data", c => { size += c.length; if (size > limit) { reject(new Error("too big")); req.destroy(); } else chunks.push(c); });
    req.on("end", () => resolve(Buffer.concat(chunks).toString()));
    req.on("error", reject);
  });
}
function iceServers() {
  const list = (process.env.STUN_URLS || "stun:stun.l.google.com:19302")
    .split(",").map(s => s.trim()).filter(Boolean).map(urls => ({ urls }));
  if (process.env.TURN_URL) list.push({ urls: process.env.TURN_URL.split(",").map(s => s.trim()),
    username: process.env.TURN_USERNAME || "", credential: process.env.TURN_CREDENTIAL || "" });
  return list;
}

const server = http.createServer(async (req, res) => {
  baseHeaders(res);
  let urlPath;
  try { urlPath = decodeURIComponent(new URL(req.url, "http://x").pathname); }
  catch { res.writeHead(400); return res.end(); }

  if (urlPath === "/api/challenge" && req.method === "GET") {
    const nonce = newChallenge();
    if (!nonce) return json(res, 503, { error: "Server busy. Try again in a minute." });
    return json(res, 200, { nonce, accessCode: !!ACCESS_PASSWORD });
  }
  if (urlPath === "/api/hello" && req.method === "POST") {
    const ip = clientIp(req);
    if (rateLimited(ip)) return json(res, 429, { error: "Too many attempts. Try again in 15 minutes." });
    let body; try { body = JSON.parse(await readBody(req)); } catch { return json(res, 400, { error: "Bad request" }); }
    const name = String(body.name || "").replace(CTRL_RE, "").trim().slice(0, 20);
    if (!name) return json(res, 400, { error: "Your account needs a name." });
    if (ACCESS_PASSWORD && !same(String(body.access || ""), ACCESS_PASSWORD)) {
      noteFailure(ip); return json(res, 401, { error: "Wrong server access code.", code: "access" });
    }
    const id = verifyHello(body);
    // Not counted toward the IP lockout: a bad signature can't be guessed into a good one, and one broken account
    // in a browser must not block every other account on that computer for 15 minutes.
    if (!id) return json(res, 401, { error: "The server couldn't verify this account's key. Reload the page and try again; if it keeps failing, remove the account and import a backup." });
    failures.delete(ip);
    const role = ADMIN_KEYS.has(id) ? "admin" : "user";
    setSession(req, res, name, role, id);
    return json(res, 200, { ok: true, name, role, id });
  }
  if (urlPath === "/api/unlock" && req.method === "POST") {
    const s = readSession(req);
    if (!s) return json(res, 401, { error: "Login required" });
    const ip = clientIp(req);
    if (rateLimited(ip)) return json(res, 429, { error: "Too many attempts. Try again in 15 minutes." });
    let body; try { body = JSON.parse(await readBody(req)); } catch { return json(res, 400, { error: "Bad request" }); }
    if (!same(String(body.password || ""), ADMIN_PASSWORD)) { noteFailure(ip); return json(res, 401, { error: "Wrong owner password." }); }
    failures.delete(ip);
    setSession(req, res, s.name, "admin", s.id);
    return json(res, 200, { ok: true });
  }
  // Master lobby pool (MASTER_SERVER=1): other hubs register their lobbies here; anyone may read the list.
  if (masterPool && urlPath === "/api/master/heartbeat" && req.method === "POST") {
    let body; try { body = JSON.parse(await readBody(req, 16384)); } catch { return json(res, 400, { error: "Bad request" }); }
    const r = masterPool.heartbeat(body, clientIp(req));
    return json(res, r.status, r.error ? { error: r.error } : { ok: true });
  }
  if (masterPool && urlPath === "/api/master/lobbies" && req.method === "GET") return json(res, 200, { lobbies: masterPool.lobbies() });
  // GBA link cable, hub to hub on this network: another hub asks for (or gives back) a seat in our session.
  // Owner on this computer: switch Cemu's active account to the Pretendo network service (backs up settings.xml).
  if (urlPath === "/api/pretendo/enable" && req.method === "POST") {
    const s = readSession(req);
    if (!localOwner(req, s) || req.headers["x-retro-hub"] !== "pretendo") return json(res, 403, { error: "Only the owner, on the hub's own computer, can change Cemu's settings." });
    try { await native.pretendoEnable(); return json(res, 200, { ok: true, ...(await native.pretendoStatus(true)) }); }
    catch (e) { return json(res, 409, { error: e.message }); }
  }
  if ((urlPath === "/api/link/claim" || urlPath === "/api/link/release") && req.method === "POST") {
    if (!directLan(req)) return json(res, 403, { error: "Link cable sessions only work between computers on the same network." });
    const ip = req.socket.remoteAddress;
    if (linkThrottled(ip)) return json(res, 429, { error: "Too many requests" });
    let body; try { body = JSON.parse(await readBody(req)); } catch { return json(res, 400, { error: "Bad request" }); }
    const r = urlPath === "/api/link/claim" ? link.claim(body, ip) : link.release(body);
    if (r.status === 200) discovery.lobbiesChanged();
    const { status, ...rest } = r;
    return json(res, status, rest);
  }
  // Owner on this computer: host a link session, join one found on the LAN, or leave.
  if ((urlPath === "/api/link/host" || urlPath === "/api/link/join" || urlPath === "/api/link/stop") && req.method === "POST") {
    const s = readSession(req);
    if (!localOwner(req, s) || req.headers["x-retro-hub"] !== "link") return json(res, 403, { error: "Link sessions can only be started by the owner, from a browser on the hub's own computer." });
    let body; try { body = JSON.parse(await readBody(req)); } catch { return json(res, 400, { error: "Bad request" }); }
    if (urlPath === "/api/link/stop") {
      if (link.joined) releaseSeat(link.joined);
      link.stop("stopped by the owner");
      native.stopGame();
      discovery.lobbiesChanged();
      return json(res, 200, { ok: true });
    }
    libCache.at = 0;
    const lib = scanLibrary();
    try {
      if (urlPath === "/api/link/host") {
        const entry = lib.find(g => g.path === String(body.path || "") && isGbaGame(g));
        const file = entry && romFile(entry.path);
        if (!file) return json(res, 404, { error: "Pick a .gba, .gb or .gbc game from the server library." });
        const players = Math.max(2, Math.min(4, Number(body.players) | 0 || 4));
        const sha1 = await sha1File(file);
        if (link.joined) releaseSeat(link.joined);
        link.stop("replaced");
        await native.launch({ ...entry, system: "gbalink" }, file, { host: lanIp(), port: LINK_PORT, players, role: "server" });
        linkHostName = s.name;
        const h = link.host({ game: entry.name, system: entry.ext === "gba" ? "gba" : "gb", sha1, size: entry.size, players });
        discovery.lobbiesChanged();
        return json(res, 200, { ok: true, lobbyId: h.lobbyId, slot: 0, players, port: LINK_PORT, ip: lanIp() });
      }
      // join
      const l = discovery.list().find(x => x.is_lan && x.link && x.lobby_id === String(body.lobby_id || ""));
      if (!l) return json(res, 404, { error: "That link session isn't on the network any more." });
      const hostBase = new URL(l.connection_string).origin, hostIp = new URL(l.connection_string).hostname;
      let entry = null, file = null;
      for (const g of lib.filter(g => isGbaGame(g) && g.size === l.link.size)) {
        const f = romFile(g.path);
        if (f && await sha1File(f).catch(() => "") === l.link.sha1) { entry = g; file = f; break; }
      }
      if (!entry) return json(res, 404, { error: `You don't have this exact ROM ("${l.game_title}"). Link cables need the same file as the host: add it to your library (same SHA-1).` });
      const r = await fetch(`${hostBase}/api/link/claim`, { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ lobby_id: l.lobby_id, hub: discovery.hubId, name: s.name, sha1: l.link.sha1 }), signal: AbortSignal.timeout(6000) });
      const seat = await r.json().catch(() => ({}));
      if (!r.ok) return json(res, 409, { error: seat.error || `The host's hub said ${r.status}.` });
      const port = Number.isInteger(seat.port) && seat.port > 0 && seat.port < 65536 ? seat.port : LINK_PORT;
      const players = Math.max(2, Math.min(4, Number(seat.players) | 0 || 2));
      await native.launch({ ...entry, system: "gbalink" }, file, { host: hostIp, port, players, role: "client" });
      link.setJoined({ lobbyId: l.lobby_id, game: l.game_title, host: l.host_name, hostIp, hostBase, slot: seat.slot, players, port });
      return json(res, 200, { ok: true, slot: seat.slot, players, host: hostIp, port });
    } catch (e) { return json(res, 409, { error: e.message || "Couldn't start the link session." }); }
  }
  if (urlPath === "/api/logout" && req.method === "POST") {
    res.setHeader("Set-Cookie", "hub=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0");
    return json(res, 200, { ok: true });
  }
  // Shut the whole server down. Allowed for (a) stop.py on this same computer, which proves itself with the
  // random token in run/retro-hub.json and must connect over loopback, or (b) a signed-in owner (admin)
  // pressing "Shut down server" (custom header = no cross-site form can trigger it).
  if (urlPath === "/api/shutdown" && req.method === "POST") {
    const s = readSession(req);
    const byToken = isLoopback(req) && typeof req.headers["x-shutdown-token"] === "string"
      && same(req.headers["x-shutdown-token"], SHUTDOWN_TOKEN);
    const byAdmin = s?.role === "admin" && req.headers["x-retro-hub"] === "shutdown";
    if (!byToken && !byAdmin) return json(res, 403, { error: "Not allowed." });
    json(res, 202, { ok: true });
    return shutdown(byAdmin ? `the owner (${s.name}) shut the server down` : "stop script");
  }
  // Native emulators: start / stop a game on this computer. Owner only, from a browser on this same computer
  // (it has to capture the emulator's window anyway), and a custom header so no other site can trigger it.
  if ((urlPath === "/api/native/launch" || urlPath === "/api/native/stop" || urlPath === "/api/native/window") && req.method === "POST") {
    const s = readSession(req);
    if (!localOwner(req, s) || req.headers["x-retro-hub"] !== "native") return json(res, 403, { error: "Native emulators can only be started by the owner, from a browser on the hub's own computer." });
    if (urlPath === "/api/native/stop") return json(res, 200, { ok: true, stopped: native.stopGame() });
    if (urlPath === "/api/native/window") {
      let b; try { b = JSON.parse(await readBody(req)); } catch { return json(res, 400, { error: "Bad request" }); }
      return native.setWindow(!!b.show) ? json(res, 200, { ok: true }) : json(res, 409, { error: "No headless game is running." });
    }
    let body; try { body = JSON.parse(await readBody(req)); } catch { return json(res, 400, { error: "Bad request" }); }
    libCache.at = 0;                    // a game just added with apps.py should be launchable right away
    // system "gbalink": a GBA / GB game from the browser consoles' folders, played in VBA-M instead of EmulatorJS.
    const asLink = body.system === "gbalink";
    const found = scanLibrary().find(g => g.path === String(body.path || "") && (g.native || (asLink && isGbaGame(g))));
    const entry = found && asLink && !found.app ? { ...found, system: "gbalink" } : found;
    const file = entry && (entry.app ? null : romFile(entry.path));
    if (!entry || (!entry.app && !file)) return json(res, 404, { error: "That game isn't in the library (or isn't for a native emulator)." });
    try { return json(res, 200, { ok: true, ...(await native.launch(entry, file, null, { headless: !!body.headless })) }); }
    catch (e) { return json(res, 409, { error: e.message }); }
  }
  // Owner, from a browser on the hub's own computer (it names folders on this PC): set or clear a console's folder.
  if (urlPath === "/api/library/folders" && req.method === "POST") {
    const s = readSession(req);
    if (!localOwner(req, s) || req.headers["x-retro-hub"] !== "library") return json(res, 403, { error: LOCAL_ONLY });
    let body; try { body = JSON.parse(await readBody(req)); } catch { return json(res, 400, { error: "Bad request" }); }
    const sys = String(body.system || "");
    if (!SYSTEMS[sys] || sys === "pc") return json(res, 400, { error: "Unknown console." });
    if (body.dir) {
      const dir = path.resolve(String(body.dir));
      let st; try { st = fs.statSync(dir); } catch {}
      if (!st?.isDirectory()) return json(res, 400, { error: "That folder doesn't exist." });
      libFolders[sys] = dir;
    } else delete libFolders[sys];
    try { saveLibFolders(); } catch (e) { return json(res, 500, { error: `Couldn't save ${path.basename(LIB_FOLDERS_FILE)}: ${e.code || e.message}` }); }
    libCache.at = 0;
    return json(res, 200, { ok: true, dir: libFolders[sys] || null });
  }
  if (urlPath.startsWith("/api/covers") && req.method === "POST") {
    const session = readSession(req);
    if (session?.role !== "admin" || req.headers["x-retro-hub"] !== "covers" || !sameOrigin(req)) return json(res, 403, { error: "Only the owner can change covers." });
    try {
      if (urlPath === "/api/covers") {
        const body = JSON.parse(await readBody(req));
        coverArt.setAuto(body.auto);
        libCache.at = 0; scanLibrary();
        return json(res, 200, coverArt.status());
      }
      const q = new URL(req.url, "http://x").searchParams;
      const le = libEntry(q.get("path"), session);
      if (!le) return json(res, 404, { error: "That game isn't in the library." });
      if (urlPath === "/api/covers/upload") coverArt.saveManual(le.system, le.entry.name, await readRaw(req, 8 * 1024 * 1024));
      else if (urlPath === "/api/covers/remove") coverArt.removeManual(le.system, le.entry.name);
      else return json(res, 404, { error: "Not found" });
      libCache.at = 0;
      const g = scanLibrary().find(x => x.path === le.entry.path);
      return json(res, 200, { ok: true, cover: g?.cover || null });
    } catch (e) { return json(res, 400, { error: e.message === "too big" ? "That image is too big (8 MB max)." : e.message || "Bad request" }); }
  }
  if (req.method !== "GET" && req.method !== "HEAD") { res.writeHead(405); return res.end(); }

  const session = readSession(req);
  if (!session && !PUBLIC_PATHS.has(urlPath)) {
    if (urlPath === "/" || urlPath.endsWith(".html")) {
      res.writeHead(302, { Location: "/login.html?next=" + encodeURIComponent(req.url) }); return res.end();
    }
    return json(res, 401, { error: "Login required" });
  }

  if (urlPath === "/api/me") return json(res, 200, { ...session, library: canLibrary(session), version: APP_VERSION,
    canUnlock: !!ADMIN_PASSWORD && session.role !== "admin" });
  if (urlPath === "/api/config") return json(res, 200, { iceServers: iceServers(), maxPlayers: MAX_PLAYERS, publicUrl: PUBLIC_URL,
    systems: Object.fromEntries(Object.entries(SYSTEMS).map(([k, v]) => [k, v.label])),
    nativeSystems: Object.keys(SYSTEMS).filter(isNativeSys),
    detect: { ext: EXT_TO_SYS, dirs: DIR_TO_SYS } });
  if (urlPath === "/api/native") {
    if (!localOwner(req, session)) return json(res, 200, { available: false,
      reason: "Native emulators (PS2, GameCube, Wii, PS3, Xbox 360, Wii U) can only be hosted by the owner, from a browser on the hub's own computer." });
    return json(res, 200, { available: true, ...(await native.status()) });
  }
  if (urlPath === "/api/pretendo") {
    if (!localOwner(req, session)) return json(res, 200, { available: false });
    const st = await native.pretendoStatus(new URL(req.url, "http://x").searchParams.has("fresh"));
    return json(res, 200, { available: !!st, ...(st || {}) });
  }
  if (urlPath === "/api/link") {
    if (!localOwner(req, session)) return json(res, 200, { available: false });
    const st = await native.status();
    return json(res, 200, { available: true, installed: !!st.systems?.gbalink?.installed, ip: lanIp(), ...link.status() });
  }
  // "Check for Emus": every emulator the hub knows, and each folder in the emulators folder, installed or not.
  if (urlPath === "/api/emulators") {
    const st = await native.status();
    const known = new Set();
    const list = Object.entries(st.emulators).map(([id, e]) => {
      for (const f of NATIVE_FOLDERS[id] || [id]) known.add(String(f).toLowerCase());
      const systems = Object.values(st.systems).filter(s => s.emulator === id).map(s => s.label);
      return { id, label: e.label, installed: !!e.installed, custom: !!e.custom, systems };
    });
    let extra = [];
    try {
      extra = fs.readdirSync(st.folder, { withFileTypes: true })
        .filter(d => d.isDirectory() && !d.name.startsWith(".") && !known.has(d.name.toLowerCase()))
        .map(d => ({ id: d.name, label: d.name, installed: false, unknown: true, systems: [] }));
    } catch {}
    return json(res, 200, { ok: !!st.runner?.ok, error: st.runner?.ok ? null : st.runner?.error || null,
      emulators: [...list, ...extra], ...(session.role === "admin" ? { folder: st.folder } : {}) });
  }
  // Library folders menu: every console and the folder it reads from.
  if (urlPath === "/api/library/folders") {
    if (session.role !== "admin") return json(res, 403, { error: "Unlock the library first." });
    return json(res, 200, { canEdit: localOwner(req, session), romsDir: ROMS_DIR,
      systems: Object.entries(SYSTEMS).filter(([id]) => id !== "pc").map(([id, s]) => ({ id, label: s.label, native: !!s.native,
        dir: libFolders[id] || null, defaultDirs: s.dirs.slice(0, 3) })) });
  }
  // Folder picker for that menu: lists sub-folders only (never files), owner on the hub's own computer.
  if (urlPath === "/api/fs/dirs") {
    if (!localOwner(req, session)) return json(res, 403, { error: LOCAL_ONLY });
    const want = new URL(req.url, "http://x").searchParams.get("dir") || "";
    if (!want) {   // start: drives (Windows) or /, plus handy places
      const roots = process.platform === "win32"
        ? "CDEFGHIJKLMNOPQRSTUVWXYZAB".split("").map(l => l + ":\\").filter(d => { try { fs.accessSync(d); return true; } catch { return false; } })
        : ["/"];
      const home = process.env.USERPROFILE || process.env.HOME || "";
      return json(res, 200, { dir: "", parent: null, dirs: [...roots, ROMS_DIR, ...(home ? [home] : [])].map(p => ({ name: p, path: p })) });
    }
    const dir = path.resolve(want);
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return json(res, 400, { error: `Can't open that folder (${e.code}).` }); }
    const dirs = entries.filter(d => { try { return d.isDirectory() && !d.name.startsWith(".") && !d.name.startsWith("$"); } catch { return false; } })
      .map(d => ({ name: d.name, path: path.join(dir, d.name) })).sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: "base" }));
    const parent = path.dirname(dir);
    return json(res, 200, { dir, parent: parent === dir ? "" : parent, dirs: dirs.slice(0, 2000) });
  }
  // RetroAchievements (read-only Web API through the hub, each player's own key): core/net/retroachievements.mjs
  if (urlPath.startsWith("/api/ra/") && req.method === "GET") {
    return retroAch.handle(req, res, urlPath, session, { json, sendFile, libFile: (p, s) => libEntry(p, s) });
  }
  // Cover art: auto covers on/off, and covers the owner drops onto a game (core/net/covers.mjs).
  if (urlPath === "/api/covers" && req.method === "GET") {
    if (!canLibrary(session)) return json(res, 403, { error: "Library is owner-only" });
    return json(res, 200, coverArt.status());
  }
  if (urlPath === "/api/library") {
    if (!canLibrary(session)) return json(res, 403, { error: "Library is owner-only" });
    return json(res, 200, scanLibrary());
  }
  if (urlPath.startsWith("/roms/")) {
    if (!canLibrary(session)) { res.writeHead(403); return res.end(); }
    // The client prefixes the file name with "<account>__" so EmulatorJS keeps a separate in-game save per account
    const f = romFile(urlPath.slice(6).replace(/(^|\/)[0-9A-F]{8}__(?=[^/]+$)/, "$1"));
    if (!f || !ROM_EXTS.has(path.extname(f).slice(1).toLowerCase())) { res.writeHead(404); return res.end(); }
    return sendFile(req, res, f, "private, no-store");
  }
  if (urlPath.startsWith("/covers/")) {      // library cover art: same access rule as the ROMs
    if (!canLibrary(session)) { res.writeHead(403); return res.end(); }
    const rel = urlPath.slice(8);
    const f = rel.startsWith("~cache/") ? coverArt.file(rel.slice(7)) : romFile(rel);
    if (!f || !COVER_EXTS.has(path.extname(f).slice(1).toLowerCase())) { res.writeHead(404); return res.end(); }
    return sendFile(req, res, f, rel.startsWith("~cache/") ? "private, no-cache" : "private, max-age=3600");
  }
  if (urlPath.startsWith("/data/cores/")) {
    const rel = urlPath.slice("/data/cores/".length);
    if (!CORE_FILE_RE.test(rel)) { res.writeHead(404); return res.end(); }
    return serveCore(req, res, rel);
  }
  const f = safeJoin(PUBLIC_DIR, urlPath.endsWith("/") ? urlPath + "index.html" : urlPath);
  if (!f) { res.writeHead(403); return res.end(); }
  sendFile(req, res, f, f.startsWith(path.join(PUBLIC_DIR, "data")) ? "public, max-age=86400" : "no-cache");
});

// ---------------------------------------------------------------- rooms + signaling (/ws)
// Room phases: lobby -> countdown (3 s, server-timed) -> loading (per-player progress) -> playing.
const rooms = new Map();      // code -> { code, host, owner, pw, reserved:Set, clients:Map, game, system, phase, rules, cd }
const lobbyWatchers = new Set();
let nextId = 1;
const MAX_CLIENTS = 12;       // players + spectators
const COUNTDOWN_MS = 3000;
const WS_RATE_MAX = 200;      // messages per second per socket before it is closed as a flood
const RESUME_MS = 30000;
const CHAT_KEEP = 60;         // messages kept per room for late joiners
const CHAT_MAX = 300;         // characters per message
const CHAT_BURST = 6, CHAT_WINDOW = 8000;   // at most 6 messages per 8 s per player     // a dropped socket keeps its seat, id, ready flag and ROM this long (resume token)
const wss = new WebSocketServer({ noServer: true, maxPayload: 64 * 1024 });
server.on("upgrade", (req, socket, head) => {
  const session = readSession(req);
  const wsPath = new URL(req.url, "http://x").pathname;
  if (wsPath === "/native-input") {
    // Guest controller state -> virtual gamepads. Same-origin page of the owner on this computer only.
    if (!localOwner(req, session) || !sameOrigin(req)) { socket.write("HTTP/1.1 403 Forbidden\r\n\r\n"); return socket.destroy(); }
    return native.handleUpgrade(req, socket, head);
  }
  if (wsPath !== "/ws" || !session) {
    socket.write("HTTP/1.1 401 Unauthorized\r\n\r\n"); return socket.destroy();
  }
  wss.handleUpgrade(req, socket, head, ws => wss.emit("connection", ws, session, clientIp(req)));
});

const send = (c, msg) => { if (c.ws.readyState === 1) c.ws.send(JSON.stringify(msg)); };
const roster = room => [...room.clients.values()].map(c => ({ id: c.id, slot: c.slot, name: c.name, key: c.key, host: c === room.host,
  ready: c.ready, progress: c.progress, rtt: c.ws.rtt ?? null, spectator: c.slot < 0, voice: c.voice, rom: c.rom, ghost: c.ghost,
  away: !!c.away, ...(room.rules.race && c.run ? { run: c.run } : {}) }));
// Removes a client for good (left on purpose, or its resume window ran out).
function finalizeLeave(room, c, quiet) {
  clearTimeout(c.awayT); c.awayT = null; c.away = false;
  if (room.clients.get(c.id) !== c) return;
  room.clients.delete(c.id);
  const wasHost = room.host === c;
  if (wasHost) { room.host = null; room.reserved = new Set(); }
  if (!room.clients.size) { clearTimeout(room.cd); rooms.delete(room.code); return pushRoomList(); }
  if (!quiet) chatSys(room, `${c.name} left.`);
  if (wasHost && promoteHost(room, `${c.name} left.`)) return;
  cancelCountdown(room, `${c.name} left.`);
  checkLoaded(room);
  sendRoster(room);
}
// Host migration: the old host is gone for good, so the connected player in the lowest seat (else a spectator)
// takes over. The game itself only ever lived in the old host's browser, so a running match ends and the room
// goes back to the lobby; the new host picks the game (co-op) or reference ROM (ghost) and starts again.
function promoteHost(room, why) {
  const live = [...room.clients.values()].filter(c => !c.away && !c.left);
  const next = live.filter(c => c.slot >= 0).sort((a, b) => a.slot - b.slot)[0] || live[0];
  if (!next) return false;          // everyone is away: the room waits (the owner can still come back as host)
  const wasRunning = room.phase !== "lobby";
  clearTimeout(room.cd); room.cd = null; room.staged = false;
  if (room.phase === "countdown") broadcast(room, { t: "countdown", cancelled: true, reason: why });
  if (next.slot < 0) next.slot = freeSlot(room, next);
  next.wasSeated = true;
  room.host = next; room.owner = next.key;
  room.reserved = new Set([next.slot]);
  setPhase(room, "lobby");          // also clears everyone's ready state
  send(next, { t: "promoted", wasRunning });
  chatSys(room, `${next.name} is the host now.`);
  broadcast(room, { t: "notice", msg: `${why} ${next.name} is the host now.${wasRunning ? " The match ended; it can be started again from the lobby." : ""}` });
  sendRoster(room);
  return true;
}
const joinedMsg = (room, c, extra) => ({ t: "joined", id: c.id, slot: c.slot, room: room.code, host: room.host === c, phase: room.phase,
  token: c.token, game: room.game, system: room.system, mode: room.rules.mode, ...extra });
const tokenMatch = (a, b) => typeof a === "string" && a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
// Single-player ghost mode: every player runs their own ROM; only checksums (never ROM data) reach the server.
const isGhost = room => room.rules.mode === "ghost";
// ---- Race / speedrun (ghost mode + a shared timer). Splits are stamped by the hub, not the players' clocks:
// time = arrival - GO - half the player's round trip, so nobody's clock (or a slow tab) changes their time.
const MAX_SPLITS = 40;
function cleanSplits(list) {
  if (!Array.isArray(list)) return null;
  return list.map(x => cleanText(x, 40)).filter(Boolean).slice(0, MAX_SPLITS);
}
const raceRunners = room => [...room.clients.values()].filter(c => c.slot >= 0);
const splitCount = room => Math.max(1, room.rules.splits?.length || 0);
const fmtRace = ms => { const t = Math.max(0, Math.round(ms)), h = Math.floor(t / 3600e3), m = Math.floor(t / 60e3) % 60, sec = Math.floor(t / 1e3) % 60;
  return `${h ? h + ":" + String(m).padStart(2, "0") : m}:${String(sec).padStart(2, "0")}.${String(t % 1000).padStart(3, "0")}`; };
function startRace(room) {
  room.goAt = Date.now(); room.raceOver = false;
  for (const c of room.clients.values()) c.run = c.slot >= 0 ? { splits: [], done: null, quit: false } : null;
}
function raceCheckOver(room) {
  const runners = raceRunners(room).filter(c => c.run);
  if (room.raceOver || !runners.length || !runners.every(c => c.run.done != null || c.run.quit)) return;
  room.raceOver = true;
  const order = runners.filter(c => c.run.done != null).sort((a, b) => a.run.done - b.run.done);
  if (runners.length > 1) chatSys(room, `Race over: ${order.map((c, i) => `${i + 1}. ${c.name} ${fmtRace(c.run.done)}`).join(" · ") || "nobody finished"}.`);
}
function raceAct(room, c, act) {
  if (!room.rules.race || room.phase !== "playing" || !room.goAt || !c.run || c.slot < 0) return false;
  const run = c.run, now = Date.now();
  if (act === "split") {
    if (run.done != null || run.quit || now - (c.splitAt || 0) < 300) return false;     // 300 ms: no double-presses
    c.splitAt = now;
    const t = Math.max(0, Math.round(now - room.goAt - Math.min(500, (c.ws.rtt || 0) / 2)));
    run.splits.push(t);
    if (run.splits.length >= splitCount(room)) {
      run.done = t;
      const place = raceRunners(room).filter(x => x.run?.done != null && x.run.done <= t).length;
      chatSys(room, raceRunners(room).length > 1 ? `${c.name} finished ${place}${["th", "st", "nd", "rd"][place % 100 > 10 && place % 100 < 14 ? 0 : place % 10] || "th"} in ${fmtRace(t)}.`
        : `${c.name} finished in ${fmtRace(t)}.`);
      raceCheckOver(room);
    }
    return true;
  }
  if (act === "undo") {
    if (!run.splits.length || run.quit) return false;
    run.splits.pop(); run.done = null; room.raceOver = false;
    return true;
  }
  if (act === "forfeit") {
    if (run.done != null || run.quit) return false;
    run.quit = true;
    if (raceRunners(room).length > 1) chatSys(room, `${c.name} forfeited.`);
    raceCheckOver(room);
    return true;
  }
  if (act === "restart") {          // solo speedrun: reset the clock without leaving (the player resets their game)
    if (raceRunners(room).length !== 1) return false;
    startRace(room);
    return true;
  }
  return false;
}
function cleanRom(r) {
  if (!r || typeof r !== "object") return null;
  const crc = String(r.crc || "").toUpperCase();
  const size = Number(r.size);
  if (!/^[0-9A-F]{8}$/.test(crc) || !Number.isSafeInteger(size) || size <= 0) return null;
  return { crc, size, name: cleanText(r.name, 80) };
}
// Lobby passwords live in memory only, as salted scrypt hashes, for as long as the lobby exists.
function hashLobbyPw(pw) {
  const salt = crypto.randomBytes(16);
  return { salt, hash: crypto.scryptSync(pw, salt, 32) };
}
const checkLobbyPw = (room, pw) => !room.pw || crypto.timingSafeEqual(crypto.scryptSync(String(pw || ""), room.pw.salt, 32), room.pw.hash);
const broadcast = (room, msg) => room.clients.forEach(c => send(c, msg));
// Room chat (text only, kept in memory for as long as the room exists). sys = a hub line, not a player's message.
function chat(room, entry) {
  room.chat = room.chat || []; room.chatSeq = (room.chatSeq || 0) + 1;
  const msg = { n: room.chatSeq, at: Date.now(), ...entry };
  room.chat.push(msg); if (room.chat.length > CHAT_KEEP) room.chat.shift();
  broadcast(room, { t: "chat", msg });
}
const chatSys = (room, text) => chat(room, { sys: true, text });
function chatAllowed(c) {
  const now = Date.now();
  c.chatTimes = (c.chatTimes || []).filter(t => now - t < CHAT_WINDOW);
  if (c.chatTimes.length >= CHAT_BURST) return false;
  c.chatTimes.push(now); return true;
}
const cleanCode = s => String(s || "").toUpperCase().replace(/[^A-Z0-9-]/g, "").slice(0, 24);
const cleanText = (s, n) => String(s || "").replace(CTRL_RE, "").trim().slice(0, n);

function freeSlot(room, except) {
  const used = new Set([...room.clients.values()].filter(c => c !== except).map(c => c.slot));
  for (let s = 0; s < MAX_PLAYERS; s++) if (!used.has(s) && !room.reserved.has(s)) return s;
  return -1;
}
const slotTaken = (room, s) => room.reserved.has(s) || [...room.clients.values()].some(c => c.slot === s);
function roomList() {
  return [...rooms.values()].filter(r => r.host).map(r => {
    const guests = [...r.clients.values()].filter(c => c !== r.host);
    const seated = guests.filter(c => c.slot >= 0).length;
    return { code: r.code, game: r.game, system: r.system, host: r.host.name, hostKey: r.owner, locked: !!r.pw,
      players: r.reserved.size + seated, open: Math.max(0, MAX_PLAYERS - r.reserved.size - seated), max: MAX_PLAYERS,
      spectators: guests.length - seated, watchable: r.rules.spectators && r.clients.size < MAX_CLIENTS,
      phase: r.phase, hostRtt: r.host.ws.rtt ?? null, mode: r.rules.mode, race: !!r.rules.race };
  });
}
let listTimer = null;
function pushRoomList() {
  if (listTimer) return;
  listTimer = setTimeout(() => {
    listTimer = null;
    const msg = JSON.stringify({ t: "rooms", rooms: roomList() });
    for (const ws of lobbyWatchers) if (ws.readyState === 1) ws.send(msg);
    discovery.lobbiesChanged();
  }, 100);
}
// This hub's lobbies in the shared discovery schema (core/net/discovery.mjs), for LAN beacons and the master pool.
function discoveryLobbies() {
  // A link session ends when this PC's VBA-M is closed.
  if ((link.hosting || link.joined) && !native.isRunning()) {
    if (link.joined) releaseSeat(link.joined);
    link.stop("ended (VBA-M closed)");
  }
  const own = link.lobby();
  return [...(own ? [own] : []), ...roomList().map(r => ({ lobby_id: r.code, host_name: r.host, emulator_core: isNativeSys(r.system) ? `native:${r.system}` : "emulatorjs",
    game_title: r.game || "", current_players: r.players, max_players: r.max, system: r.system, locked: r.locked, phase: r.phase, mode: r.mode,
    netplay_mode: r.system === "wiiu" && native.pretendoCached()?.ready ? "pretendo" : "netplay" }))];
}
const masterPool = process.env.MASTER_SERVER === "1" ? createMasterPool() : null;
const loopbackOnly = /^(127\.|::1$|localhost$)/i.test(HOST);
const discovery = createDiscovery({ lobbies: discoveryLobbies, port: PORT, advertise: !loopbackOnly, publicUrl: PUBLIC_URL,
  masterUrl: process.env.MASTER_SERVER_URL || "", version: APP_VERSION, onChange: pushLanList });
discovery.setWatching(() => lobbyWatchers.size > 0);
// GBA link-cable sessions between hubs on this network (core/net/link.mjs).
let linkHostName = "Host";
const link = createLink({ hubId: discovery.hubId, hostName: () => linkHostName });
setInterval(() => { if (link.hosting || link.joined) discoveryLobbies(); }, 3000).unref();   // notice VBA-M closing
const lanIp = () => Object.values(os.networkInterfaces()).flat().find(a => a && (a.family === "IPv4" || a.family === 4) && !a.internal)?.address || "127.0.0.1";
// A request straight from another computer on this network: no proxy / tunnel in between.
function directLan(req) {
  const h = req.headers;
  return PRIVATE_IP.test(String(req.socket.remoteAddress || "")) && !h["cf-connecting-ip"] && !h["x-forwarded-for"] && !h["x-real-ip"] && !h["forwarded"];
}
const linkHits = new Map();    // ip -> { n, at }: hub-to-hub link requests, 30 a minute per address
function linkThrottled(ip) {
  const now = Date.now(), e = linkHits.get(ip);
  if (!e || now - e.at > 60e3) { linkHits.set(ip, { n: 1, at: now }); if (linkHits.size > 500) linkHits.clear(); return false; }
  return ++e.n > 30;
}
function releaseSeat(j) {
  fetch(`${j.hostBase}/api/link/release`, { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ lobby_id: j.lobbyId, hub: discovery.hubId }), signal: AbortSignal.timeout(4000) }).catch(() => {});
}
// Games VBA-M can link: GBA plus Game Boy / Color, from the browser consoles' folders or VBA-M's own (gbalink).
const LINK_EXTS = new Set(["gba", "gb", "gbc"]);
const isGbaGame = g => (g.system === "gba" || g.system === "gb" || g.system === "gbalink") && LINK_EXTS.has(g.ext) && !g.app;
// Other hubs' lobbies. LAN ones (private 192.168.x addresses) only go to browsers on the same private network:
// a friend coming in over the internet / tunnel can't reach them, and shouldn't learn the owner's LAN layout.
const PRIVATE_IP = /^(::ffff:)?(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|127\.|169\.254\.)|^::1$|^f[cd][0-9a-f]{2}:/i;
function lanMsgFor(ws) {
  const all = discovery.list();
  return JSON.stringify({ t: "lan", lobbies: ws.privateNet ? all : all.filter(l => !l.is_lan) });
}
function pushLanList() {
  for (const ws of lobbyWatchers) if (ws.readyState === 1) ws.send(lanMsgFor(ws));
}
function sendRoster(room) {
  broadcast(room, { t: "roster", players: roster(room), hostId: room.host?.id ?? null, game: room.game, system: room.system,
    phase: room.phase, rules: room.rules, reserved: [...room.reserved], staged: !!room.staged,
    ...(room.rules.race && room.goAt ? { race: { elapsed: Date.now() - room.goAt, over: !!room.raceOver } } : {}) });
  pushRoomList();
}
function setPhase(room, phase) {
  room.phase = phase;
  // Race: the hub's clock is the race clock. It starts on GO, the same moment every player's game unpauses.
  if (phase === "playing" && room.rules.race) startRace(room);
  if (phase === "lobby") { room.goAt = null; room.raceOver = false; for (const c of room.clients.values()) c.run = null; }
  if (phase === "loading") for (const c of room.clients.values()) { c.ready = "loading"; c.progress = 0; }
  if (phase === "lobby") for (const c of room.clients.values()) { c.ready = "notready"; c.progress = 0; }
  broadcast(room, { t: "phase", phase });
}
// Co-op: lobby -> countdown -> loading -> playing (the host's stream starts once everyone is connected).
// Ghost: lobby -> loading -> countdown -> playing, so every player's own emulator is booted (paused) before
// the 3-2-1 and all runs start together on GO. A cancelled ghost countdown returns to the loaded state.
function cancelCountdown(room, reason) {
  if (room.phase !== "countdown") return false;
  clearTimeout(room.cd); room.cd = null;
  room.phase = room.staged ? "loading" : "lobby";
  broadcast(room, { t: "countdown", cancelled: true, reason });
  return true;
}
function runCountdown(room, after) {
  room.phase = "countdown";
  broadcast(room, { t: "countdown", ms: COUNTDOWN_MS });
  room.cd = setTimeout(() => { room.cd = null; if (room.phase === "countdown") { after(); sendRoster(room); } }, COUNTDOWN_MS);
}
const needsReady = room => [...room.clients.values()].filter(c => c.slot >= 0 && c !== room.host);   // the host readies by pressing Start
function checkLoaded(room) {
  if (room.phase !== "loading" || !room.host) return;
  if (![...room.clients.values()].every(c => c.progress >= 100)) return;
  if (!isGhost(room)) {
    for (const c of room.clients.values()) c.ready = "ready";
    return setPhase(room, "playing");
  }
  // Ghost: the first time everyone is loaded the countdown starts by itself; after an abort the host restarts it.
  if (room.staged) return;
  room.staged = true;
  runCountdown(room, () => setPhase(room, "playing"));
}

wss.on("connection", (ws, session, ip) => {
  ws.privateNet = PRIVATE_IP.test(String(ip || ""));
  let me = { id: nextId++, ws, room: null, slot: -1, name: session.name, key: session.id, ready: "notready", progress: 0, voice: false,
    rom: null, ghost: false, token: crypto.randomBytes(18).toString("base64url"), away: false, awayT: null };
  ws.isAlive = true; ws.missed = 0;
  ws.on("pong", () => { ws.isAlive = true; ws.missed = 0; if (ws.pingAt) ws.rtt = Date.now() - ws.pingAt; });
  ws.on("message", raw => {
    // Flood guard: a normal client sends a few messages a second (bursts of ICE candidates are well under this).
    const now = Date.now();
    if (now - (ws.win || 0) >= 1000) { ws.win = now; ws.n = 0; }
    if (++ws.n > WS_RATE_MAX) { me.left = true; return ws.close(1008, "Too many messages"); }
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (!m || typeof m !== "object" || typeof m.t !== "string") return;
    if (m.t === "ping") return send(me, { t: "pong", ts: m.ts });
    if (m.t === "lobby") {
      lobbyWatchers.add(ws);
      send(me, { t: "rooms", rooms: roomList() });
      discovery.nowWatching();
      return ws.send(lanMsgFor(ws));
    }
    if (m.t === "join" && !me.room) {
      const code = cleanCode(m.room);
      if (!code) return send(me, { t: "error", msg: "Missing room code." });
      let room = rooms.get(code);
      if (room) {
        // Resume: same account + the secret token from "joined" gets back the exact same player (id, seat, ready, ROM).
        const mineAway = [...room.clients.values()].filter(c => c.away && c.key === me.key);
        let held = mineAway.find(c => tokenMatch(m.resume, c.token))
          // Planned reload (host migration): the seat was marked just before the page reloaded; same account only.
          || (m.handoff ? mineAway.find(c => c.handoff && Date.now() - c.handoff < RESUME_MS) : null);
        if (held) {
          clearTimeout(held.awayT); held.awayT = null; held.away = false; held.handoff = 0;
          held.ws = ws; lobbyWatchers.delete(ws);
          me = held;
          send(me, joinedMsg(room, me, { resumed: true }));
          send(me, { t: "chat-history", list: room.chat || [] });
          if (!room.host && promoteHost(room, "The host didn't come back.")) return;
          return sendRoster(room);
        }
        // Same account came back without the token (page reload): the old seat is released so the new join can take it.
        held = mineAway.find(c => (c === room.host) === (m.role === "host"));
        if (held) { finalizeLeave(room, held, true); room = rooms.get(code); me.reloaded = true; }
      }
      if (m.role === "host") {
        if (room && room.owner !== me.key) {
          return send(me, room.host
            ? { t: "error", code: "host-moved", msg: `${room.host.name} is hosting this lobby now. You can join it from the hosts list.` }
            : { t: "error", code: "host-taken", msg: "This lobby belongs to someone else." });
        }
        if (room?.host) return send(me, { t: "error", code: "host-taken", msg: "You are already hosting this lobby in another tab." });
        if (!room) {
          const pw = String(m.password || "").slice(0, 64);
          rooms.set(code, room = { code, host: null, owner: me.key, pw: pw ? hashLobbyPw(pw) : null,
            reserved: new Set(), clients: new Map(), game: "", system: "", phase: "lobby", cd: null, staged: false,
            rules: { spectators: true, mode: m.mode === "ghost" && !isNativeSys(m.system) ? "ghost" : "coop", race: false, splits: [] } });
          room.rules.race = room.rules.mode === "ghost" && !!m.race;
          room.rules.splits = cleanSplits(m.splits) || [];
          room.game = cleanText(m.game, 80);
          room.system = SYSTEMS[m.system] ? m.system : "";
        }
        const local = Array.isArray(m.local) ? m.local.filter(n => Number.isInteger(n) && n >= 0 && n < MAX_PLAYERS) : [];
        room.reserved = new Set(local.length && !isGhost(room) ? local : [0]);
        me.rom = cleanRom(m.rom);
        for (const c of room.clients.values()) if (room.reserved.has(c.slot)) c.slot = -1;
        for (const c of room.clients.values()) if (c.slot < 0 && c.wasSeated) c.slot = freeSlot(room);
        me.slot = Math.min(...room.reserved);
        if (room.phase === "loading" || room.phase === "playing") { me.ready = "ready"; me.progress = Number(m.progress) || 0; }
        room.host = me;
      } else {
        if (!room) return send(me, { t: "error", code: "no-room", msg: "No lobby with this code is open right now." });
        const rlKey = "lobby:" + ip;
        if (rateLimited(rlKey)) return send(me, { t: "error", code: "limited", msg: "Too many wrong passwords. Try again in 15 minutes." });
        if (!checkLobbyPw(room, m.password)) {
          if (m.password) noteFailure(rlKey);
          return send(me, { t: "error", code: "password", msg: m.password ? "Wrong lobby password." : "This lobby needs a password." });
        }
        if (room.clients.size >= MAX_CLIENTS) return send(me, { t: "error", code: "full", msg: "Lobby is full." });
        const watch = !!m.spectate;
        me.slot = watch ? -1 : (Number.isInteger(m.slot) && m.slot >= 0 && m.slot < MAX_PLAYERS && !slotTaken(room, m.slot) ? m.slot : freeSlot(room));
        if (!watch && me.slot < 0) {
          return send(me, { t: "error", code: "full", msg: room.rules.spectators ? "All player slots are taken. You can still watch." : "Lobby is full.",
            watchable: room.rules.spectators });
        }
        if (watch && !room.rules.spectators) return send(me, { t: "error", code: "no-spectators", msg: "This lobby doesn't allow spectators." });
        me.wasSeated = me.slot >= 0;
        me.rom = cleanRom(m.rom);
        if (room.phase === "loading" || room.phase === "playing") me.ready = "loading";
      }
      me.room = room; room.clients.set(me.id, me);
      send(me, joinedMsg(room, me));
      send(me, { t: "chat-history", list: room.chat || [] });
      if (!me.reloaded && (room.host !== me || room.clients.size > 1)) chatSys(room, `${me.name} joined${me.slot < 0 ? " to watch" : ""}.`);
      if (!room.host && promoteHost(room, "The host didn't come back.")) return;
      return sendRoster(room);
    }
    const room = me.room; if (!room) return;
    const isHost = room.host === me;
    switch (m.t) {
      case "signal": {
        const target = room.clients.get(m.to);
        if (!target || (!isHost && target !== room.host)) return;
        return send(target, { t: "signal", from: me.id, data: m.data });
      }
      case "ready": {
        const staged = room.staged && (room.phase === "loading" || room.phase === "countdown");
        if (room.phase !== "lobby" && room.phase !== "countdown" && !staged) return;
        const want = m.state === "ready" ? "ready" : "notready";
        if (want === "ready" && isGhost(room) && me.slot >= 0 && !me.rom) {
          return send(me, { t: "notice", msg: "Load your own copy of the game (ROM) before you ready up." });
        }
        if (want === "ready" && staged && me.progress < 100) return;
        me.ready = want;
        if (me.ready === "notready") cancelCountdown(room, `${me.name} is no longer ready.`);
        return sendRoster(room);
      }
      case "rom": {     // ghost mode: checksum of the player's own ROM file (the file itself never leaves their browser)
        if (room.phase !== "lobby" && room.phase !== "countdown" && room.phase !== "loading") return;
        const rom = cleanRom(m.rom);
        if (JSON.stringify(rom) === JSON.stringify(me.rom)) return;
        me.rom = rom;
        if (room.phase !== "loading") {
          if (isHost) {     // the reference ROM changed: everyone re-checks and readies again
            cancelCountdown(room, "The host loaded a different ROM.");
            for (const c of room.clients.values()) c.ready = "notready";
          } else if (me.ready === "ready") { me.ready = "notready"; cancelCountdown(room, `${me.name} changed their ROM.`); }
        }
        return sendRoster(room);
      }
      case "ghost": { me.ghost = !!m.on; return sendRoster(room); }
      case "rules": {
        if (!isHost || room.staged || (room.phase !== "lobby" && room.phase !== "countdown")) return;
        const before = JSON.stringify([room.game, room.system, room.rules]);
        if (typeof m.game === "string") room.game = cleanText(m.game, 80);
        if (typeof m.system === "string" && SYSTEMS[m.system]) room.system = m.system;
        if (typeof m.spectators === "boolean") room.rules.spectators = m.spectators;
        if (m.mode === "ghost" || m.mode === "coop") {
          room.rules.mode = m.mode;
          if (m.mode === "ghost") room.reserved = new Set([room.host.slot]);   // one player per computer in ghost mode
        }
        if (typeof m.race === "boolean") room.rules.race = m.race;
        const splits = cleanSplits(m.splits); if (splits) room.rules.splits = splits;
        if (isNativeSys(room.system)) room.rules.mode = "coop";    // native games run once, on the host's computer
        if (room.rules.mode !== "ghost") room.rules.race = false;  // a race is everyone on their own copy
        if (JSON.stringify([room.game, room.system, room.rules]) === before) return;
        cancelCountdown(room, "The host changed the rules.");
        for (const c of room.clients.values()) c.ready = "notready";
        broadcast(room, { t: "notice", msg: "The host changed the game or rules. Everyone needs to ready up again." });
        return sendRoster(room);
      }
      case "start": {
        if (!isHost) return;
        const waiting = needsReady(room).filter(c => c.ready !== "ready");
        if (room.phase === "loading" && room.staged) {     // ghost: restart the countdown after an abort
          if (![...room.clients.values()].every(c => c.progress >= 100)) return send(me, { t: "notice", msg: "Someone is still loading." });
          if (waiting.length) return send(me, { t: "notice", msg: `Waiting for ${waiting.map(c => c.name).join(", ")} to ready up.` });
          runCountdown(room, () => setPhase(room, "playing"));
          return sendRoster(room);
        }
        if (room.phase !== "lobby") return;
        if (waiting.length) return send(me, { t: "notice", msg: `Waiting for ${waiting.map(c => c.name).join(", ")} to ready up.` });
        if (isGhost(room)) {
          if (!me.rom) return send(me, { t: "notice", msg: "Load your ROM first." });
          room.staged = false;
          setPhase(room, "loading");
          return sendRoster(room);
        }
        runCountdown(room, () => setPhase(room, "loading"));
        return sendRoster(room);
      }
      case "abort": {
        if (isHost && cancelCountdown(room, "The host stopped the countdown.")) sendRoster(room);
        return;
      }
      case "progress": {
        if (room.phase !== "loading" && room.phase !== "playing") return;
        const pct = Math.max(0, Math.min(100, Math.round(Number(m.pct) || 0)));
        if (pct === me.progress) return;
        me.progress = pct;
        if (pct >= 100 && (room.phase === "playing" || (isGhost(room) && me.ready === "loading"))) me.ready = "ready";
        checkLoaded(room);
        return sendRoster(room);
      }
      case "slot": {     // move yourself to an empty seat (also leaves spectating)
        const s = Number(m.slot);
        if (!Number.isInteger(s) || s < 0 || s >= MAX_PLAYERS || isHost || room.phase === "countdown" || slotTaken(room, s)) return;
        if (isGhost(room) && room.phase !== "lobby" && me.slot < 0) return;   // a ghost run can't be joined from the stands
        me.slot = s; me.wasSeated = true; me.ready = room.phase === "lobby" ? "notready" : me.ready;
        return sendRoster(room);
      }
      case "swap": {     // host swaps two guest seats (either may be empty)
        if (!isHost || room.phase === "countdown" || (isGhost(room) && room.phase !== "lobby")) return;
        const a = Number(m.a), b = Number(m.b);
        if (![a, b].every(s => Number.isInteger(s) && s >= 0 && s < MAX_PLAYERS && !room.reserved.has(s)) || a === b) return;
        const ca = [...room.clients.values()].find(c => c.slot === a), cb = [...room.clients.values()].find(c => c.slot === b);
        if (ca) ca.slot = b; if (cb) cb.slot = a;
        return sendRoster(room);
      }
      case "spectate": {
        if (isHost || room.phase === "countdown") return;
        if (isGhost(room) && room.phase !== "lobby") return send(me, { t: "notice", msg: "Seats are locked while a ghost run is in progress." });
        if (m.on) {
          if (!room.rules.spectators) return send(me, { t: "notice", msg: "This lobby doesn't allow spectators." });
          me.slot = -1; me.wasSeated = false;
        } else if (me.slot < 0) {
          const s = freeSlot(room, me);
          if (s < 0) return send(me, { t: "notice", msg: "No free player slot." });
          me.slot = s; me.wasSeated = true; if (room.phase === "lobby") me.ready = "notready";
        }
        return sendRoster(room);
      }
      case "voice": { me.voice = !!m.on; return sendRoster(room); }
      case "race": { if (raceAct(room, me, String(m.act || ""))) sendRoster(room); return; }
      case "chat": {
        // Clients render chat as plain text, so only control characters are removed ("<3" survives).
        const text = String(m.text ?? "").replace(/[\x00-\x1f\x7f]/g, " ").trim().slice(0, CHAT_MAX);
        if (!text) return;
        if (!chatAllowed(me)) return send(me, { t: "notice", msg: "Slow down a little: too many chat messages." });
        return chat(room, { from: me.id, name: me.name, key: me.key, slot: me.slot, text });
      }
      case "savestate": {     // co-op host saved or loaded a save state (the state itself travels peer to peer)
        if (!isHost || isGhost(room) || room.phase !== "playing" || !chatAllowed(me)) return;
        const label = cleanText(m.label, 60);
        if (m.act === "save") return chatSys(room, `${me.name} saved the game${label ? ` (${label})` : ""}.`);
        if (m.act === "load") return chatSys(room, `${me.name} loaded a save${label ? `: ${label}` : ""}.`);
        return;
      }
      case "leave": { me.left = true; return; }               // sent right before an intentional close: no resume window
      case "handoff": { me.handoff = Date.now(); return; }   // about to reload into a new role: keep the seat
    }
  });
  ws.on("close", () => {
    lobbyWatchers.delete(ws);
    const room = me.room; if (!room || me.ws !== ws) return;     // a resumed client's old socket closing changes nothing
    if (me.left) return finalizeLeave(room, me);
    // Wi-Fi blip etc.: keep the seat for RESUME_MS. WebRTC links usually survive a hub drop, and the same id keeps them.
    me.away = true;
    const c = me;
    c.awayT = setTimeout(() => finalizeLeave(room, c), RESUME_MS);
    cancelCountdown(room, `${me.name} lost connection.`);
    sendRoster(room);
  });
});
// Heartbeat every 5 s: measures each socket's round-trip time; drops sockets that miss 3 in a row.
setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive && ++ws.missed >= 3) { ws.terminate(); continue; }
    ws.isAlive = false; ws.pingAt = Date.now(); ws.ping();
  }
}, 5000).unref();
// Latency changes: refresh the hosts list and rosters every 5 s.
setInterval(() => { if (rooms.size) { pushRoomList(); for (const r of rooms.values()) if (r.clients.size > 1) sendRoster(r); } }, 5000).unref();

// ---------------------------------------------------------------- shutdown
// Every way of stopping ends here: Ctrl+C, closing the window, `docker stop` (SIGTERM; without a handler Node
// running as PID 1 in a container ignores it and Docker has to kill it after 10 s), stop.py / stop.sh / the Retro Hub window,
// or the owner's "Shut down server" button. Players are told, sockets close, the run file is removed, and the
// process exits; if anything hangs, it is forced out after 3 s.
let stopping = false;
function shutdown(reason) {
  if (stopping) return;
  stopping = true;
  console.log(`Shutting down (${reason})…`);
  const bye = JSON.stringify({ t: "shutdown", msg: "The Retro Hub server was shut down." });
  for (const ws of wss.clients) { try { ws.send(bye); ws.close(1001, "Server shutting down"); } catch {} }
  for (const room of rooms.values()) clearTimeout(room.cd);
  try { native.shutdown(); } catch {}
  try { discovery.stop(); masterPool?.stop(); } catch {}
  removeRunFile();
  server.close(() => process.exit(0));
  setTimeout(() => { for (const ws of wss.clients) ws.terminate(); process.exit(0); }, 3000).unref();
}
for (const sig of ["SIGINT", "SIGTERM", "SIGHUP", "SIGBREAK"]) { try { process.on(sig, () => shutdown(sig)); } catch {} }
process.on("exit", removeRunFile);

// run/retro-hub.json tells stop.py which process and port this is, plus a random token that only someone who
// can read this folder knows. Readable by this user only; deleted on exit. Never sent to browsers.
const RUN_FILE = path.join(ROOT, "run", "retro-hub.json");
const SHUTDOWN_TOKEN = crypto.randomBytes(24).toString("base64url");
function writeRunFile() {
  try {
    fs.mkdirSync(path.dirname(RUN_FILE), { recursive: true });
    fs.writeFileSync(RUN_FILE, JSON.stringify({ pid: process.pid, port: PORT, token: SHUTDOWN_TOKEN, started: new Date().toISOString() }), { mode: 0o600 });
  } catch (e) { console.warn(`Could not write ${RUN_FILE} (${e.code}); stop.py will fall back to finding the process by port.`); }
}
function removeRunFile() {
  try { if (JSON.parse(fs.readFileSync(RUN_FILE, "utf8")).pid === process.pid) fs.unlinkSync(RUN_FILE); } catch {}
}
function isLoopback(req) {
  const a = req.socket.remoteAddress || "";
  return a === "127.0.0.1" || a === "::1" || a === "::ffff:127.0.0.1";
}
// A browser on this very computer: loopback AND not relayed by a local proxy (a Cloudflare tunnel or reverse
// proxy also connects from loopback, but adds forwarding headers for the real visitor).
function localOwner(req, s) {
  if (s?.role !== "admin" || !isLoopback(req)) return false;
  const h = req.headers;
  return !h["cf-connecting-ip"] && !h["x-forwarded-for"] && !h["x-real-ip"] && !h["forwarded"];
}
function sameOrigin(req) {
  const o = String(req.headers.origin || "");
  try { const u = new URL(o); return u.host === req.headers.host && (u.protocol === "http:" || u.protocol === "https:"); } catch { return false; }
}

server.listen(PORT, HOST, () => {
  writeRunFile();
  console.log(`Retro Hub v${APP_VERSION} on http://localhost:${PORT}  (roms: ${ROMS_DIR}, core cache: ${CORES_CACHE}, library: ${LIBRARY_ACCESS})`);
  if (PUBLIC_URL) console.log(`Public address (used in invite links): ${PUBLIC_URL}`);
  console.log("Stop it with the Retro Hub window's Stop button, Ctrl+C, python stop.py / stop.sh, or 'docker compose down' for Docker.");
});
