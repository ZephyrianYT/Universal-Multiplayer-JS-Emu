@echo off
setlocal
rem Double-click to open the Retro Hub control panel (start/stop, settings, apps, files, admin console).
rem With options it runs the console launcher instead, e.g.  launch.bat --tunnel   or   launch.bat --port 8081
cd /d "%~dp0"

rem Find a Python that really runs. "where python" is not enough: Windows has Microsoft Store
rem shortcuts named python.exe / py.exe that exist even when Python is not installed.
set "PY="
py -3 -c "import sys; sys.exit(sys.version_info < (3, 8))" >nul 2>nul && set "PY=py -3"
if not defined PY python -c "import sys; sys.exit(sys.version_info < (3, 8))" >nul 2>nul && set "PY=python"
if not defined PY python3 -c "import sys; sys.exit(sys.version_info < (3, 8))" >nul 2>nul && set "PY=python3"
if not defined PY (
  echo Python 3.8 or newer was not found.
  echo Install it from https://www.python.org/downloads/ ^(tick "Add python.exe to PATH"^), then double-click this again.
  echo If a "python" command opens the Microsoft Store, that is only a shortcut, not Python itself.
  pause
  exit /b 1
)

if not "%~1"=="" goto console
%PY% -c "import tkinter" >nul 2>nul || (
  echo This Python has no window support ^(tkinter^). Starting the console launcher instead.
  goto console
)

rem pythonw shows the panel without a black console window behind it.
set "PYW="
for /f "usebackq delims=" %%i in (`%PY% -c "import sys, os; p = os.path.join(os.path.dirname(sys.executable), 'pythonw.exe'); print(p if os.path.isfile(p) else '')"`) do set "PYW=%%i"
if defined PYW (
  start "" "%PYW%" "%~dp0RetroHub.pyw"
  exit /b 0
)
%PY% RetroHub.pyw
if errorlevel 1 pause
exit /b

:console
%PY% launch.py %*
pause
