#!/usr/bin/env python3
"""Retro Hub apps: native emulators and PC games for remote play.

  python apps.py                         menu: list, add a PC game, add an emulator, remove
  python apps.py list                    what is installed and registered
  python apps.py add-game NAME EXE [-- ARGS...]
  python apps.py add-emulator ID EXE --systems switch[,other] [--label L] [--args "{game}"] [--new-system ...]
  python apps.py remove ID
  python apps.py status                  JSON for the hub server
  python apps.py pretendo-status         JSON: is Cemu ready for Pretendo Network (dumps, account, service)?
  python apps.py pretendo-enable         set Cemu's active account to the Pretendo network service (backs up settings.xml)
  python apps.py run --app ID [--game PATH] [--job NAME] [--link KEY=VALUE ...] [--headless]    used by the hub server
                                         (--link: host, port, players, role for emulators with a "link" block)
                                         (--headless: keep the program's windows off-screen; the host plays it in
                                          the browser, which captures the window. stdin "show" / "hide" toggles.)

Built-in emulators (core/runner/catalog.json) are found by dropping a portable build into emulators/<id>/.
Anything else (Ryujinx forks, other emulators anywhere on disk, PC games) is registered in emulators/apps.json.

Container: `run` starts the program inside a Windows Job Object (Linux: its own process group). Everything it
spawns (launchers, helper processes) stays in that container, the hub's keyboard mode only types into windows
inside it, and stopping closes the windows politely, then ends whatever is left. Nothing in the emulator's
folder is changed by this tool; the program gets its arguments and runs exactly as installed.
"""
import argparse
import json
import os
import re
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CATALOG = ROOT / "core" / "runner" / "catalog.json"
WIN = sys.platform == "win32"


def emu_dir():
    return Path(os.environ.get("EMULATORS_DIR") or ROOT / "emulators").resolve()


def apps_file():
    return emu_dir() / "apps.json"


# ------------------------------------------------------------------ registry
def read_json(p, default):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as e:
        raise SystemExit(f"Can't read {p}: {e}")


def load_user():
    u = read_json(apps_file(), {})
    for k in ("emulators", "systems", "games"):
        if not isinstance(u.get(k), dict):
            u[k] = {}
    return u


def save_user(u):
    apps_file().parent.mkdir(parents=True, exist_ok=True)
    tmp = apps_file().with_suffix(".tmp")
    tmp.write_text(json.dumps(u, indent=2) + "\n", encoding="utf-8")
    tmp.replace(apps_file())


def load_catalog():
    """Built-in catalog + emulators/apps.json. User emulators go first in their systems' lists."""
    cat = read_json(CATALOG, None)
    if not cat:
        raise SystemExit(f"Missing {CATALOG}")
    u = load_user()
    systems = {k: dict(v, emulators=list(v.get("emulators", []))) for k, v in cat["systems"].items()}
    emulators = {k: dict(v) for k, v in cat["emulators"].items()}
    for sid, s in u["systems"].items():
        systems[sid] = {"label": s.get("label", sid), "ext": s.get("ext", []), "dirs": s.get("dirs", []),
                        "emulators": list(s.get("emulators", [])), "custom": True}
    for eid, e in u["emulators"].items():
        emulators[eid] = {**e, "custom": True}
        for sid in reversed(e.get("systems", [])):
            if sid in systems and eid not in systems[sid]["emulators"]:
                systems[sid]["emulators"].insert(0, eid)
    return systems, emulators, u["games"]


def resolve_path(p):
    p = Path(os.path.expandvars(os.path.expanduser(str(p))))
    return (p if p.is_absolute() else emu_dir() / p).resolve()


_PRODUCT_CACHE = {}


def product_name(p):
    """The Windows ProductName (or FileDescription) of an .exe, lowercased; "" when it has none or off Windows."""
    if not WIN:
        return ""
    p = str(p)
    try:
        key = (p, os.stat(p).st_mtime_ns)
    except OSError:
        return ""
    if key in _PRODUCT_CACHE:
        return _PRODUCT_CACHE[key]
    out = ""
    try:
        import ctypes
        from ctypes import wintypes as W
        v = ctypes.WinDLL("version")
        v.GetFileVersionInfoSizeW.argtypes = [W.LPCWSTR, ctypes.c_void_p]
        v.GetFileVersionInfoW.argtypes = [W.LPCWSTR, W.DWORD, W.DWORD, ctypes.c_void_p]
        v.VerQueryValueW.argtypes = [ctypes.c_void_p, W.LPCWSTR, ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(W.UINT)]
        n = v.GetFileVersionInfoSizeW(p, None)
        if n:
            buf = ctypes.create_string_buffer(n)
            if v.GetFileVersionInfoW(p, 0, n, buf):
                ptr, ln = ctypes.c_void_p(), W.UINT()
                langs = []
                if v.VerQueryValueW(buf, "\\VarFileInfo\\Translation", ctypes.byref(ptr), ctypes.byref(ln)) and ln.value >= 4:
                    arr = ctypes.cast(ptr, ctypes.POINTER(W.WORD * (ln.value // 2))).contents
                    langs = [f"{arr[i]:04x}{arr[i + 1]:04x}" for i in range(0, len(arr) - 1, 2)]
                for lang in langs + ["040904b0", "040904e4"]:
                    for field in ("ProductName", "FileDescription"):
                        if v.VerQueryValueW(buf, f"\\StringFileInfo\\{lang}\\{field}", ctypes.byref(ptr), ctypes.byref(ln)) and ln.value:
                            out = ctypes.wstring_at(ptr, ln.value).rstrip("\0").strip().lower()
                            if out:
                                break
                    if out:
                        break
    except Exception:
        out = ""
    _PRODUCT_CACHE[key] = out
    return out


def _product_ok(p, e):
    """False when the exe says it is a different program (e.g. melonDS renamed to Azahar.exe)."""
    want = [w.lower() for w in e.get("product") or []]
    if not want:
        return True
    name = product_name(p).replace(" ", "")
    return not name or any(w.replace(" ", "") in name for w in want)


def find_exe(eid, e):
    """A registered exe path, a known executable name in emulators/<folder>/ (or one folder below), or (Windows)
    any .exe in an emulators/ subfolder whose ProductName says it is this emulator, whatever it is called."""
    if e.get("exe"):
        p = resolve_path(e["exe"])
        return p if p.is_file() else None
    names = {n.lower() for n in (e.get("win") if WIN else e.get("nix")) or []}
    for folder in e.get("folders") or [eid]:
        base = emu_dir() / folder
        hit = _look(base, names, eid, 1, e)
        if hit:
            return hit
    if WIN and e.get("product"):
        want = [w.lower().replace(" ", "") for w in e["product"]]
        try:
            subs = sorted((x for x in os.scandir(emu_dir()) if x.is_dir() and not x.name.startswith(".")), key=lambda x: x.name.lower())
        except OSError:
            subs = []
        for d in subs:
            hit = _look_product(d.path, want, 1)
            if hit:
                return hit
    return None


def _look(d, names, eid, depth, e=None):
    try:
        entries = sorted(os.scandir(d), key=lambda x: x.name.lower())
    except OSError:
        return None
    for x in entries:
        n = x.name.lower()
        if x.is_file() and (n in names or (not WIN and n.endswith(".appimage") and eid in n)):
            if e is None or _product_ok(x.path, e):
                return Path(x.path)
    if depth > 0:
        for x in entries:
            if x.is_dir() and not x.name.startswith("."):
                hit = _look(x.path, names, eid, depth - 1, e)
                if hit:
                    return hit
    return None


def _look_product(d, want, depth):
    try:
        entries = sorted(os.scandir(d), key=lambda x: x.name.lower())
    except OSError:
        return None
    for x in entries:
        if x.is_file() and x.name.lower().endswith(".exe"):
            name = product_name(x.path).replace(" ", "")
            if name and any(w in name for w in want):
                return Path(x.path)
    if depth > 0:
        for x in entries:
            if x.is_dir() and not x.name.startswith("."):
                hit = _look_product(x.path, want, depth - 1)
                if hit:
                    return hit
    return None


def status():
    systems, emulators, games = load_catalog()
    found = {eid: find_exe(eid, e) for eid, e in emulators.items()}
    out_sys = {}
    for sid, s in systems.items():
        pick = next((x for x in s["emulators"] if found.get(x)), None) or (s["emulators"][0] if s["emulators"] else None)
        out_sys[sid] = {"label": s["label"], "emulator": pick,
                        "emulatorLabel": emulators.get(pick, {}).get("label", pick) if pick else None,
                        "installed": sid == "pc" or bool(pick and found.get(pick))}
    return {
        "ok": True,
        "emulators": {eid: {"label": e.get("label", eid), "installed": bool(found[eid]), "custom": bool(e.get("custom"))}
                      for eid, e in emulators.items()},
        "systems": out_sys,
        "games": [{"id": gid, "name": g.get("name", gid), "installed": bool(g.get("exe") and resolve_path(g["exe"]).is_file())}
                  for gid, g in games.items()],
    }


# ------------------------------------------------------------------ container (Windows Job Object)
class WinJob:
    """Kill-on-close job containing this runner and everything it starts."""

    def __init__(self, name):
        import ctypes
        from ctypes import wintypes as W
        self.c, self.W = ctypes, W
        k = self.k = ctypes.WinDLL("kernel32", use_last_error=True)
        u = self.u = ctypes.WinDLL("user32", use_last_error=True)
        k.CreateJobObjectW.restype = W.HANDLE
        k.CreateJobObjectW.argtypes = [ctypes.c_void_p, W.LPCWSTR]
        k.SetInformationJobObject.argtypes = [W.HANDLE, ctypes.c_int, ctypes.c_void_p, W.DWORD]
        k.QueryInformationJobObject.argtypes = [W.HANDLE, ctypes.c_int, ctypes.c_void_p, W.DWORD, ctypes.c_void_p]
        k.AssignProcessToJobObject.argtypes = [W.HANDLE, W.HANDLE]
        k.TerminateJobObject.argtypes = [W.HANDLE, W.UINT]
        k.GetCurrentProcess.restype = W.HANDLE
        k.CloseHandle.argtypes = [W.HANDLE]
        u.PostMessageW.argtypes = [W.HWND, W.UINT, W.WPARAM, W.LPARAM]
        u.GetWindowThreadProcessId.argtypes = [W.HWND, ctypes.POINTER(W.DWORD)]
        u.IsWindowVisible.argtypes = [W.HWND]

        # A job left over from an earlier run with the same name: end it first (one app at a time).
        for _ in range(20):
            h = k.CreateJobObjectW(None, name)
            if not h:
                raise OSError(ctypes.get_last_error(), "CreateJobObject failed")
            if ctypes.get_last_error() != 183:  # ERROR_ALREADY_EXISTS
                break
            k.TerminateJobObject(h, 1)
            k.CloseHandle(h)
            time.sleep(0.15)
        else:
            raise OSError("an earlier app container is still closing")
        self.h = h

        class BASIC(ctypes.Structure):
            _fields_ = [("PerProcessUserTimeLimit", ctypes.c_int64), ("PerJobUserTimeLimit", ctypes.c_int64),
                        ("LimitFlags", W.DWORD), ("MinimumWorkingSetSize", ctypes.c_size_t),
                        ("MaximumWorkingSetSize", ctypes.c_size_t), ("ActiveProcessLimit", W.DWORD),
                        ("Affinity", ctypes.c_size_t), ("PriorityClass", W.DWORD), ("SchedulingClass", W.DWORD)]

        class EXTENDED(ctypes.Structure):
            _fields_ = [("Basic", BASIC), ("IoInfo", ctypes.c_uint64 * 6), ("ProcessMemoryLimit", ctypes.c_size_t),
                        ("JobMemoryLimit", ctypes.c_size_t), ("PeakProcessMemoryUsed", ctypes.c_size_t),
                        ("PeakJobMemoryUsed", ctypes.c_size_t)]

        info = EXTENDED()
        info.Basic.LimitFlags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        if not k.SetInformationJobObject(h, 9, ctypes.byref(info), ctypes.sizeof(info)):
            raise OSError(ctypes.get_last_error(), "SetInformationJobObject failed")
        # The runner joins first, so every process it starts is born inside the container (no race).
        if not k.AssignProcessToJobObject(h, k.GetCurrentProcess()):
            raise OSError(ctypes.get_last_error(), "AssignProcessToJobObject failed")

    def pids(self):
        c, W = self.c, self.W

        class LIST(c.Structure):
            _fields_ = [("Assigned", W.DWORD), ("InList", W.DWORD), ("Ids", c.c_size_t * 512)]

        lst = LIST()
        if not self.k.QueryInformationJobObject(self.h, 3, c.byref(lst), c.sizeof(lst), None):
            return set()
        return {int(lst.Ids[i]) for i in range(min(lst.InList, 512))} - {os.getpid()}

    def close_windows(self):
        c, W = self.c, self.W
        mine = self.pids()
        proto = c.WINFUNCTYPE(W.BOOL, W.HWND, W.LPARAM)

        def cb(hwnd, _):
            pid = W.DWORD()
            self.u.GetWindowThreadProcessId(hwnd, c.byref(pid))
            if pid.value in mine and self.u.IsWindowVisible(hwnd):
                self.u.PostMessageW(hwnd, 0x0010, 0, 0)  # WM_CLOSE: lets the emulator save settings / memory cards
            return True

        self.u.EnumWindows(proto(cb), 0)


# ------------------------------------------------------------------ headless windows (Windows)
class Offscreen:
    """Keeps the container's main windows just past the right edge of the desktop, so the emulator doesn't sit
    on screen as a second window: the host's browser captures it (Windows Graphics Capture keeps working for
    windows that are off-screen but not minimised) and shows it in the page. "show" puts them back where they
    were; they are also put back before the program is closed, so it doesn't save an off-screen position."""

    def __init__(self, job):
        import ctypes
        from ctypes import wintypes as W
        self.c, self.W, self.job = ctypes, W, job
        u = self.u = ctypes.WinDLL("user32", use_last_error=True)
        try:
            u.SetThreadDpiAwarenessContext.restype = ctypes.c_void_p
            u.SetThreadDpiAwarenessContext.argtypes = [ctypes.c_void_p]
        except AttributeError:
            pass

        class RECT(ctypes.Structure):
            _fields_ = [("left", W.LONG), ("top", W.LONG), ("right", W.LONG), ("bottom", W.LONG)]

        self.RECT = RECT
        u.GetWindowRect.argtypes = [W.HWND, ctypes.POINTER(RECT)]
        u.SetWindowPos.argtypes = [W.HWND, W.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, W.UINT]
        u.GetWindowThreadProcessId.argtypes = [W.HWND, ctypes.POINTER(W.DWORD)]
        u.IsWindowVisible.argtypes = [W.HWND]
        u.IsIconic.argtypes = [W.HWND]
        u.GetWindow.argtypes = [W.HWND, W.UINT]
        u.GetWindow.restype = W.HWND
        u.GetWindowTextLengthW.argtypes = [W.HWND]
        u.GetWindowLongW.argtypes = [W.HWND, ctypes.c_int]
        u.ShowWindow.argtypes = [W.HWND, ctypes.c_int]
        u.SetForegroundWindow.argtypes = [W.HWND]
        self.home = {}        # hwnd -> (x, y) where it was before we moved it
        self.hidden = True
        self.lock = threading.Lock()

    def _dpi(self):
        try:
            self.u.SetThreadDpiAwarenessContext(self.c.c_void_p(-4))  # per-monitor v2: real pixel coordinates
        except (AttributeError, OSError):
            pass

    def windows(self):
        c, W, mine = self.c, self.W, self.job.pids()
        found = []
        proto = c.WINFUNCTYPE(W.BOOL, W.HWND, W.LPARAM)

        def cb(hwnd, _):
            pid = W.DWORD()
            self.u.GetWindowThreadProcessId(hwnd, c.byref(pid))
            if pid.value not in mine or not self.u.IsWindowVisible(hwnd) or self.u.GetWindow(hwnd, 4):  # GW_OWNER: dialogs stay
                return True
            if self.u.GetWindowLongW(hwnd, -20) & 0x80:  # WS_EX_TOOLWINDOW
                return True
            r = self.RECT()
            self.u.GetWindowRect(hwnd, c.byref(r))
            if r.right - r.left >= 160 and r.bottom - r.top >= 120 and self.u.GetWindowTextLengthW(hwnd) > 0:
                found.append((hwnd, r))
            return True

        self.u.EnumWindows(proto(cb), 0)
        return found

    def apply(self):
        """Move windows that are on screen off it (when hidden), or back home (when shown)."""
        with self.lock:
            self._dpi()
            vx, vw = self.u.GetSystemMetrics(76), self.u.GetSystemMetrics(78)  # virtual screen left, width
            edge = vx + vw + 64
            flags = 0x0001 | 0x0004 | 0x0010  # SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE
            for hwnd, r in self.windows():
                if self.u.IsIconic(hwnd):
                    if not self.hidden:
                        continue
                    self.u.ShowWindow(hwnd, 4)  # SW_SHOWNOACTIVATE: a minimised window can't be captured
                    continue
                if self.hidden and r.left < edge:
                    self.home.setdefault(hwnd, (r.left, r.top))
                    self.u.SetWindowPos(hwnd, None, edge, max(0, r.top), 0, 0, flags)
                elif not self.hidden and hwnd in self.home:
                    x, y = self.home.pop(hwnd)
                    self.u.SetWindowPos(hwnd, None, x, y, 0, 0, flags & ~0x0010)
                    self.u.SetForegroundWindow(hwnd)

    def set_hidden(self, hidden):
        self.hidden = hidden
        self.apply()
        emit(t="window", hidden=hidden)

    def loop(self, stop):
        started = time.time()
        while not stop.is_set():
            if self.hidden:
                try:
                    self.apply()
                except OSError:
                    pass
            stop.wait(0.3 if time.time() - started < 30 else 1.5)  # catch the first window fast


# ------------------------------------------------------------------ run
def emit(**m):
    sys.stdout.write(json.dumps(m) + "\n")
    sys.stdout.flush()


def unquote(a):
    """Launch options are passed to the program as a list (Windows adds the quoting itself), so quotes the user
    typed around a token, like "{game}" or '--fullscreen', must go: left in, they reach the emulator as part of
    the path and it can't open the game."""
    a = str(a).strip()
    while len(a) >= 2 and a[0] == a[-1] and a[0] in "\"'":
        a = a[1:-1].strip()
    return a


def split_args(s):
    """Split typed launch options like `--fullscreen "{game}"`, keeping quoted parts (with spaces) together and
    backslashes as they are (Windows paths)."""
    return [unquote(t) for t in re.findall(r'"[^"]*"|\'[^\']*\'|\S+', s or "") if unquote(t)]


LINK_KEYS = {
    "host": re.compile(r"^[A-Za-z0-9.-]{1,253}$|^\d{1,3}(\.\d{1,3}){3}$"),
    "port": re.compile(r"^\d{1,5}$"),
    "players": re.compile(r"^[2-4]$"),
    "role": re.compile(r"^(server|client)$"),
}


def parse_link(items):
    """["host=1.2.3.4", "port=5738", ...] -> dict, every value checked (they end up on a command line)."""
    out = {}
    for it in items or []:
        k, _, v = str(it).partition("=")
        k = k.strip().lower()
        if k not in LINK_KEYS or not LINK_KEYS[k].match(v):
            raise SystemExit(f"bad link setting {it!r}")
        if k == "port" and not 1 <= int(v) <= 65535:
            raise SystemExit(f"bad link port {v!r}")
        out[k] = v
    return out


def build_command(app, game, link=None):
    systems, emulators, games = load_catalog()
    if app in games:
        g = games[app]
        exe = resolve_path(g.get("exe", ""))
        args = [unquote(a) for a in g.get("args", []) if unquote(a)]
        cwd = resolve_path(g["workdir"]) if g.get("workdir") else exe.parent
        label = g.get("name", app)
    elif app in emulators:
        e = emulators[app]
        exe = find_exe(app, e)
        if not exe:
            raise SystemExit(f"{e.get('label', app)} isn't installed (emulators/{(e.get('folders') or [app])[0]}/).")
        tpl = [unquote(a) for a in e.get("args", ["{game}"]) if unquote(a)]
        if game is None:
            args = [a for a in tpl if "{game}" not in a and a != "--"]
        else:
            args = [a.replace("{game}", game) for a in tpl]
            if not any("{game}" in a for a in tpl):
                args.append(game)
        if e.get("link") and game and "=" in game:
            # VBA-M reads every NAME=VALUE argument as a setting, so a game path with "=" would not load.
            raise SystemExit(f"{e.get('label', app)} can't open a game whose path contains '=': rename {Path(game).name!r} or its folder.")
        if link:
            # Network link cable (e.g. VBA-M): the emulator's "link" block lists extra arguments with
            # {link_host} {link_port} {link_players} {link_role} filled in from the hub's link session.
            lt = (e.get("link") or {}).get("args")
            if not lt:
                raise SystemExit(f"{e.get('label', app)} has no network link support in the catalog.")
            vals = {"link_host": link.get("host", ""), "link_port": link.get("port", ""),
                    "link_players": link.get("players", "2"), "link_role": link.get("role", "client")}
            for a in lt:
                for k, v in vals.items():
                    a = a.replace("{" + k + "}", v)
                args.append(a)
        cwd = exe.parent
        label = e.get("label", app)
    else:
        raise SystemExit(f"Unknown app {app!r}. See: python apps.py list")
    if not exe or not exe.is_file():
        raise SystemExit(f"{label}: program not found ({exe}).")
    if WIN and exe.suffix.lower() != ".exe":
        # .bat/.cmd go through cmd.exe, which re-parses arguments; only real programs are started.
        raise SystemExit(f"{label}: only .exe programs can be started ({exe.name}).")
    return label, [str(exe), *args], str(cwd)


def run(app, game, job, link=None, headless=False):
    import subprocess
    label, cmd, cwd = build_command(app, game, link)
    container = WinJob(job) if WIN and job else None
    offscreen = Offscreen(container) if headless and container else None
    proc = subprocess.Popen(cmd, cwd=cwd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                            start_new_session=not WIN)
    emit(t="started", app=app, label=label, pid=proc.pid, container=bool(container))

    stop = threading.Event()

    def watch_stdin():  # "stop" from the hub, or the hub going away (EOF); "show" / "hide" for headless windows
        for line in sys.stdin:
            cmd = line.strip()
            if cmd == "stop":
                break
            if offscreen and cmd in ("show", "hide"):
                try:
                    offscreen.set_hidden(cmd == "hide")
                except OSError:
                    pass
        stop.set()

    threading.Thread(target=watch_stdin, daemon=True).start()
    if offscreen:
        threading.Thread(target=offscreen.loop, args=(stop,), daemon=True).start()

    def alive():
        if proc.poll() is None:
            return True
        # Launchers often start the real game and exit: keep going while anything is left in the container.
        return bool(container and container.pids())

    while alive() and not stop.is_set():
        stop.wait(0.5)

    if stop.is_set() and alive():
        if offscreen:  # back on screen first, so the emulator doesn't save an off-screen window position
            try:
                offscreen.hidden = False
                offscreen.apply()
            except OSError:
                pass
        if container:
            container.close_windows()
        elif proc.poll() is None:
            import signal
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except OSError:
                pass
        deadline = time.time() + 5
        while alive() and time.time() < deadline:
            time.sleep(0.2)
        if not WIN and proc.poll() is None:
            import signal
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except OSError:
                pass
        emit(t="stopped", forced=alive())
    else:
        emit(t="exited", code=proc.poll())
    # Exiting closes the container's last handle: Windows ends anything still inside it.
    sys.stdout.flush()
    os._exit(0)


# ------------------------------------------------------------------ registry commands
def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")[:40] or "app"


def store_path(p):
    """Inside the emulators folder: stored relative (the folder can move). Elsewhere: absolute."""
    p = Path(p).expanduser().resolve()
    try:
        return p.relative_to(emu_dir()).as_posix()
    except ValueError:
        return str(p)


def check_exe(p):
    p = Path(str(p).strip().strip('"')).expanduser()
    if not p.is_file():
        raise SystemExit(f"Not a file: {p}")
    if WIN and p.suffix.lower() != ".exe":
        raise SystemExit("Pick the program's .exe (shortcuts and .bat files can't be contained).")
    return p


def add_game(name, exe, args):
    u = load_user()
    exe = check_exe(exe)
    gid = slug(name)
    systems, emulators, _ = load_catalog()
    if gid in emulators:
        gid = "game-" + gid
    u["games"][gid] = {"name": name.strip()[:80], "exe": store_path(exe), "args": list(args or [])}
    save_user(u)
    print(f"Added PC game '{name}' ({gid}). It shows in the hub's library under 'PC games' (restart not needed).")


def add_emulator(eid, exe, systems_csv, label, args, new_system):
    u = load_user()
    systems, emulators, _ = load_catalog()
    eid = slug(eid)
    exe = check_exe(exe)
    tpl = split_args(args) or ["{game}"]
    sys_ids = [s.strip() for s in (systems_csv or "").split(",") if s.strip()]
    if new_system:
        sid, slabel, ext, dirs = (new_system + ":::").split(":")[:4]
        sid = slug(sid).replace("-", "")
        u["systems"][sid] = {"label": slabel or sid, "ext": [x.strip().lower() for x in ext.split(",") if x.strip()],
                             "dirs": [x.strip() for x in dirs.split(",") if x.strip()] or [sid], "emulators": [eid]}
        sys_ids.append(sid)
        systems[sid] = u["systems"][sid]
    unknown = [s for s in sys_ids if s not in systems]
    if unknown or not sys_ids:
        raise SystemExit(f"Give --systems from: {', '.join(k for k in systems if k != 'pc')} (or --new-system id:Label:ext1,ext2:folder)")
    u["emulators"][eid] = {"label": label or eid, "exe": store_path(exe), "args": tpl, "systems": sys_ids}
    save_user(u)
    print(f"Added emulator {label or eid} ({eid}) for {', '.join(sys_ids)}. Restart the hub to pick up new consoles.")


def remove(item):
    u = load_user()
    for k in ("games", "emulators", "systems"):
        if item in u[k]:
            del u[k][item]
            save_user(u)
            return print(f"Removed {item}.")
    raise SystemExit(f"{item!r} isn't in {apps_file()} (built-in emulators are removed by deleting their folder).")


# ------------------------------------------------------------------ Pretendo Network (Cemu)
# Cemu 2.0+ has Pretendo built in: Options > General settings > Account > Network service = Pretendo, stored in
# settings.xml as <AccountService><SelectedService PersistentId=".." Service="2"/></AccountService>
# (NetworkService: 0 Offline, 1 Nintendo, 2 Pretendo, 3 Custom). It needs the console's own otp.bin and
# seeprom.bin and an account.dat for a Pretendo Network ID (PNID). No hosts-file or DNS change is involved.
CEMU_SERVICES = {0: "Offline", 1: "Nintendo", 2: "Pretendo", 3: "Custom"}


def cemu_paths():
    """(exe, data dir) for the installed Cemu. Portable builds keep everything in <exe dir>/portable/."""
    _, emulators, _ = load_catalog()
    exe = find_exe("cemu", emulators["cemu"]) if "cemu" in emulators else None
    if not exe:
        return None, None
    if (exe.parent / "portable").is_dir():
        return exe, exe.parent / "portable"
    if WIN:
        return exe, Path(os.environ.get("APPDATA", "")) / "Cemu"
    return exe, Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share") / "Cemu"


def _cemu_settings(data):
    for cand in (data / "settings.xml", (Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config") / "Cemu" / "settings.xml") if not WIN else None):
        if cand and cand.is_file():
            return cand
    return data / "settings.xml"


def pretendo_status():
    import xml.etree.ElementTree as ET
    exe, data = cemu_paths()
    out = {"ok": True, "installed": bool(exe), "ready": False, "problems": [], "service": None, "account": None, "accounts": []}
    if not exe:
        out["problems"].append("Cemu isn't installed (emulators/cemu/).")
        return out
    out["dataDir"] = str(data)
    if (exe.parent / "cemuhook.dll").is_file() and not (exe.parent / "portable").is_dir() and not data.is_dir():
        out["problems"].append("This looks like Cemu 1.x (cemuhook.dll). Pretendo needs Cemu 2.0 or newer.")
    for f in ("otp.bin", "seeprom.bin"):
        if not any((d / f).is_file() for d in (data, exe.parent)):
            out["problems"].append(f"{f} is missing: dump it from your own Wii U and put it in {data}.")
    settings = _cemu_settings(data)
    persistent, service, mlc = None, None, data / "mlc01"
    if settings.is_file():
        try:
            root = ET.parse(settings).getroot()
            pid = root.findtext("Account/PersistentId")
            persistent = int(pid) if pid and pid.strip().isdigit() else None
            m = (root.findtext("mlc_path") or "").strip()
            if m:
                mlc = Path(m)
            legacy = root.findtext("Account/ActiveService")
            for el in root.findall("AccountService/SelectedService"):
                if persistent is not None and el.get("PersistentId", "").isdigit() and int(el.get("PersistentId")) == persistent:
                    service = int(el.get("Service", "0") or 0)
            if service is None and legacy and legacy.strip().lstrip("-").isdigit():
                online = (root.findtext("Account/OnlineEnabled") or "").strip().lower() == "true"
                service = int(legacy) if online else 0
        except (ET.ParseError, OSError, ValueError) as err:
            out["problems"].append(f"Couldn't read {settings.name}: {err}")
    else:
        out["problems"].append("Cemu hasn't been set up yet (no settings.xml): open Cemu once and finish its first-run setup.")
    act = mlc / "usr" / "save" / "system" / "act"
    try:
        dirs = sorted(d for d in act.iterdir() if d.is_dir())
    except OSError:
        dirs = []
    for d in dirs:
        info = {}
        try:
            for line in (d / "account.dat").read_text(encoding="utf-8", errors="replace").splitlines():
                k, _, v = line.partition("=")
                if k in ("PersistentId", "AccountId", "MiiName"):
                    info[k] = v.strip()[:64]
        except OSError:
            continue
        pid = int(info["PersistentId"], 16) if re.fullmatch(r"[0-9a-fA-F]{8}", info.get("PersistentId", "")) else int(d.name, 16) if re.fullmatch(r"[0-9a-fA-F]{8}", d.name) else None
        out["accounts"].append({"persistentId": pid, "networkId": info.get("AccountId", ""), "folder": d.name})
    if persistent is not None:
        out["account"] = next((a for a in out["accounts"] if a["persistentId"] == persistent), {"persistentId": persistent, "networkId": "", "folder": f"{persistent:08x}"})
    out["service"] = CEMU_SERVICES.get(service) if service is not None else None
    if settings.is_file():
        if not out["account"] or not (act / out["account"]["folder"] / "account.dat").is_file():
            out["problems"].append("The active Cemu account has no account.dat: download it for your PNID (Pretendo account page) or dump it from your Wii U, then pick it in Options > General settings > Account.")
        elif not out["account"]["networkId"]:
            out["problems"].append("The active Cemu account isn't linked to a network ID: use an account.dat made for your Pretendo Network ID (PNID).")
        if out["service"] != "Pretendo":
            out["problems"].append(f"Cemu's network service is {out['service'] or 'not set'}: choose Pretendo in Options > General settings > Account (or press Use Pretendo).")
    out["ready"] = not out["problems"]
    return out


def pretendo_enable():
    """Set SelectedService=2 (Pretendo) for Cemu's active account. Keeps settings.xml.bak-retrohub first."""
    import shutil
    import xml.etree.ElementTree as ET
    exe, data = cemu_paths()
    if not exe:
        raise SystemExit("Cemu isn't installed.")
    settings = _cemu_settings(data)
    if not settings.is_file():
        raise SystemExit("Cemu hasn't been set up yet (no settings.xml). Open Cemu once first.")
    tree = ET.parse(settings)
    root = tree.getroot()
    pid = (root.findtext("Account/PersistentId") or "").strip()
    if not pid.isdigit():
        raise SystemExit("Cemu has no active account. Pick one in Options > General settings > Account.")
    svc = root.find("AccountService")
    if svc is None:
        svc = ET.SubElement(root, "AccountService")
    el = next((e for e in svc.findall("SelectedService") if e.get("PersistentId") == pid), None)
    if el is None:
        el = ET.SubElement(svc, "SelectedService", {"PersistentId": pid})
    el.set("Service", "2")
    backup = settings.with_name(settings.name + ".bak-retrohub")
    if not backup.exists():
        shutil.copy2(settings, backup)
    tmp = settings.with_suffix(".tmp-retrohub")
    tree.write(tmp, encoding="utf-8", xml_declaration=True)
    tmp.replace(settings)
    return {"ok": True, "backup": str(backup)}


def list_all():
    st = status()
    print(f"Emulators folder: {emu_dir()}\n\nEmulators:")
    for eid, e in st["emulators"].items():
        print(f"  {'[x]' if e['installed'] else '[ ]'} {e['label']:<26} {eid}{'  (yours)' if e['custom'] else ''}")
    print("\nConsoles:")
    for sid, s in st["systems"].items():
        if sid != "pc":
            print(f"  {'[x]' if s['installed'] else '[ ]'} {s['label']:<18} -> {s['emulatorLabel'] or '-'}")
    print("\nPC games:")
    for g in st["games"] or []:
        print(f"  {'[x]' if g['installed'] else '[missing]'} {g['name']}  ({g['id']})")
    if not st["games"]:
        print("  (none yet: python apps.py add-game \"Name\" \"C:\\path\\game.exe\")")


def browse():
    try:
        import tkinter as tk
        from tkinter import filedialog
        r = tk.Tk()
        r.withdraw()
        r.attributes("-topmost", True)
        p = filedialog.askopenfilename(title="Pick the program", filetypes=[("Programs", "*.exe")] if WIN else [])
        r.destroy()
        return p
    except Exception:
        return ""


def menu():
    while True:
        print()
        list_all()
        print("\n[1] Add a PC game   [2] Add an emulator   [3] Remove   [q] Quit")
        c = input("> ").strip().lower()
        try:
            if c == "1":
                name = input("Game name: ").strip()
                exe = input("Path to the game's .exe (Enter = browse): ").strip() or browse()
                extra = input("Extra launch options (optional): ").strip()
                if name and exe:
                    add_game(name, exe, split_args(extra))
            elif c == "2":
                label = input("Emulator name (e.g. Ryujinx): ").strip()
                exe = input("Path to its .exe (Enter = browse): ").strip() or browse()
                systems, _, _ = load_catalog()
                print("Consoles: " + ", ".join(k for k in systems if k != "pc"))
                syscsv = input("Which consoles (comma separated; or 'new' for a console not listed): ").strip()
                new = None
                if syscsv.lower() == "new":
                    sid = input("  console id (e.g. vita): ").strip()
                    sl = input("  console name (e.g. PS Vita): ").strip()
                    ext = input("  file extensions (e.g. vpk,zip): ").strip()
                    dirs = input("  library folder name(s) (e.g. vita): ").strip()
                    new, syscsv = f"{sid}:{sl}:{ext}:{dirs}", ""
                args = input('Launch options, {game} = game path (Enter = "{game}"): ').strip()
                if label and exe:
                    add_emulator(label, exe, syscsv, label, args, new)
            elif c == "3":
                remove(input("Id to remove: ").strip())
            elif c in ("q", "quit", "exit", ""):
                return
        except SystemExit as e:
            print(f"! {e}")


def main():
    ap = argparse.ArgumentParser(description="Retro Hub apps: native emulators and PC games")
    sub = ap.add_subparsers(dest="cmd")
    sub.add_parser("list")
    sub.add_parser("status")
    sub.add_parser("pretendo-status")
    sub.add_parser("pretendo-enable")
    g = sub.add_parser("add-game")
    g.add_argument("name")
    g.add_argument("exe")
    g.add_argument("args", nargs=argparse.REMAINDER)
    e = sub.add_parser("add-emulator")
    e.add_argument("id")
    e.add_argument("exe")
    e.add_argument("--systems", default="")
    e.add_argument("--label")
    e.add_argument("--args", help='launch options, e.g. "-f {game}"')
    e.add_argument("--new-system", help="id:Label:ext1,ext2:folder1,folder2")
    r = sub.add_parser("remove")
    r.add_argument("id")
    rn = sub.add_parser("run")
    rn.add_argument("--app", required=True)
    rn.add_argument("--game")
    rn.add_argument("--job", default="")
    rn.add_argument("--link", action="append", default=[], help="network link setting KEY=VALUE (host, port, players, role)")
    rn.add_argument("--headless", action="store_true", help="keep the program's windows off-screen (the browser shows it)")
    a = ap.parse_args()
    if a.cmd == "list":
        list_all()
    elif a.cmd == "status":
        print(json.dumps(status()))
    elif a.cmd == "pretendo-status":
        print(json.dumps(pretendo_status()))
    elif a.cmd == "pretendo-enable":
        try:
            print(json.dumps(pretendo_enable()))
        except SystemExit as err:
            print(json.dumps({"ok": False, "error": str(err)}))
        except (OSError, Exception) as err:  # noqa: BLE001
            print(json.dumps({"ok": False, "error": f"couldn't change settings.xml: {err}"}))
    elif a.cmd == "add-game":
        add_game(a.name, a.exe, [x for x in a.args if x != "--"])
    elif a.cmd == "add-emulator":
        add_emulator(a.id, a.exe, a.systems, a.label, a.args, a.new_system)
    elif a.cmd == "remove":
        remove(a.id)
    elif a.cmd == "run":
        try:
            run(a.app, a.game, a.job, parse_link(a.link), headless=a.headless)
        except SystemExit as err:
            emit(t="error", error=str(err))
            sys.exit(1)
        except OSError as err:
            emit(t="error", error=f"couldn't start: {err}")
            sys.exit(1)
    else:
        menu()


if __name__ == "__main__":
    main()
